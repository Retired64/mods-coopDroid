-- name: Information Display
-- description: Shows a variety of information, such as speed, angle, and position.\nCreated by Sunk, Isaac, and Piko Piko.

local hud_x_pos_offset = 0
local hud_y_pos_offset = 100
local show_speed = 1
local show_v_speed = 0
local show_s_speed = 0
local show_angle = 0
local show_pos = 0
local style = FONT_MENU
local zor2 = '2'
local colon = ':'

local scale = 1
local r = 255
local g = 255
local b = 255

function show_info(msg)

    if string.lower(msg) == 'all' then
        show_speed = 1
        show_v_speed = 1
        show_s_speed = 1
        show_angle = 1
        show_pos = 1
        return true
    end

    if string.lower(msg) == 'none' then
        show_speed = 0
        show_v_speed = 0
        show_s_speed = 0
        show_angle = 0
        show_pos = 0
        return true
    end

    if string.lower(msg) == 'speed' or string.lower(msg) == 'spd' or 
    string.lower(msg) == 'horizontal speed' or string.lower(msg) == 'h speed' or string.lower(msg) == 'h spd' then
        if show_speed == 1 then
            show_speed = 0
            return true
        else
            show_speed = 1
            return true
        end
        return false
    end

    if string.lower(msg) == 'vertical speed' or string.lower(msg) == 'v speed' or string.lower(msg) == 'v spd' or
    string.lower(msg) == 'y speed' or string.lower(msg) == 'y spd' then
        if show_v_speed == 1 then
            show_v_speed = 0
            return true
        else
            show_v_speed = 1
            return true
        end
        return false
    end

    if string.lower(msg) == 'sliding speed' or string.lower(msg) == 's speed' or string.lower(msg) == 's spd' then
        if show_s_speed == 1 then
            show_s_speed = 0
            return true
        else
            show_s_speed = 1
            return true
        end
        return false
    end

    if string.lower(msg) == 'angle' then
        if show_angle == 1 then
            show_angle = 0
            return true
        else
            show_angle = 1
            return true
        end
        return false
    end

    if string.lower(msg) == 'position' or string.lower(msg) == 'pos' then
        if show_pos == 1 then
            show_pos = 0
            return true
        else
            show_pos = 1
            return true
        end
        return false
    end

    return false
end

function set_style(msg)
    if string.lower(msg) == 'normal' then
        style = FONT_HUD
        scale = 2.5
        r = 255
        g = 255
        b = 255
        zor2 = '2'
        colon = ''
        return true
    end

    if string.lower(msg) == 'text' then
        style = FONT_NORMAL
        scale = 2.25
        r = 255
        g = 127
        b = 64
        zor2 = 'Z'
        colon = ':'
        return true
    end

    if string.lower(msg) == 'djui' then
        style = FONT_MENU
        scale = 1
        r = 255
        g = 255
        b = 255
        zor2 = 'Z'
        colon = ':'
        return true
    end

    return false
end

function move_hud_x(num)
    if tonumber(num) ~= nil then
    hud_x_pos_offset = tonumber(num)
    return true
    else
    return false
    end
    return false
end

function move_hud_y(num)
    if tonumber(num) ~= nil then
    hud_y_pos_offset = -tonumber(num)
    return true
    else
    return false
    end
    return false
end

function hud_speed()
    local m = gMarioStates[0]

    djui_hud_set_resolution(RESOLUTION_DJUI)
    djui_hud_set_font(style)
    djui_hud_set_color(r, g, b, 255);

    if show_speed == 1 then
        djui_hud_print_text(string.format("H Spd" .. colon .. " %.0f", m.forwardVel), hud_x_pos_offset, hud_y_pos_offset, scale)
    end
    if show_v_speed == 1 then
        djui_hud_print_text(string.format("Y Spd" .. colon .. " %.0f", m.vel.y), hud_x_pos_offset, hud_y_pos_offset + 50, scale)
    end
    if show_s_speed == 1 then
        djui_hud_print_text(string.format("X SSpd" .. colon .. " %.0f", m.slideVelX), hud_x_pos_offset, hud_y_pos_offset + 100, scale)
        djui_hud_print_text(string.format(zor2 .. " SSpd" .. colon .. " %.0f", m.slideVelZ), hud_x_pos_offset, hud_y_pos_offset + 150, scale)
    end
    if show_angle == 1 then
        djui_hud_print_text(string.format("Angle" .. colon .. " %.0f", m.faceAngle.y), hud_x_pos_offset, hud_y_pos_offset + 200, scale)
    end
    if show_pos == 1 then
        djui_hud_print_text(string.format("X Pos" .. colon .. " %.0f", m.pos.x), hud_x_pos_offset, hud_y_pos_offset + 250, scale)
        djui_hud_print_text(string.format("Y Pos" .. colon .. " %.0f", m.pos.y), hud_x_pos_offset, hud_y_pos_offset + 300, scale)
        djui_hud_print_text(string.format(zor2 .. " Pos" .. colon .. " %.0f", m.pos.z), hud_x_pos_offset, hud_y_pos_offset + 350, scale)
    end
end
    
function on_hud_render()
    hud_speed()
end

hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_chat_command('show', 'Type in any of the following to show that information:\nSpeed\nVertical speed\nSliding speed\nAngle\nPosition\nOr show All or None', show_info)
hook_chat_command('style', 'Sets the style of the displays:\nNormal\nText\nDJUI', set_style)
hook_chat_command('movex', 'Moves the information horizontally. Write an amount to move it by.', move_hud_x)
hook_chat_command('movey', 'Moves the information vertically. Write an amount to move it by.', move_hud_y)