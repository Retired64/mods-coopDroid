-- name: \\#de04fa\\Milne the Crystal Fox
-- incompatible:
-- description: Type "milne \\#00C7FF\\on\\#ffffff\\|\\#A02200\\off\\#ffffff\\" in chat to play as Milne, a character from an SRB2 mod.\n\ \n\OC and original moveset by \\#de04fa\\CystallineGazer\\#ffffff\\ and the team behind the original SRB2 mod. Go support 'em by playin' their mod: \\#de04fa\\https://mb.srb2.org/addons/horizonchars-v1-0-milne-on-ice-the-musical.555/\\#ffffff\\\n\ \n\Moveset recreation by \\#00FFFF\\steven.\n\ \n\Also big thanks t' Isaac fer helpin' me t' fix a major bug that could've really been easily fixed.

E_MODEL_MILNE = smlua_model_util_get_id("milne_geo")
E_MODEL_MILNE_RECOLORABLE = smlua_model_util_get_id("milne_recolorable_geo")

local MILNE_SOUND_WOAH = audio_sample_load("milne-woah.mp3")
local SOD = audio_sample_load("Soldier of Dance (SM64 Mix).mp3")
local HUDGlyph = get_texture_info("HUD")
local kazotskyicon = get_texture_info("kazotskyicon")

local milne = 0
local recolorable = 0
local showIcon = 0

gStateExtras = {}
for i = 0, (MAX_PLAYERS - 1) do
	gStateExtras[i] = {}
	local m = gMarioStates[i]
	local e = gStateExtras[i]
	e.animFrame = 0
	e.rotAngle = 0
	e.crystallanced = 0
	e.watercrystallanced = 0
	e.ttvertspeed = 0
	e.tthorispeed = 0
	e.clspeed = 0
	e.loopTimer = 0
end

ACT_TWISTER_THOK        = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ATTACKING |
	ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_CRYSTAL_LANCE_START = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_MOVING | ACT_FLAG_ATTACKING
	| ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_CRYSTAL_LANCE_DASH  = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_MOVING | ACT_FLAG_ATTACKING
	| ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_CRYSTAL_LANCE_WALL  = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_STATIONARY)
ACT_KAZOTSKY_KICK       = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_MOVING)

function act_twister_thok(m)
	local e = gStateExtras[m.playerIndex]
		if m.actionTimer < 5 then
			m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
		end

		if m.actionState == 1 then spinDirFactor = -1 end
		set_mario_animation(m, MARIO_ANIM_TWIRL)
		if m.actionArg == 0 then
			if m.actionTimer == 0 then
				m.actionState = m.actionArg
				play_character_sound(m, CHAR_SOUND_HOOHOO)
				m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
				if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
					m.health = m.health - 0x100
				end
			elseif m.actionTimer > 0 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
				m.faceAngle.y = m.intendedYaw
				m.actionTimer = 0
				if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
					m.vel.y = -50
					mario_set_forward_vel(m, m.forwardVel * 2)
				else
					m.vel.y = -40
					mario_set_forward_vel(m, m.forwardVel * 1.5)
				end
				return set_mario_action(m, ACT_TWISTER_THOK, 1)
			end
			e.rotAngle = e.rotAngle + 0x2000
		elseif m.actionArg == 1 then
			if m.actionTimer == 0 then
				m.actionState = m.actionArg
				play_character_sound(m, CHAR_SOUND_YAHOO)
				if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
					m.health = m.health - 0x100
				end
			end
			e.rotAngle = e.rotAngle + 0x3053
		end

		if (m.input & INPUT_B_PRESSED) ~= 0 and e.crystallanced == 0 then
			m.faceAngle.y = m.intendedYaw
			e.crystallanced = 1
			set_mario_action(m, ACT_CRYSTAL_LANCE_START, 0)
		end

		local stepResult = common_air_action_step(m, ACT_DOUBLE_JUMP_LAND, MARIO_ANIM_TWIRL,
                           AIR_STEP_CHECK_HANG)
		if stepResult == AIR_STEP_LANDED then
			-- set facing direction
			-- not part of original Extended Moveset
			local yawDiff = m.faceAngle.y - m.intendedYaw
			e.rotAngle = e.rotAngle + yawDiff
			m.faceAngle.y = m.intendedYaw
			if should_get_stuck_in_ground(m) ~= 0 then
				queue_rumble_data_mario(m, 5, 80)
				play_character_sound(m, CHAR_SOUND_OOOF2)
				set_mario_action(m, ACT_FEET_STUCK_IN_GROUND, 0)
			else
				if check_fall_damage(m, ACT_SQUISHED) == 0 then
					set_mario_action(m, ACT_TRIPLE_JUMP_LAND, 0)
				end
			end
		end

		if e.rotAngle > 0x10000 then e.rotAngle = e.rotAngle - 0x10000 end
		if e.rotAngle < -0x10000 then e.rotAngle = e.rotAngle + 0x10000 end
		m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + e.rotAngle

		m.actionTimer = m.actionTimer + 1
		return 0
end

function act_crystal_lance_start(m)
	local e = gStateExtras[m.playerIndex]
		if m.actionTimer > 10 then
			return set_mario_action(m, ACT_CRYSTAL_LANCE_DASH, 0)
		else
			set_mario_animation(m, MARIO_ANIM_FIRST_PUNCH)
			set_anim_to_frame(m, 1)
			mario_set_forward_vel(m, -20)
			m.vel.y = 0
			m.actionTimer = m.actionTimer + 1
			m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
			stepResult = perform_air_step(m, 0)
		end
		m.actionTimer = m.actionTimer + 1
		return 0
end

function act_crystal_lance_dash(m)
	local e = gStateExtras[m.playerIndex]
		if m.actionTimer == 0 then
			m.actionState = m.actionArg
			e.animFrame = 0
			play_character_sound(m, CHAR_SOUND_YAHOO)
			play_sound(SOUND_ACTION_FLYING_FAST, m.marioObj.header.gfx.cameraToObject)
			if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
				m.health = m.health - 0x100
			end
		elseif m.actionTimer > 0 then
			if (m.input & INPUT_B_PRESSED) ~= 0 then
				set_mario_action(m, ACT_FREEFALL, 0)
			end
		end
		if m.actionTimer > 20 then
			return set_mario_action(m, ACT_FREEFALL, 0)
		else
			set_mario_animation(m, MARIO_ANIM_FIRST_PUNCH)
			set_anim_to_frame(m, e.animFrame)
			if e.animFrame >= 25 then
				e.animFrame = 25
			end
			if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
				mario_set_forward_vel(m, 150)
			else
				mario_set_forward_vel(m, 100)
			end
			m.vel.y = 0
			m.actionTimer = m.actionTimer + 1
			m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
			e.animFrame = e.animFrame + 1
		end
		local stepResult = 0
		if (m.input & INPUT_OFF_FLOOR) ~= 0 then
			stepResult = perform_air_step(m, 0)
		elseif (m.input & INPUT_OFF_FLOOR) == 0 then
			stepResult = perform_ground_step(m)
		end
		if (stepResult == AIR_STEP_HIT_WALL or stepResult == GROUND_STEP_HIT_WALL) and m.wall ~= nil then
			m.particleFlags = m.particleFlags | PARTICLE_VERTICAL_STAR
			play_sound(SOUND_ACTION_METAL_BONK, m.marioObj.header.gfx.cameraToObject)
			set_mario_action(m, ACT_CRYSTAL_LANCE_WALL, 0)
		end
		m.marioBodyState.handState = MARIO_HAND_PEACE_SIGN
		m.actionTimer = m.actionTimer + 1
		return 0
end

function act_crystal_lance_wall(m)
	local e = gStateExtras[m.playerIndex]
		m.vel.y = 0
		mario_set_forward_vel(m, 0)
		m.marioBodyState.handState = MARIO_HAND_PEACE_SIGN
		if (m.input & INPUT_A_PRESSED) ~= 0 then
			set_jumping_action(m, ACT_DOUBLE_JUMP, 0)
			play_character_sound(m, CHAR_SOUND_HOOHOO)
			m.vel.y = 65.0
		end
		if (m.input & INPUT_Z_PRESSED) ~= 0 then
			m.vel.y = -10
			set_mario_action(m, ACT_SOFT_BONK, 0)
		end
		if (m.input & INPUT_B_PRESSED) ~= 0 then
			set_mario_action(m, ACT_JUMP_KICK, 0)
		end
end


function act_kazotsky_kick(m)
	set_mario_animation(m, MARIO_ANIM_RUNNING_UNUSED)
	if m.marioObj.header.gfx.animInfo.animFrame > 21 then
		m.marioObj.header.gfx.animInfo.animFrame = 1
	end

    if (m.input & INPUT_A_PRESSED) ~= 0 then
		m.vel.y = 30
        return set_mario_action(m, ACT_JUMP, 0)
    end
	
    if (m.input & INPUT_B_PRESSED) ~= 0 then
        return set_mario_action(m, ACT_PUNCHING, 0)
    end
	
	if (m.controller.buttonPressed & X_BUTTON) ~= 0 then
		return set_mario_action(m, ACT_DOUBLE_JUMP_LAND, 0)
	end

	if (m.marioObj.header.gfx.animInfo.animFrame == 1 or m.marioObj.header.gfx.animInfo.animFrame == 11) then
		play_sound(SOUND_ACTION_TERRAIN_STEP, m.marioObj.header.gfx.cameraToObject)
	end

    if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
		if m.marioObj.header.gfx.animInfo.animFrame >= 3 and m.marioObj.header.gfx.animInfo.animFrame < 9 or
		m.marioObj.header.gfx.animInfo.animFrame >= 14 and m.marioObj.header.gfx.animInfo.animFrame < 19 then
			mario_set_forward_vel(m, 20)
			m.faceAngle.y = m.intendedYaw - approach_s32(convert_s16(m.intendedYaw - m.faceAngle.y), 0, 0x800, 0x800)
		else
			mario_set_forward_vel(m, 0)
		end
	else
        mario_set_forward_vel(m, 0)
    end

	local stepResult = perform_ground_step(m)

    if stepResult == GROUND_STEP_LEFT_GROUND then
		set_mario_action(m, ACT_FREEFALL, 0)
	end

    return 0
end

function mario_update_local(m)
	if milne == 1 then
		if recolorable == 0 then
			gPlayerSyncTable[0].modelId = E_MODEL_MILNE
		else
			gPlayerSyncTable[0].modelId = E_MODEL_MILNE_RECOLORABLE
		end
	end
	if gMarioStates[0].character.type ~= 0 or milne == 0 then
		gPlayerSyncTable[0].modelId = nil
	end
end

function mario_update(m)
	local s = gPlayerSyncTable[m.playerIndex]
	local np = gNetworkPlayers[m.playerIndex]
	-- Taken from the Sonic mod.
	if s.overwriteCharToMario then
		np.overrideModelIndex = 0
	else
		np.overrideModelIndex = np.modelIndex
	end
	local e = gStateExtras[m.playerIndex]
	if m.playerIndex == 0 then
		mario_update_local(m)
	end
	if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
		obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
	end
	--milne's expressions
	if gPlayerSyncTable[m.playerIndex].modelId == E_MODEL_MILNE or gPlayerSyncTable[m.playerIndex].modelId == E_MODEL_MILNE_RECOLORABLE then
			-- yawn
			if m.action == ACT_START_SLEEPING and m.actionState == 2 then
				m.marioBodyState.eyeState = 9
			end
			-- snoring
			if m.action == ACT_SLEEPING then
				if m.actionState == 0 then
					if m.marioObj.header.gfx.animInfo.animFrame < 20 then
						m.marioBodyState.eyeState = 9
					elseif m.marioObj.header.gfx.animInfo.animFrame >= 20 then
						m.marioBodyState.eyeState = 10
					end
				elseif m.actionState == 2 then
					if m.marioObj.header.gfx.animInfo.animFrame < 25 then
						m.marioBodyState.eyeState = 9
					elseif m.marioObj.header.gfx.animInfo.animFrame >= 25 then
						m.marioBodyState.eyeState = 10
					end
				else
					m.marioBodyState.eyeState = 10
				end
			end
			-- blushin' after Peach's kiss
			if m.action == ACT_END_PEACH_CUTSCENE then
				if (m.actionTimer >= 136 and m.actionArg == 8) or (m.actionArg == 9 and m.actionTimer <= 60) then
					m.marioBodyState.eyeState = 11
				end
			end
			-- death 'n hurt animations
			if m.action == ACT_STANDING_DEATH or m.action == ACT_ELECTROCUTION or m.action == ACT_WATER_DEATH then
				m.marioBodyState.eyeState = 13
			end
			if m.action == ACT_LAVA_BOOST or
				m.action == ACT_BURNING_FALL or
				m.action == ACT_BURNING_JUMP or
				m.action == ACT_QUICKSAND_DEATH or
				m.action == ACT_GRABBED or
				m.action == ACT_GETTING_BLOWN or
				m.action == ACT_HARD_BACKWARD_AIR_KB or
				m.action == ACT_BACKWARD_AIR_KB or
				m.action == ACT_SOFT_BACKWARD_GROUND_KB or
				m.action == ACT_HARD_FORWARD_AIR_KB or
				m.action == ACT_FORWARD_AIR_KB or
				m.action == ACT_SOFT_FORWARD_GROUND_KB or
				m.action == ACT_THROWN_FORWARD or
				m.action == ACT_THROWN_BACKWARD or
				m.action == ACT_DEATH_EXIT or
				m.action == ACT_BURNING_GROUND then
				m.marioBodyState.eyeState = 12
			end
			if m.action == ACT_HARD_BACKWARD_GROUND_KB or
				m.action == ACT_BACKWARD_GROUND_KB or
				m.action == ACT_HARD_FORWARD_GROUND_KB or
				m.action == ACT_FORWARD_GROUND_KB or
				m.action == ACT_DEATH_EXIT_LAND or
				m.action == ACT_FORWARD_WATER_KB or
				m.action == ACT_BACKWARD_WATER_KB or
				m.action == ACT_GROUND_BONK then
				m.marioBodyState.eyeState = 14
			end
			if m.action == ACT_DEATH_ON_BACK or m.action == ACT_DEATH_ON_STOMACH then
				m.actionTimer = m.actionTimer + 1
				if m.actionTimer >= 30 then
					m.marioBodyState.eyeState = 13
				end
			end
			if m.action == ACT_DROWNING then
				if m.actionState == 0 then
					m.marioBodyState.eyeState = 12
				elseif m.actionState == 1 then
					m.marioBodyState.eyeState = 13
				end
			end
			-- misc
			if m.action == ACT_STAR_DANCE_EXIT or m.action == ACT_STAR_DANCE_NO_EXIT or m.action == ACT_STAR_DANCE_WATER then
				if m.marioBodyState.eyeState < 2 then
					m.marioBodyState.eyeState = 2
				end
			end
			if m.action == ACT_EXIT_LAND_SAVE_DIALOG and m.actionState == 2 then
				if m.marioObj.header.gfx.animInfo.animFrame > 109 and m.marioObj.header.gfx.animInfo.animFrame < 154 then
					m.marioBodyState.eyeState = 15
				elseif m.marioObj.header.gfx.animInfo.animFrame > 0 and m.marioObj.header.gfx.animInfo.animFrame <= 109 then
					m.marioBodyState.eyeState = 12
				end
			end
			if m.action == ACT_FEET_STUCK_IN_GROUND then
				if m.marioObj.header.gfx.animInfo.animFrame < 100 then
					m.marioBodyState.eyeState = 12
				elseif m.marioObj.header.gfx.animInfo.animFrame >= 100 then
					m.marioBodyState.eyeState = 14
				end
			end
			if m.action == ACT_BUTT_STUCK_IN_GROUND then
				if m.marioObj.header.gfx.animInfo.animFrame < 100 then
					m.marioBodyState.eyeState = 12
				elseif m.marioObj.header.gfx.animInfo.animFrame >= 100 then
					m.marioBodyState.eyeState = 14
				end
			end
			if m.action == ACT_PANTING then
				m.marioBodyState.eyeState = 16
			end
			if m.action == ACT_SHIVERING then
				if m.actionState == 0 then
					if m.marioObj.header.gfx.animInfo.animFrame >= 30 then
						m.marioBodyState.eyeState = 16
					else
						m.marioBodyState.eyeState = 17
					end
				else
					m.marioBodyState.eyeState = 17
				end
			end
		--end of expressions
	end
	if milne == 1 then
		local thokkable = m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_LONG_JUMP or
			m.action == ACT_TRIPLE_JUMP or m.action == ACT_SIDE_FLIP or m.action == ACT_BACKFLIP or m.action == ACT_WALL_KICK_AIR
			or m.action == ACT_STEEP_JUMP or m.action == ACT_FREEFALL
		
		if m.action == ACT_IDLE and (m.controller.buttonPressed & X_BUTTON) ~= 0 then
			return set_mario_action(m, ACT_KAZOTSKY_KICK, 0)
		end
		
		if thokkable and m.actionTimer > 0 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
			m.faceAngle.y = m.intendedYaw
			if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
				m.vel.y = 60
				mario_set_forward_vel(m, m.forwardVel * 2.5)
			else
				m.vel.y = 50
				mario_set_forward_vel(m, m.forwardVel * 2)
			end
			return set_mario_action(m, ACT_TWISTER_THOK, 0)
		end
		
		if thokkable then
			m.actionTimer = m.actionTimer + 1
		end	

		local waterActions = m.action == ACT_WATER_PLUNGE or
			m.action == ACT_WATER_IDLE or
			m.action == ACT_FLUTTER_KICK or
			m.action == ACT_SWIMMING_END or
			m.action == ACT_WATER_ACTION_END or
			m.action == ACT_METAL_WATER_FALLING or
			m.action == ACT_BREASTSTROKE
		if waterActions then
			return set_mario_action(m, ACT_MILNE_WATER_FALLING, 0)
		end

		if (m.action & ACT_FLAG_AIR) == 0 
		or m.action == ACT_WALL_KICK_AIR then
			e.crystallanced = 0
		end
		
		if m.action == ACT_MILNE_WATER_WALKING
		or m.action == ACT_MILNE_WATER_STANDING then
			e.watercrystallanced = 0
		end
		if m.action == ACT_DIVE and e.crystallanced == 0 then
			e.crystallanced = 1
			return set_mario_action(m, ACT_CRYSTAL_LANCE_START, 0)
		end
		if (m.action == ACT_WALKING or m.action == ACT_HOLD_WALKING) and m.forwardVel > 0 then
			m.forwardVel = m.forwardVel * 1.05
		end
		
		custom_character_snore(m)
	end
	if milne == 0 then
		local milnesWaterActions = m.action == ACT_MILNE_WATER_FALLING or
			m.action == ACT_MILNE_WATER_STANDING or
			m.action == ACT_MILNE_WATER_WALKING or
			m.action == ACT_WATER_TWISTER_THOK or
			m.action == ACT_WATER_CRYSTAL_LANCE_DASH
		if milnesWaterActions then
			return set_mario_action(m, ACT_WATER_IDLE, 0)
		end
		if m.action == ACT_TWISTER_THOK then
			return set_mario_action(m, ACT_FREEFALL, 0)
		end
		if m.playerIndex ~= 0 then
			if dist_between_objects(m.marioObj, gMarioStates[0].marioObj) <= 100 and m.action == ACT_KAZOTSKY_KICK then
				if gMarioStates[0].action == ACT_IDLE then
					showIcon = 1
					if (gMarioStates[0].controller.buttonPressed & X_BUTTON) ~= 0 then
						return set_mario_action(gMarioStates[0], ACT_KAZOTSKY_KICK, 0)
					end
				else
					showIcon = 0
				end
			end
		end
	end
	
    local np = gNetworkPlayers[0]
    if not np.connected then
        return false
    end
	
	-- Soldier of Dance
	if m.action == ACT_KAZOTSKY_KICK and m.playerIndex == 0 then
		seq_player_lower_volume(SEQ_PLAYER_LEVEL, 100, 40)
		if e.loopTimer > 0 then
			e.loopTimer = e.loopTimer - 1
		else
			e.loopTimer = 32 * 30
			audio_sample_play(SOD, m.pos, 3)
		end
	end
	if (m.action ~= ACT_KAZOTSKY_KICK and m.playerIndex == 0) then
		seq_player_unlower_volume(SEQ_PLAYER_LEVEL, 100)
		audio_sample_stop(SOD)
	end
end

function mario_before_phys_step(m)
	local hScale = 1.0
	local e = gStateExtras[m.playerIndex]
	if milne == 1 then
		if ((m.action & ACT_FLAG_AIR) ~= 0 or m.action == ACT_METAL_WATER_JUMP) and m.vel.y < 0 then
			m.vel.y = m.vel.y - 2
		end
	end
end

function mario_on_set_action(m)
	local e = gStateExtras[m.playerIndex]
	if milne == true then
		if m.action == ACT_METAL_WATER_JUMP then
			m.vel.y = m.vel.y + 4
		end
		if m.action == ACT_SLEEPING then
			e.animFrame = 0
		end
	end
	if m.action == ACT_KAZOTSKY_KICK then
		e.loopTimer = 0
	end
end

function on_hud_render()
	local m = gMarioStates[0]
	if obj_get_first_with_behavior_id(id_bhvActSelector) ~= nil or is_game_paused() or
		(m.action == ACT_END_PEACH_CUTSCENE or m.action == ACT_CREDITS_CUTSCENE or m.action == ACT_END_WAVING_CUTSCENE) then
		return
	end
	djui_hud_set_resolution(RESOLUTION_DJUI)
	if milne == 1 then
		local size = (djui_hud_get_screen_height() * 0.01) / (m.character.hudHeadTexture.height * 0.15)
		djui_hud_set_color(255, 255, 255, 255)
		djui_hud_render_texture(HUDGlyph, djui_hud_get_screen_height() / 24, djui_hud_get_screen_height() / 40,
			size, size)
		if set_cam_angle(0) == CAM_ANGLE_MARIO then
			djui_hud_set_color(255, 255, 255, 255)
			djui_hud_render_texture(HUDGlyph,
				(djui_hud_get_screen_width()) - 200, djui_hud_get_screen_height() * 2 / 2.45
				, size, size)
		end
	end
	if showIcon == 1 then
		render_kazotsky_icon()
	end
end

function milne_command(msg)
	if msg == 'on' then
		djui_chat_message_create('\\#de04fa\\Milne\\#ffffff\\ is \\#00C7FF\\on\\#ffffff\\!')
		gPlayerSyncTable[0].overwriteCharToMario = true
		milne = 1
		return true
	elseif msg == 'off' then
		djui_chat_message_create('\\#de04fa\\Milne\\#ffffff\\ is \\#A02200\\off\\#ffffff\\!')
		gPlayerSyncTable[0].overwriteCharToMario = false
		milne = 0
		return true
	end
end

function convert_s16(num)
    local min = -32768
    local max = 32767
    while (num < min) do
        num = max + (num - min)
    end
    while (num > max) do
        num = min + (num - max)
    end
    return num
end

function milnecolor(msg)
	if msg == 'on' then
		djui_chat_message_create('\\#de04fa\\Milne\\#ffffff\\ is \\#00C7FF\\recolorable\\#ffffff\\!')
		recolorable = 1
		return true
	elseif msg == 'off' then
		djui_chat_message_create('\\#de04fa\\Milne\\#ffffff\\ is \\#A02200\\not recolorable\\#ffffff\\!')
		recolorable = 0
		return true
	end
end

for i = 0, (MAX_PLAYERS - 1) do
	local s = gPlayerSyncTable[i]
	s.overwriteCharToMario = false
end

function render_kazotsky_icon()
    local outPos = {x = 0, y = 0, z = 0}
    local scale

    djui_hud_set_resolution(RESOLUTION_N64)
    djui_hud_set_font(FONT_NORMAL)
    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)

    for i = 1, network_player_connected_count() - 1 do
        local m = gMarioStates[i]

        if m.marioBodyState.updateTorsoTime == gMarioStates[0].marioBodyState.updateTorsoTime and dist_between_objects(m.marioObj, gMarioStates[0].marioObj) <= 100 then
            local headPos = {x = m.marioBodyState.headPos.x, y = m.marioBodyState.headPos.y + 100, z = m.marioBodyState.headPos.z}
            djui_hud_world_pos_to_screen_pos(headPos, outPos)

            if gMarioStates[0].area.camera ~= nil then
                scale = 50 - (vec3f_dist(gLakituState.pos, headPos) / 100)
            else
                scale = 0
            end

            if scale < 0 then
                scale = 0
            elseif scale > 50 then
                scale = 50
            end

			djui_hud_render_texture(kazotskyicon, outPos.x - 30, outPos.y - scale, scale / 50, scale / 50)
        end
    end
end

-- SMS Alfredo's voice system.
-- Define what triggers the custom voice
local function use_custom_voice(m)
    return gPlayerSyncTable[m.playerIndex].modelId == E_MODEL_MILNE or gPlayerSyncTable[m.playerIndex].modelId == E_MODEL_MILNE_RECOLORABLE --Put your condition here!
end

--How many snores the sleep-talk has, or rather, how long the sleep-talk lasts
--If you omit the sleep-talk you can ignore this
local SLEEP_TALK_SNORES = 8

--Define what actions play what voice clips
--If an action has more than one voice clip, put those clips inside a table
--CHAR_SOUND_SNORING3 requires two or three voice clips to work properly...
--but you can omit it if your character does not sleep-talk
local CUSTOM_VOICETABLE = {
    [CHAR_SOUND_ATTACKED] = {'milne-ugh-hurt.mp3', 'milne-hurt.mp3'},
    [CHAR_SOUND_COUGHING1] = 'milne-cough.mp3',
    [CHAR_SOUND_COUGHING2] = {'milne-cough-2.mp3', 'milne-cough-2-2.mp3'},
    [CHAR_SOUND_COUGHING3] = 'milne-cough-3.mp3',
    [CHAR_SOUND_DOH] = {'milne-doh.mp3', 'milne-doh-2.mp3'},
    --[CHAR_SOUND_DROWNING] = 'Blurp_Blurp_Blurp_Drowning',
    [CHAR_SOUND_DYING] = 'milne-death.mp3',
    [CHAR_SOUND_EEUH] = 'milne-hrnng.mp3',
    --[CHAR_SOUND_GAME_OVER] = 'Game_Over.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'milne-hay.mp3',
    [CHAR_SOUND_HAHA] = 'milne-chuckle.mp3',
    [CHAR_SOUND_HAHA_2] = 'milne-chuckle.mp3',
    [CHAR_SOUND_HELLO] = 'milne-sup.mp3',
    --[CHAR_SOUND_HERE_WE_GO] = 'Here_we_GO_Mario_Kart_64.ogg',
    [CHAR_SOUND_HOOHOO] = {'milne-ha.mp3', 'milne-hup.mp3'},
    [CHAR_SOUND_HRMM] = 'milne-grunt.mp3',
    --[CHAR_SOUND_IMA_TIRED] = 'Ughtired.ogg',
    --[CHAR_SOUND_LETS_A_GO] = 'Okay.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'milne-o-em-gee-guys-she-said-the-bad-word.mp3',
    --[CHAR_SOUND_OKEY_DOKEY] = 'Okie_Dokie.ogg',
    [CHAR_SOUND_ON_FIRE] = 'milne-lava.mp3',
    [CHAR_SOUND_OOOF] = 'milne-ugh-hurt.mp3',
    [CHAR_SOUND_OOOF2] = 'milne-ugh-hurt.mp3',
    --[CHAR_SOUND_PANTING] = 'Panting_Low_Energy.ogg',
    --[CHAR_SOUND_PANTING_COLD] = 'Panting_Low_Energy.ogg',
    --[CHAR_SOUND_PRESS_START_TO_PLAY] = 'Press_Start_to_Play.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'milne-hah.mp3',
    [CHAR_SOUND_PUNCH_WAH] = 'milne-ha.mp3',
    [CHAR_SOUND_PUNCH_YAH] = 'milne-ha-2.mp3',
    --[CHAR_SOUND_SNORING1] = 'Snoring1.ogg',
    --[CHAR_SOUND_SNORING2] = 'Snoring2.ogg',
    --[CHAR_SOUND_SNORING3] = {'Snoring3.ogg', 'Snoring2.ogg', 'Must_Plant_Flowers_Talking_in_Sleep.ogg'},
    --[CHAR_SOUND_SO_LONGA_BOWSER] = 'Bye_Bye_King_Bowser.ogg',
    --[CHAR_SOUND_TWIRL_BOUNCE] = 'Boing.ogg',
    [CHAR_SOUND_UH] = 'milne-uhng.mp3',
    [CHAR_SOUND_UH2] = 'milne-uhng.mp3',
    [CHAR_SOUND_UH2_2] = 'milne-uhng.mp3',
    [CHAR_SOUND_WAAAOOOW] = 'milne-falling.mp3',
    [CHAR_SOUND_WAH2] = 'milne-ha-2.mp3g',
    [CHAR_SOUND_WHOA] = 'milne-woah.mp3',
    [CHAR_SOUND_YAHOO] = 'milne-yeah.mp3',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'milne-yeah.mp3', 'milne-yeah.mp3', 'milne-yeah.mp3'},
    [CHAR_SOUND_YAH_WAH_HOO] = {'milne-ha-2.mp3', 'milne-hay.mp3'},
    [CHAR_SOUND_YAWNING] = 'milne-yawn.mp3',
}

--Define the table of samples that will be used for each player
--Global so if multiple mods use this they won't create unneeded samples
--DON'T MODIFY THIS SINCE IT'S GLOBAL FOR USE BY OTHER MODS!
gCustomVoiceSamples = {}
gCustomVoiceStream = nil

--Get the player's sample, stop whatever sound
--it's playing if it doesn't match the provided sound
--DON'T MODIFY THIS SINCE IT'S GLOBAL FOR USE BY OTHER MODS!
--- @param m MarioState
function stop_custom_character_sound(m, sound)
    local voice_sample = gCustomVoiceSamples[m.playerIndex]
    if voice_sample == nil or not voice_sample.loaded then
        return
    end

    audio_sample_stop(voice_sample)
    if voice_sample.file.relativePath:match('^.+/(.+)$') == sound then
        return voice_sample
    end
    audio_sample_destroy(voice_sample)
end

--Play a custom character's sound
--DON'T MODIFY THIS SINCE IT'S GLOBAL FOR USE BY OTHER MODS!
--- @param m MarioState
function play_custom_character_sound(m, voice)
    --Get sound, if it's a table, get a random entry from it
    local sound
    if type(voice) == "table" then
        sound = voice[math.random(#voice)]
    else
        sound = voice
    end
    if sound == nil then return 0 end

    --Get current sample and stop it
    local voice_sample = stop_custom_character_sound(m, sound)

    --If the new sound isn't a string, let's assume it's
    --a number to return to the character sound hook
    if type(sound) ~= "string" then
        return sound
    end

    --Load a new sample and play it! Don't make a new one if we don't need to
    if (m.area == nil or m.area.camera == nil) and m.playerIndex == 0 then
        if gCustomVoiceStream ~= nil then
            audio_stream_stop(gCustomVoiceStream)
            audio_stream_destroy(gCustomVoiceStream)
        end
        gCustomVoiceStream = audio_stream_load(sound)
        audio_stream_play(gCustomVoiceStream, true, 1)
    else
        if voice_sample == nil then
            voice_sample = audio_sample_load(sound)
        end
        audio_sample_play(voice_sample, m.pos, 1)

        gCustomVoiceSamples[m.playerIndex] = voice_sample
    end
    return 0
end

--Main character sound hook
--This hook is freely modifiable in case you want to make any specific exceptions
--- @param m MarioState
local function custom_character_sound(m, characterSound)
    if not use_custom_voice(m) then return end
    if characterSound == CHAR_SOUND_SNORING3 then return 0 end
    if characterSound == CHAR_SOUND_HAHA and m.hurtCounter > 0 then return 0 end

    local voice = CUSTOM_VOICETABLE[characterSound]
    if voice ~= nil then
        return play_custom_character_sound(m, voice)
    end
    return 0
end

--Snoring logic for CHAR_SOUND_SNORING3 since we have to loop it manually
--This code won't activate on the Japanese version, due to MARIO_MARIO_SOUND_PLAYED not being set
local SNORE3_TABLE = CUSTOM_VOICETABLE[CHAR_SOUND_SNORING3]
local STARTING_SNORE = 46
local SLEEP_TALK_START = STARTING_SNORE + 49
local SLEEP_TALK_END = SLEEP_TALK_START + SLEEP_TALK_SNORES

--Main hook for snoring
--- @param m MarioState
function custom_character_snore(m)
    if not use_custom_voice(m) then return end

    --Stop the snoring!
    if m.action ~= ACT_SLEEPING then
        if m.isSnoring > 0 then
            stop_custom_character_sound(m)
        end
        return

    --You're not in deep snoring
    elseif not (m.actionState == 2 and (m.flags & MARIO_MARIO_SOUND_PLAYED) ~= 0) then
        return
    end

    local animFrame = m.marioObj.header.gfx.animInfo.animFrame

    --Behavior for CHAR_SOUND_SNORING3
    if SNORE3_TABLE ~= nil and #SNORE3_TABLE >= 2 then
        --Exhale sound
        if animFrame == 2 and m.actionTimer < SLEEP_TALK_START then
            play_custom_character_sound(m, SNORE3_TABLE[2])

        --Inhale sound
        elseif animFrame == 25 then
            
            --Count up snores
            if #SNORE3_TABLE >= 3 then
                m.actionTimer = m.actionTimer + 1

                --End sleep-talk
                if m.actionTimer >= SLEEP_TALK_END then
                    m.actionTimer = STARTING_SNORE
                end
    
                --Enough snores? Start sleep-talk
                if m.actionTimer == SLEEP_TALK_START then
                    play_custom_character_sound(m, SNORE3_TABLE[3])
                
                --Regular snoring
                elseif m.actionTimer < SLEEP_TALK_START then
                    play_custom_character_sound(m, SNORE3_TABLE[1])
                end
            
            --Definitely regular snoring
            else
                play_custom_character_sound(m, SNORE3_TABLE[1])
            end
        end

    --No CHAR_SOUND_SNORING3, just use regular snoring
    elseif animFrame == 2 then
        play_character_sound(m, CHAR_SOUND_SNORING2)

    elseif animFrame == 25 then
        play_character_sound(m, CHAR_SOUND_SNORING1)
    end
end

-----------
-- hooks --
-----------
hook_event(HOOK_BEFORE_PHYS_STEP, mario_before_phys_step)
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_CHARACTER_SOUND, custom_character_sound)

hook_mario_action(ACT_TWISTER_THOK, act_twister_thok, INTERACT_PLAYER)
hook_mario_action(ACT_CRYSTAL_LANCE_START, act_crystal_lance_start,INTERACT_PLAYER)
hook_mario_action(ACT_CRYSTAL_LANCE_DASH, act_crystal_lance_dash, INT_KICK)
hook_mario_action(ACT_CRYSTAL_LANCE_WALL, act_crystal_lance_wall, INTERACT_PLAYER)
hook_mario_action(ACT_KAZOTSKY_KICK, act_kazotsky_kick, INTERACT_PLAYER)
hook_chat_command("milne",
	"[\\#00C7FF\\on\\#ffffff\\|\\#A02200\\off\\#ffffff\\] turn \\#de04fa\\Milne \\#00C7FF\\on \\#ffffff\\or \\#A02200\\off"
	, milne_command)
hook_chat_command("milnecolor",
	"[\\#00C7FF\\on\\#ffffff\\|\\#A02200\\off\\#ffffff\\] Toggle \\#de04fa\\Milne's \\#ffffff\\recolorability.", milnecolor)
