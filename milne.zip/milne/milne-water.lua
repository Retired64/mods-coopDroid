ACT_MILNE_WATER_FALLING        =     (0x09A | ACT_GROUP_SUBMERGED | ACT_FLAG_MOVING | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_WATER_OR_TEXT | ACT_FLAG_CONTROL_JUMP_HEIGHT)
ACT_MILNE_WATER_STANDING       =     (0x09B | ACT_GROUP_SUBMERGED | ACT_FLAG_IDLE | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_WATER_OR_TEXT)
ACT_MILNE_WATER_WALKING        =   	 (0x09C | ACT_GROUP_SUBMERGED | ACT_FLAG_MOVING | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_WATER_OR_TEXT)
ACT_WATER_TWISTER_THOK         = 	 (0x09D | ACT_GROUP_SUBMERGED | ACT_FLAG_MOVING | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_WATER_OR_TEXT)
ACT_WATER_CRYSTAL_LANCE_START  =     (0x09E | ACT_GROUP_SUBMERGED | ACT_FLAG_MOVING | ACT_FLAG_ATTACKING  | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_WATER_OR_TEXT)
ACT_WATER_CRYSTAL_LANCE_DASH   = 	 (0x09F | ACT_GROUP_SUBMERGED | ACT_FLAG_MOVING | ACT_FLAG_INVULNERABLE | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_WATER_OR_TEXT)

function act_milne_water_falling(m)
	local e = gStateExtras[m.playerIndex]
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end

    if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
		if m.forwardVel > 60 then mario_set_forward_vel(m, 60) end
		if m.forwardVel < -60 then mario_set_forward_vel(m, -60) end
		if (m.input & INPUT_B_PRESSED) ~= 0 and e.watercrystallanced == 0 then
			e.watercrystallanced = 1
			return set_mario_action(m, ACT_WATER_CRYSTAL_LANCE_START, 0)
		end
    end
	local animation = MARIO_ANIM_GENERAL_FALL
	if m.vel.y < 0 then m.vel.y = m.vel.y + 3 end
	m.peakHeight = m.pos.y
	if m.actionArg == 0 then
		animation = MARIO_ANIM_GENERAL_FALL
	elseif m.actionArg == 1 then
		animation = MARIO_ANIM_FALL_FROM_WATER
	else
        animation = MARIO_ANIM_SINGLE_JUMP
	end

	local stepResult = perform_air_step(m, 0)
	update_air_without_turn(m)
	set_mario_animation(m, animation)
    if stepResult == AIR_STEP_LANDED then --hit floor or cancelled
        set_mario_action(m, ACT_MILNE_WATER_STANDING, 0)
    end
    if (m.input & INPUT_A_PRESSED) ~= 0 and m.actionTimer >= 1 then
		m.faceAngle.y = m.intendedYaw
		if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
		m.vel.y = 60
			mario_set_forward_vel(m, m.forwardVel * 2.5)
		else
			m.vel.y = 50
			mario_set_forward_vel(m, m.forwardVel * 2)
		end
        return set_mario_action(m, ACT_WATER_TWISTER_THOK, 0)
    end
    if (m.pos.y >= m.waterLevel - 80) and m.vel.y > 0 then
		m.pos.y = m.waterLevel
		set_mario_particle_flags(m, PARTICLE_WATER_SPLASH, false)
		return set_mario_action(m, ACT_WATER_JUMP, 0)
    end
	m.actionTimer = m.actionTimer + 1
    return 0
end

function act_milne_water_standing(m)
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end
    if (m.input & INPUT_A_PRESSED) ~= 0 then
		m.vel.y = 50
		mario_set_forward_vel(m, 0)
        return set_mario_action(m, ACT_MILNE_WATER_FALLING, 2)
    end

    if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
		m.faceAngle.y = m.intendedYaw
        return set_mario_action(m, ACT_MILNE_WATER_WALKING, 0)
    end

    if m.actionState == 0 then
		set_mario_animation(m, MARIO_ANIM_IDLE_HEAD_LEFT)
    elseif m.actionState == 1 then
		set_mario_animation(m, MARIO_ANIM_IDLE_HEAD_RIGHT)
    elseif m.actionState == 2 then
		set_mario_animation(m, MARIO_ANIM_IDLE_HEAD_CENTER)
    end

    if is_anim_at_end(m) ~= 0 then
		if m.actionState >= 3 then
			m.actionState = 0
		else
			m.actionState = m.actionState + 1
		end
    end

    if (m.pos.y >= m.waterLevel - 150) then
        set_mario_particle_flags(m, PARTICLE_IDLE_WATER_WAVE, false)
    end

    return 0
end

function act_milne_water_walking(m)
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end

    if (m.input & INPUT_FIRST_PERSON) ~= 0 then
        return set_mario_action(m, ACT_MILNE_WATER_STANDING, 0)
    end

    if (m.input & INPUT_A_PRESSED) ~= 0 then
		m.vel.y = 50
        return set_mario_action(m, ACT_MILNE_WATER_FALLING, 2)
    end
	
    if (m.input & INPUT_B_PRESSED) ~= 0 then
        return set_mario_action(m, ACT_WATER_CRYSTAL_LANCE_START, 2)
    end

    if (m.input & INPUT_ZERO_MOVEMENT) ~= 0 then
        return set_mario_action(m, ACT_MILNE_WATER_STANDING, 0)
    end

	update_walking_speed(m)
	local stepResult = perform_ground_step(m)

    if stepResult == GROUND_STEP_LEFT_GROUND then
		set_mario_action(m, ACT_MILNE_WATER_FALLING, 1)
    elseif stepResult == GROUND_STEP_NONE then
		anim_and_audio_for_walk(m)
		if m.forwardVel < 20 then mario_set_forward_vel(m, 20) end
    elseif stepResult == GROUND_STEP_HIT_WALL then
		push_or_sidle_wall(m, m.pos)
		m.actionTimer = 0
	end

    return 0
end

function act_water_twister_thok(m)
	local e = gStateExtras[m.playerIndex]
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end
	if m.actionTimer < 5 then
		m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
	end
	if m.vel.y < -20 then m.vel.y = m.vel.y + 3 end

	m.peakHeight = m.pos.y
	if m.actionState == 1 then spinDirFactor = -1 end
	set_mario_animation(m, MARIO_ANIM_TWIRL)
	if m.actionArg == 0 then
		if m.actionTimer == 0 then
			m.actionState = m.actionArg
			play_character_sound(m, CHAR_SOUND_HOOHOO)
			m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
			if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
				m.health = m.health - 0x100
			end
		elseif m.actionTimer > 0 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
			m.faceAngle.y = m.intendedYaw
			m.actionTimer = 0
			if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
				m.vel.y = -50
				mario_set_forward_vel(m, m.forwardVel * 2)
			else
				m.vel.y = -40
				mario_set_forward_vel(m, m.forwardVel * 1.5)
			end
			return set_mario_action(m, ACT_WATER_TWISTER_THOK, 1)
			end
		e.rotAngle = e.rotAngle + 0x2000
	elseif m.actionArg == 1 then
		if m.actionTimer == 0 then
			m.actionState = m.actionArg
			play_character_sound(m, CHAR_SOUND_YAHOO)
			if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
				m.health = m.health - 0x100
			end
		end
		e.rotAngle = e.rotAngle + 0x3053
	end
	
    if (m.pos.y >= m.waterLevel - 100) and m.vel.y > 0 then
		m.pos.y = m.waterLevel
		set_mario_particle_flags(m, PARTICLE_WATER_SPLASH, false)
		return set_mario_action(m, ACT_TWISTER_THOK, 0)
    end
	
	if (m.input & INPUT_B_PRESSED) ~= 0 and e.watercrystallanced == 0 then
	    e.watercrystallanced = 1
		return set_mario_action(m, ACT_WATER_CRYSTAL_LANCE_START, 0)
    end
	
	
	local stepResult = perform_air_step(m, 0)
	update_air_without_turn(m)
	set_mario_animation(m, MARIO_ANIM_TWIRL)
	if stepResult == AIR_STEP_LANDED then
		-- set facing direction
		-- not part of original Extended Moveset
		local yawDiff = m.faceAngle.y - m.intendedYaw
		e.rotAngle = e.rotAngle + yawDiff
		m.faceAngle.y = m.intendedYaw
		set_mario_action(m, ACT_MILNE_WATER_STANDING, 0)
	end
	if e.rotAngle >  0x10000 then e.rotAngle = e.rotAngle - 0x10000 end
	if e.rotAngle < -0x10000 then e.rotAngle = e.rotAngle + 0x10000 end
	m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + e.rotAngle
	
    m.actionTimer = m.actionTimer + 1
    return 0
end

function act_water_crystal_lance_start(m)
    local e = gStateExtras[m.playerIndex]
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end
    if m.actionTimer > 10 then
		return set_mario_action(m, ACT_WATER_CRYSTAL_LANCE_DASH, 0)
	else
		set_mario_animation(m, MARIO_ANIM_FIRST_PUNCH)
		set_anim_to_frame(m, 1)
		mario_set_forward_vel(m, -20)	    
		m.vel.y = 0
		m.actionTimer = m.actionTimer + 1
		m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
		stepResult = perform_air_step(m, 0)
	end
	m.actionTimer = m.actionTimer + 1
	return 0
end	

function act_water_crystal_lance_dash(m)
	local e = gStateExtras[m.playerIndex]
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end
	if m.actionArg == 0 then
	if m.actionTimer == 0 then
		m.actionState = m.actionArg
		e.animFrame = 0
		play_character_sound(m, CHAR_SOUND_YAHOO)
		play_sound(SOUND_ACTION_FLYING_FAST, m.marioObj.header.gfx.cameraToObject)
		if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
			m.health = m.health - 0x100
		end
	elseif m.actionTimer > 0 then
		if (m.input & INPUT_B_PRESSED) ~= 0 then
			set_mario_action(m, ACT_MILNE_WATER_FALLING, 0)
		end
	end
	if m.actionTimer > 40 then
		return set_mario_action(m, ACT_MILNE_WATER_FALLING, 0)
	else
		set_mario_animation(m, MARIO_ANIM_FIRST_PUNCH)
		set_anim_to_frame(m, e.animFrame)
		if e.animFrame >= 25 then
			e.animFrame = 25
		end
		if m.flags & (MARIO_NORMAL_CAP | MARIO_CAP_ON_HEAD) == 0 then
			mario_set_forward_vel(m, 80)
		else
			mario_set_forward_vel(m, 70)
		end
		m.vel.y = 0
		m.actionTimer = m.actionTimer + 1
		m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
		e.animFrame = e.animFrame + 1
	end
	local stepResult = 0
	if (m.input & INPUT_OFF_FLOOR) ~= 0 then
		stepResult = perform_air_step(m, 0)
	elseif (m.input & INPUT_OFF_FLOOR) == 0 then
		stepResult = perform_ground_step(m)
	end
	if (stepResult == AIR_STEP_HIT_WALL or stepResult == GROUND_STEP_HIT_WALL) then
		m.particleFlags = m.particleFlags | PARTICLE_VERTICAL_STAR
		play_sound(SOUND_ACTION_METAL_BONK, m.marioObj.header.gfx.cameraToObject)
		return set_mario_action(m, ACT_WATER_CRYSTAL_LANCE_DASH, 1)
    end
	end
	if m.actionArg == 1 then
	m.vel.y = 0
    mario_set_forward_vel(m, 0)
	if (m.input & INPUT_A_PRESSED) ~= 0 then
		m.vel.y = 65.0
		set_mario_action(m, ACT_MILNE_WATER_FALLING, 2)
		play_character_sound(m, CHAR_SOUND_HOOHOO)
    end
	if (m.input & INPUT_Z_PRESSED) ~= 0 then
		m.vel.y = -10
		set_mario_action(m, ACT_MILNE_WATER_FALLING, 0)
    end
	end
	m.marioBodyState.handState = MARIO_HAND_PEACE_SIGN
	m.actionTimer = m.actionTimer + 1
	return 0
end

function act_water_crystal_lance_wall(m)
		if (m.flags & MARIO_METAL_CAP) ~= 0 then
			m.health = m.health + 0x100
		end
	m.vel.y = 0
    mario_set_forward_vel(m, 0)
	m.marioBodyState.handState = MARIO_HAND_PEACE_SIGN
	if (m.input & INPUT_A_PRESSED) ~= 0 then
		m.vel.y = 65.0
		set_mario_action(m, ACT_MILNE_WATER_FALLING, 2)
		play_character_sound(m, CHAR_SOUND_HOOHOO)
    end
	if (m.input & INPUT_Z_PRESSED) ~= 0 then
		m.vel.y = -10
		set_mario_action(m, ACT_MILNE_WATER_FALLING, 0)
    end
	return 0
end

hook_mario_action(ACT_MILNE_WATER_FALLING, act_milne_water_falling)
hook_mario_action(ACT_MILNE_WATER_STANDING, act_milne_water_standing)
hook_mario_action(ACT_MILNE_WATER_WALKING, act_milne_water_walking)
hook_mario_action(ACT_WATER_TWISTER_THOK, act_water_twister_thok)
hook_mario_action(ACT_WATER_CRYSTAL_LANCE_DASH, act_water_crystal_lance_dash)
hook_mario_action(ACT_WATER_CRYSTAL_LANCE_START, act_water_crystal_lance_start)