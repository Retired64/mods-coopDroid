-- name: SM64 Peach and the pink star
-- description: Port of SM64 Peach and the pink star by Leonitz
-- incompatible: romhack
gLevelValues.exitCastleLevel = LEVEL_CASTLE_GROUNDS
gLevelValues.exitCastleWarpNode = 0x0A
gLevelValues.coinsRequiredForCoinStar = 50

movtexqc_register('bob_1_Movtex_0',               9, 1, 0)

smlua_audio_utils_replace_sequence(0x03, 0x25, 70, "03_Seq_rom_custom")

function on_level_init()
    local m = gMarioStates[0]
    local np = gNetworkPlayers[0]

    starPositions = gLevelValues.starPositions

    vec3f_set(starPositions.KingBobombStarPos, 3592.0, 2010.0, -785.0)
    vec3f_set(starPositions.TuxieMotherStarPos, -613.0, 750.0, -6318.0)
end

hook_event(HOOK_ON_LEVEL_INIT, on_level_init)