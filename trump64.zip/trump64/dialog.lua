smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, "It makes me so mad! We\
pay your billy and\
your food!\
You guys are\
leeching off of us!\
When Mexico sends\
it's people, they\
aren't sending their\
best!\
Let's make america \
great again!")

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, "Hillary rigged this\
fight!")