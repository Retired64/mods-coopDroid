starPositions = gLevelValues.starPositions
vec3f_set(gLevelValues.starPositions.KingWhompStarPos, -2982, 10110, -10332)