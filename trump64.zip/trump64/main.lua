-- name: Super Trump 64
-- description: Jump the border in this romhack created by Kaze Emanuar\n\Ported by Warioplier\n\Custom player models based on the ones by Enkal, Cjes and FluffaLuigi
-- incompatible: romhack

LEVEL_BORDER = level_register('level_border_entry', COURSE_NONE, 'The Border', 'border', 28000, 0x28, 0x28, 0x28)
gLevelValues.entryLevel = LEVEL_BORDER
gServerSettings.skipIntro = 1

smlua_text_utils_castle_secret_stars_replace("     Defeat Trump!")

smlua_audio_utils_replace_sequence(0x03, 0x25, 75, "mexican_hat_dance") -- SEQ_LEVEL_GRASS
smlua_audio_utils_replace_sequence(0x16, 0x11, 85, "americafuckyeah") -- SEQ_EVENT_BOSS

-- Warp to LEVEL_BORDER
function warp_to_start()
    gMarioStates[0].health = 0x0880
    warp_to_level(LEVEL_BORDER, 1, 0)
end
warp_to_start()

function mario_update(m)
    -- Keep Players in Level
    if gNetworkPlayers[0].currLevelNum ~= LEVEL_BORDER then
        warp_to_start()
    end
end
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_DEATH, warp_to_start)