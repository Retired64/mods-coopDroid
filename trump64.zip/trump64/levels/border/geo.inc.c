#include "levels/border/area_1/geo.inc.c"
