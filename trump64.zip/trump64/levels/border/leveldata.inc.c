#include "levels/border/area_1/collision.inc.c"
#include "levels/border/area_1/macro.inc.c"
#include "levels/border/area_1/spline.inc.c"
#include "levels/border/model.inc.c"
