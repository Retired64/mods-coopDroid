const Collision border_collision[] = {
	COL_INIT(),
	COL_VERTEX_INIT(0),
	COL_TRI_STOP(),
	COL_END()
};
