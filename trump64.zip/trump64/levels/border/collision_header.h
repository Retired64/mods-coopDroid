extern const Collision border_collision[];
