#include <ultra64.h>
#include "sm64.h"
#include "behavior_data.h"
#include "model_ids.h"
#include "seq_ids.h"
#include "dialog_ids.h"
#include "segment_symbols.h"
#include "level_commands.h"

#include "game/level_update.h"

#include "levels/scripts.h"


/* Fast64 begin persistent block [includes] */
/* Fast64 end persistent block [includes] */

#include "make_const_nonconst.h"
#include "levels/border/header.h"

/* Fast64 begin persistent block [scripts] */
/* Fast64 end persistent block [scripts] */

const LevelScript level_border_entry[] = {
	INIT_LEVEL(),
	LOAD_MIO0(0x7, _border_segment_7SegmentRomStart, _border_segment_7SegmentRomEnd), 
	LOAD_MIO0(0xa, _ssl_skybox_mio0SegmentRomStart, _ssl_skybox_mio0SegmentRomEnd), 
	ALLOC_LEVEL_POOL(),
	MARIO(MODEL_MARIO, 0x00000001, bhvMario),
    LOAD_MODEL_FROM_GEO(MODEL_METALLIC_BALL, metallic_ball_geo),
	LOAD_MODEL_FROM_GEO(MODEL_WOODEN_POST, wooden_post_geo),

	/* Fast64 begin persistent block [level commands] */
	/* Fast64 end persistent block [level commands] */

	AREA(1, border_area_1),
		WARP_NODE(241, LEVEL_CASTLE_GROUNDS, 1, 100, WARP_NO_CHECKPOINT),
		WARP_NODE(240, LEVEL_CASTLE_GROUNDS, 1, 100, WARP_NO_CHECKPOINT),
		OBJECT(E_MODEL_CHAIN_CHOMP, -3227, 138, -6311, 0, 0, 0, 0x00000000, id_bhvChainChomp),
		OBJECT(E_MODEL_CHAIN_CHOMP, -3227, 138, -3802, 0, 0, 0, 0x00000000, id_bhvChainChomp),
		OBJECT(E_MODEL_GOOMBA, -2732, 1458, -8928, 0, 0, 0, 0x00000000, id_bhvGoomba),
		OBJECT(E_MODEL_GOOMBA, -3271, 3333, -6917, 0, 0, 0, 0x00000000, id_bhvGoomba),
		OBJECT(E_MODEL_GOOMBA, -3204, 4061, -4215, 0, 0, 0, 0x00000000, id_bhvGoomba),
		OBJECT(E_MODEL_GOOMBA, -3094, 4906, -1210, 0, 0, 0, 0x00000000, id_bhvGoomba),
		OBJECT(E_MODEL_GOOMBA, -3094, 5792, -2223, 0, 0, 0, 0x00000000, id_bhvGoomba),
		OBJECT(E_MODEL_GOOMBA, -3094, 7156, 393, 0, 0, 0, (1 << 16), id_bhvGoomba),
		OBJECT(E_MODEL_GOOMBA, -3094, 9483, -4289, 0, 0, 0, (1 << 16), id_bhvGoomba),
		OBJECT(E_MODEL_HEAVE_HO, -3250, 2543, -8403, 0, 0, 0, 0x00000000, id_bhvHeaveHo),
		OBJECT(E_MODEL_HEAVE_HO, -3250, 4070, -6235, 0, 0, 0, 0x00000000, id_bhvHeaveHo),
		OBJECT(E_MODEL_HEAVE_HO, -3206, 7347, 1770, 0, 0, 0, 0x00000000, id_bhvHeaveHo),
		OBJECT(E_MODEL_HEAVE_HO, -3206, 9879, -6159, 0, 0, 0, 0x00000000, id_bhvHeaveHo),
		OBJECT(E_MODEL_PIRANHA_PLANT, -3169, 1076, -8511, 0, 0, 0, 0x00000000, id_bhvPiranhaPlant),
		OBJECT(E_MODEL_PIRANHA_PLANT, -2217, 2, -4135, 0, 0, 0, 0x00000000, id_bhvPiranhaPlant),
		OBJECT(E_MODEL_PIRANHA_PLANT, -3056, 6915, -1506, 0, 0, 0, 0x00000000, id_bhvPiranhaPlant),
		OBJECT(E_MODEL_PIRANHA_PLANT, -2214, 2, -5577, 0, 0, 0, 0x00000000, id_bhvPiranhaPlant),
		OBJECT(MODEL_NONE, -2781, 1487, -8386, 0, 0, 0, (96 << 16), bhvPoleGrabbing),
		OBJECT(E_MODEL_THWOMP, -3175, 7349, 1385, 0, -179, 0, 0x00000000, id_bhvThwomp),
		OBJECT(E_MODEL_THWOMP, -3206, 7942, 661, 0, 0, 0, 0x00000000, id_bhvThwomp),
		OBJECT(E_MODEL_THWOMP, -3206, 7965, -24, 0, 0, 0, 0x00000000, id_bhvThwomp),
		OBJECT(E_MODEL_THWOMP, -3206, 8185, -601, 0, 0, 0, 0x00000000, id_bhvThwomp),
		OBJECT(E_MODEL_THWOMP, -3206, 8396, -1147, 0, 0, 0, 0x00000000, id_bhvThwomp),
		OBJECT(E_MODEL_THWOMP, -3206, 8407, -1819, 0, 0, 0, 0x00000000, id_bhvThwomp),
		OBJECT(E_MODEL_WHOMP, -3028, 9878, -10451, 0, 0, 0, 0x00000000, id_bhvWhompKingBoss),
		OBJECT(MODEL_NONE, 3912, 111, -1936, 0, 0, 0, 0x000A0000, bhvSpinAirborneWarp),
		MARIO_POS(0x01, 0, 3912, 111, -1936),
		TERRAIN(border_area_1_collision),
		MACRO_OBJECTS(border_area_1_macro_objs),
		SET_BACKGROUND_MUSIC(0x00, SEQ_LEVEL_GRASS),
		TERRAIN_TYPE(TERRAIN_STONE),
		/* Fast64 begin persistent block [area commands] */
		/* Fast64 end persistent block [area commands] */
	END_AREA(),

	FREE_LEVEL_POOL(),
	MARIO_POS(0x01, 0, 3912, 111, -1936),
	CALL(0, lvl_init_or_update),
	CALL_LOOP(1, lvl_init_or_update),
	CLEAR_LEVEL(),
	SLEEP_BEFORE_EXIT(1),
	EXIT(),
};
