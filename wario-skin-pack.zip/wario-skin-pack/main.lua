-- name: \\#ffcc00\\Wario's \\#993399\\Skin Pack\\#dcdcdc\\
-- incompatible: Wario's Skin Pack
-- description: You've had Mario's Skin Pack, you've had Luigi's Skin Pack, now you have Wario's Skin Pack. How much skin packs are there gonna be???

E_MODEL_ERROR_PLAYABLE = smlua_model_util_get_id("playablerror_geo")
E_MODEL_SUPER_WARIO_MAN = smlua_model_util_get_id("superwarioman_geo")
E_MODEL_CHEESY = smlua_model_util_get_id("cheesy_geo")
E_MODEL_NET64 = smlua_model_util_get_id("net64_geo")
E_MODEL_PARTY = smlua_model_util_get_id("party_geo")
E_MODEL_UPDATED = smlua_model_util_get_id("updated_geo")
E_MODEL_ALEX_WARIO = smlua_model_util_get_id("alex_wario_geo")
E_MODEL_LEO_FLAMINGHOTVIDS = smlua_model_util_get_id("leo_flaminghotvids_wario_geo")
E_MODEL_STUPIDMARIOBROS1FAN = smlua_model_util_get_id("stupidmariobros1fan_geo")

local mariowardrobeMode = false

modelSkin = 0

-- Edit these values to add/delete a model --
modelVars = {nil, E_MODEL_SUPER_WARIO_MAN, E_MODEL_CHEESY, E_MODEL_NET64, E_MODEL_PARTY, E_MODEL_UPDATED, E_MODEL_ALEX_WARIO, E_MODEL_LEO_FLAMINGHOTVIDS, E_MODEL_STUPIDMARIOBROS1FAN, E_MODEL_ERROR_PLAYABLE}
modelList = {'Default', 'Super Wario Man v1', 'Cheesy\'s Old Wario', 'Net64 Wario Cousins', 'Mario Party', 'Updated', 'Alex\'s Wario', 'Leo and Flaminghotvids', 'StupidMarioBros1Fan', '?'}
modelCrediting = {'Nintendo', 'AlexXRGames', 'Cheesy/Cheesester', 'Cheesy/Cheesester', '6b', 'Fluffamario', 'AquariusAlexx', 'Leo and Flaminghotvids', 'Steven/StupidMarioBros1Fan', 'Keeberghrh'}

modelSkin_limit = 0
for _ in pairs(modelVars) do modelSkin_limit = modelSkin_limit + 1 end

function da_omm_mode()
    for _,mods in pairs(gActiveMods) do
        if string.find(mods.name, "OMM") then
            return true
        end
    end
    return false
end

if da_omm_mode() then
	djui_popup_create("\\#ffcc00\\Select Wario, Hold R and press D-Pad Down to access the skin menu!", 1)
else
	djui_popup_create("\\#ffcc00\\Select Wario and Press D-Pad Down to access the skin menu!", 1)
end

function mario_update_local(m)
    -- Some Stuff --
    if modelSkin <= -1 then
        modelSkin = modelSkin_limit
    end
    if modelSkin >= modelSkin_limit + 1 then
        modelSkin = 0
    end

    if mariowardrobeMode == true then
        set_mario_animation(m, MARIO_ANIM_STAND_AGAINST_WALL)
    end
    -- Controls --	
	
if da_omm_mode() then
    if mariowardrobeMode == true then
        if (m.controller.buttonPressed & R_JPAD) ~= 0 then
            play_sound(SOUND_MENU_CHANGE_SELECT, m.marioObj.header.gfx.cameraToObject)
            modelSkin = modelSkin + 1
        end
        if (m.controller.buttonPressed & L_JPAD) ~= 0 then
            play_sound(SOUND_MENU_CHANGE_SELECT, m.marioObj.header.gfx.cameraToObject)
            modelSkin = modelSkin - 1
        end
    end
    if ((m.controller.buttonDown & R_TRIG) ~= 0 and (m.controller.buttonPressed & D_JPAD) ~= 0) then
        if mariowardrobeMode == false then
            play_sound(SOUND_MENU_READ_A_SIGN, m.marioObj.header.gfx.cameraToObject)
            mariowardrobeMode = true
            return true
        end
	end
	if (m.controller.buttonPressed & D_JPAD) ~= 0 then
        if mariowardrobeMode == true then
            play_sound(SOUND_MENU_STAR_SOUND_OKEY_DOKEY, m.marioObj.header.gfx.cameraToObject)
            mariowardrobeMode = false
            return true
        end
    end
else
	if mariowardrobeMode == true then
        if (m.controller.buttonPressed & R_JPAD) ~= 0 then
            play_sound(SOUND_MENU_CHANGE_SELECT, m.marioObj.header.gfx.cameraToObject)
            modelSkin = modelSkin + 1
        end
        if (m.controller.buttonPressed & L_JPAD) ~= 0 then
            play_sound(SOUND_MENU_CHANGE_SELECT, m.marioObj.header.gfx.cameraToObject)
            modelSkin = modelSkin - 1
        end
    end
    if (m.controller.buttonPressed & D_JPAD) ~= 0 then
        if mariowardrobeMode == true then
            play_sound(SOUND_MENU_STAR_SOUND_OKEY_DOKEY, m.marioObj.header.gfx.cameraToObject)
            mariowardrobeMode = false
            return true
        end
        if mariowardrobeMode == false then
            play_sound(SOUND_MENU_READ_A_SIGN, m.marioObj.header.gfx.cameraToObject)
            mariowardrobeMode = true
            return true
        end
    end
end

    -- Models --
    gPlayerSyncTable[0].modelId = modelVars[modelSkin + 1]
end

function mario_update(m)
    local p = gNetworkPlayers[m.playerIndex]
    if m.playerIndex == 0 then
		if p.modelIndex == CT_WARIO then
		mario_update_local(m)
		else
		modelSkin = 0
		gPlayerSyncTable[0].modelId = nil
		mariowardrobeMode = false
		end
	end
		if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
        obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
    end
end

function mario_before_phys_step(m)
    if mariowardrobeMode == true then
        m.vel.x = 0
        if m.vel.y > 0 then
            m.vel.y = 0
        end
        m.vel.z = 0
    end
end

function hud_char()
    djui_hud_set_resolution(RESOLUTION_DJUI);
    djui_hud_set_font(FONT_MENU);

    local screenHeight = djui_hud_get_screen_height()
    local screenWidth = djui_hud_get_screen_width()
    local scale = 1
    local tscale = 0.8
    local width = 0
	local cwidth = 0
    local twidth = 0
    local height = 64 * scale
    local theight = 64 * tscale

    if modelSkin >= modelSkin_limit + 1 then
        width = djui_hud_measure_text(modelList[1]) * scale
		cwidth = djui_hud_measure_text(modelCrediting[1]) * scale
    elseif modelSkin <= -1 then
        width = djui_hud_measure_text(modelList[modelSkin_limit + 1]) * scale
		cwidth = djui_hud_measure_text(modelCrediting[modelSkin_limit + 1]) * scale
    else
        width = djui_hud_measure_text(modelList[modelSkin + 1]) * scale
		cwidth = djui_hud_measure_text(modelCrediting[modelSkin + 1]) * scale
    end

    if modelSkin >= modelSkin_limit + 1 then
        twidth = djui_hud_measure_text(modelList[1]) * tscale
    elseif modelSkin <= -1 then
        twidth = djui_hud_measure_text(modelList[modelSkin_limit + 1]) * tscale
    else
        twidth = djui_hud_measure_text(modelList[modelSkin + 1]) * tscale
    end

    local y = (screenHeight / 2) - (height / 2) + 300
	local cy = (screenHeight / 2) - (height / 2) - 300
    local x = (screenWidth / 2) - (width / 2)
	local cx = (screenWidth / 2) - (width / 2)

    local ty = (screenHeight / 2) - (theight / 2) + 300
    local tx = (screenWidth / 2) - (twidth / 2)

    if mariowardrobeMode == true then
        if modelSkin >= modelSkin_limit + 1 then
            djui_hud_print_text(modelList[1], x, y, scale)
			djui_hud_print_text("Made by: "..modelCrediting[1], (djui_hud_get_screen_width() - djui_hud_measure_text("Made by: " .. modelCrediting[1]) * tscale) / 2, cy, tscale)
        elseif modelSkin <= -1 then
            djui_hud_print_text(modelList[modelSkin_limit + 1], x, y, scale)
			djui_hud_print_text("Made by: "..modelCrediting[modelSkin_limit + 1], (djui_hud_get_screen_width() - djui_hud_measure_text("Made by: " .. modelCrediting[modelSkin_limit + 1]) * tscale) / 2, cy, tscale)
        else
            djui_hud_print_text(modelList[modelSkin + 1], x, y, scale)
			djui_hud_print_text("Made by: "..modelCrediting[modelSkin + 1], (djui_hud_get_screen_width() - djui_hud_measure_text("Made by: " .. modelCrediting[modelSkin + 1]) * tscale) / 2, cy, tscale)
        end

        scale = 0.8
        djui_hud_set_color(255,255,255,123)
        if modelSkin + 1 >= modelSkin_limit + 1 then
            djui_hud_print_text(modelList[1], tx + 500, ty, tscale)
        elseif modelSkin + 1 <= -1 then
            djui_hud_print_text(modelList[modelSkin_limit + 1], tx + 500, ty, tscale)
        else
            djui_hud_print_text(modelList[modelSkin + 2], tx + 500, ty, tscale)
        end

        if modelSkin - 1 >= modelSkin_limit + 1 then
            djui_hud_print_text(modelList[1], tx - 500, ty, tscale)
        elseif modelSkin - 1 <= -1 then
            djui_hud_print_text(modelList[modelSkin_limit + 1], tx - 500, ty, tscale)
        else
            djui_hud_print_text(modelList[modelSkin], tx - 500, ty, tscale)
        end
    end
end

function on_hud_render()
    hud_char()
end

hook_event(HOOK_BEFORE_PHYS_STEP, mario_before_phys_step)
--hook_event(HOOK_ON_JOIN, inputshow)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_OBJECT_SET_MODEL, function (o, id)
    if id == E_MODEL_MARIO then
        local i = network_local_index_from_global(o.globalPlayerIndex)
        if gPlayerSyncTable[i].modelId ~= nil then
            obj_set_model_extended(o, gPlayerSyncTable[i].modelId)
        end
    end
end)

local marioskinscons = function(msg)
    djui_chat_message_create("Non recolorable: Star Road, Low Poly Promo, Doll Mario, mayro")
    djui_chat_message_create("Partially recolorable: Elephant (KTK), Elephant (CM9), Goombio, Goombio (N64), SM64DS, Shadow Mario, MX, French Mario, Stanley, Mr. M, Cursed, Retro 2D, Retro Textures, Toadario, Raidenio, Magiorno, Tally Mario, Blue Mario, [[red plumber]]!!, ...tired?, you absolute buffoon, GRAND DAD!, ?")
	djui_chat_message_create("Missing metal recolorability: Star Road, Paisano, Low Poly Promo, Doll Mario, Low Poly, Mr. M, Cursed, Raidenio, Jotario, Magiorno, mayro")
	djui_chat_message_create("Glitchy metal material: Doll Mario")
	djui_chat_message_create("Arena weapon disappearing skins: Beta Mario, Paper, French Mario")
    return true
end

local menuinputs = function(msg)
    if da_omm_mode() then
		djui_chat_message_create("Hold R and press D-Pad Down to access the skin menu! Use D-Pad Left and Right to choose your skin, and then D-Pad down to confirm!")
    return true
	else
		djui_chat_message_create("Press D-Pad Down to access the skin menu! Use D-Pad Left and Right to choose your skin, and then D-Pad down to confirm!")
    return true
  end
end


hook_chat_command('marioskinscons', '- Gives out the issues that each Mario skin has.', marioskinscons)
hook_chat_command('menuinputs', '- Hands instructions on how to use the skin menu.', menuinputs)


--[[Mario Skin Pack - Skin List Credits:

- Fixed Sideburns: baihsense (!)
- Fixed Sideburns: 6b / cheval23
- Star Road: Agent W / woissil
- Beta Mario: Fluffamario & steven3004
- Classic: Ale64 (sup)
- Builder: SGJ4 & MSatiro
- Tuxedo: SuperG64 & MSatiro
- Koopa Shell: baihsense
- Cloud: ImYourCat / ImYourCat
- Elephant (KooptheKoopa): koopthekoopa
- Elephant (CM9): CM9 Animation (!)
- Mario DS: fluffamario
- Mario Party: 6b / cheval23
- Odyssey Recolor: lucho_gamer & ExcellentGamer
- Paisano: 6b / cheval23
- Paper: 6b / cheval23
- Shadow Mario: steven3004
- MX: steven3004
- Movie: Brobgonal Second / brob2nd & LeoHaha
- HD Mario: MSatiro & Arredondo
- Title Screen Head: baihsense & Brobgonal Second / brob2nd
- Render96: Render96 Team (Char, DorfDork, ballz3dfannumber1, Rueven) (!)
- Bradley Render96: Mario / fluffamario & Bradley
- Low Poly Promo: fznmeatpopsicle
- Allergic to Mountains: Tilly & MSatiro
- Jumpman : AlexXRGames & brob2nd
- Stanley: Cheesester & brob2nd
- French Mario: cheval23
- Low Poly: Chilly / chillyzone
- Raiden: sonicdark_
- Cursed: ??? (Deleted User)
- So Retro: aidenwasheere
- Retro 2D: aidenwasheere (!)
- Tire:  AquariusAlexx & brob2nd
- Grand Dad: 6b / cheval23
- Mr. M: Blocky
- Retro Textures: angelicmiracles
- Toadario: AlexXRGames & brob2nd 
- Doll Mario: AlexXRGames
- Mayro: boxshooter
- ERROR: keeberghrh
- Mawio: Napstio & sm64rise & wall_e20 & OWOify Project members
- Cappy: VelipeCrack21YT & LuchoGamer
- Realistic Movie Mario: Furious64 (!)
- Sorio: Napstio (!)
- Oppenhario: Furious64 (!)
- Tallyhall Mario: zanden (!)
- Spamton: BWGLite (!)
- Hatsune Mario: SuperG64 (!)
- Jesusyoshi56's Mario: Jesusyoshi56 & TikalSM64 (!)
- Realistic Mario: Tilly (!)
- Clown Mario: SuperG64 (!)
- Bee Mario: ImYourCat & (???)
- Smoothio Mario: Banty & Smoothio 64 Team (!)
- Super Sonio (Sonic): Lazym12 & Soniceurs & ImYourCat
- Giorno Mario: Napstio (!)
- Jotaro Mario: Napstio (!)
- I.M. Meen Mario: Napstio (!)
- VaniLla96 Mario: Alice♥︎ / lonicth (!)
- Goomba with Cap: MrGameAndSketch (!)
- 64 Goomba with Cap: MrGameAndSketch (!)
- Textureless Anomaly: Ale64 (hello)
- Reloaded / HD: Poke Headroom & GhostlyDark & Render96 Team (shoutouts to Roovahlees for helping me with the credit!) (!)
- Minecraft Mario: kitsufae & cooliokid956
- Headphones / StupidMarioBrosFan1: StupidMarioBrosFan1 & AgentX
- Sunshine Jacket: baihsense (!)
- Super Maria: baihsense (!)
- Google Images: Lucho Gamer
- Boo: MrGameAndSketch (!)
- Retro Textures (Fae): kitsufae

(!): Recolorability by me, Ale64 (or majorly updated)


Voice Credits:

- Beta Mario: Beta Bros. moveset / WB Sound effect library
- Mario DS: Ale64
- Odyssey: Gdark01 / _gdark
- HD Mario: MapMappening on GitHub, ported by me
- French Mario: 6b
- NES Sounds: Ale64
- Spamton: BWGLite
- Sonic: angelicmiracles / Sonic Character: Rebooted
- Goomba: Ale64
- Boo: Ale64
- Mayro: boxshooter--]]