smlua_text_utils_dialog_replace(DIALOG_000,1,5,30,200, ("Finally! Mario was able\
to crack Katze's password\
and print himself\
into real life!\
Wait... where is Katze?\
You hear a loud noise\
from the bathroom.\
Sounds like Katze is\
there. Maybe you should\
go give him a surprise!"))

smlua_text_utils_dialog_replace(DIALOG_001,1,5,95,200, ("I have not eaten a burger\
for 27000 years already\
and I feel hungary.\
Could you go weast\
and get me some?\
I'm picky and only\
eat burgers that are\
delivered in under\
25 seconds."))

smlua_text_utils_dialog_replace(DIALOG_002,1,5,95,200, ("Who the h (hell) put\
this thing (ball) here\
(this location). It's\
right on top of my home\
(giant apartment building).\
And on top of that (quite\
literally so) it stole my\
lunch. Still better than\
living with GMDmom.\
That thing sucks, man."))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("People cannot appreciate\
the beauty of second-hand\
burgers. Even though they\
are cheaper than the ones\
at McDonalds they can\
still be as tasty as\
McDonalds's burgers.\
But no matter what I\
try to tell people, they\
won't try my burgers.\
So I decided to redesign\
their parking lot a little\
bit. Maybe that'll bring\
some people over here.\
\
Anyway try my burgers.\
They're right there on\
the table, one pound each.\
Take a bite,\
I'm sure you'll love them."))

smlua_text_utils_dialog_replace(DIALOG_004,1,7,30,200, ("We're peace-loving\
Bob-ombs, so we don't use\
cannons.\
But if you'd like\
to blast off, we don't\
mind. Help yourself.\
We'll prepare all of the\
cannons in this course for\
you to use. Bon Voyage!"))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, ("Hello Mario!\
You are now obligated\
to take a speed test.\
If you're slower than me\
then you will be arrested\
by the Harm Police.\
Ready....\
\
//Go!////Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_006,1,2,30,200, ("How the fuck did you\
even do that???"))

smlua_text_utils_dialog_replace(DIALOG_007,1,2,30,200, ("Congratulations. You are\
not cringe."))

smlua_text_utils_dialog_replace(DIALOG_008,1,5,30,200, ("Here lies the ghost\
of bad collision.\
Comes back to life\
at the worst times.\
The traitor."))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Long time, no see! Wow,\
have you gotten fast!\
Have you been training\
on the sly, or is it the\
power of the Stars?\
I've been feeling down\
about losing the last\
race. This is my home\
course--how about a\
rematch?\
The goal is in\
Windswept Valley.\
Ready?\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("Wing cap.\
Idk what to write here.\
Send PogChamp in chat\
if you see this.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("You've just stepped on\
the Metal Cap Switch!\
The Metal Cap makes\
Mario invincible.\
Now Metal Caps will\
pop out of all of the\
green blocks you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,6,30,200, ("Vanish Cap.\
Idk what to write here.\
Send MingLee in chat\
if you see this.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("You've collected enough\
coins for a burger!\
That's amazing!\
Do you want to Save?\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Wow! Another Burger!\
The World Record kind\
of burger!\
AlsOb\
Do you want to Save?\
\
//You Bet//Not Now"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("Here lies all the\
attempts that died to\
Katze pressing his\
favourite button in\
situations he thought he\
would benefit from it but\
instead caused him to\
fail miserably.\
Hashtag Stop Pausing"))

smlua_text_utils_dialog_replace(DIALOG_016,1,5,95,200, ("Here lies the attempt\
in Mario Adventure\
where Astaroth did\
the Katze by pressing\
the pause button.\
We will never forget the\
moments we had climbing\
that stupid-ass ship."))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("type something here pls"))

smlua_text_utils_dialog_replace(DIALOG_018,1,7,30,200, ("Due to the coronavirus\
outbreak, please\
remember to keep at least\
2 meters away\
(37.53 eagle beaks) from\
other customers to avoid\
spreading the virus.\
You can also use the\
drive-thru\
(trash container)\
for ordering."))

smlua_text_utils_dialog_replace(DIALOG_019,1,3,95,150, ("Don't enter if you're\
collecting coins for the\
coin burgers!"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("Dear Mario:\
Please come to the\
castle. I've baked\
a cake for you.\
Yours truly--\
Princess Toadstool"))

smlua_text_utils_dialog_replace(DIALOG_021,1,10,30,200, ("1 --- On the right:\
Vanish\
Yoshboi420\
Mosky2000\
InfiniteVoid\
StarrlightSims\
Mintynate\
MattyBuhh\
Irfanziaulla\
PixelSM64 & Normal71\
--- On the left\
Ap616\
Oneeyeddeacon\
TriforceTK\
CartoonBuffoon\
Frameperfection\
Spaceman64\
Luvbaseball58\
Moosesm64"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("Go get burgers and\
beat Asta!!"))

smlua_text_utils_dialog_replace(DIALOG_023,1,5,30,200, ("This key doesn't fit!\
Maybe it's for the\
basement..."))

smlua_text_utils_dialog_replace(DIALOG_024,1,8,95,200, ("You better check out what\
is happening in the \
bathroom before\
going outside.\
Also you need a single\
burger unit of energy\
to open this door anyway\
so go find one somewhere."))

smlua_text_utils_dialog_replace(DIALOG_025,1,3,95,150, ("It takes the power of\
3 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, ("It takes the power of\
8 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_027,1,6,95,200, ("Nope! I don't think you\
have enough burgers\
to get Katze out of the\
toilet yet! It probably\
takes around uhh... hmm\
let's see....\
Somewhere around 30\
burgers maybe? So you'll\
have to get at least [%]\
more of them."))

smlua_text_utils_dialog_replace(DIALOG_028,1,4,95,200, ("You already played\
too many hacks today,\
go workout in the fresh\
air!"))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,30,200, ("Due to the Coronavirus\
outbreak Burger Shop is\
currently closed!\
Please use our drive-thru\
to get burgers!"))

smlua_text_utils_dialog_replace(DIALOG_030,1,9,30,200, ("2 --- On the right\
GmdDoesDMG\
SomeBro\
Trueballer21\
LocaMash\
SirSirSirSirSirSirSirSir\
sizzlingmario4\
Fiery SR\
Kable\
--- On the left\
AndrewSM64\
SheepSquared\
serp\
Bellring\
Benjamin\
FasterSuperSonic\
Pieordie1\
Asbeth"))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("No way! You beat me...\
again!! And I just spent\
my entire savings on\
these new Koopa\
Mach 1 Sprint shoes!\
Here, I guess I have to\
hand over this Star to\
the winner of the race.\
Congrats, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_032,1,10,30,200, ("3 --- On the right\
ShiKiT\
Kimlu\
MXF\
Rambi Rampage &\
TsucnenT\
Scuttlebug Raiser\
Redmat\
MorningStorm\
Yoshistar95\
--- On the left\
StanFuzz\
Mik & Focus SR\
ChrisLink\
Mopplopmopplop\
Gian 97\
Mushie64\
BroDute\
Usernamesarespiders"))

smlua_text_utils_dialog_replace(DIALOG_033,1,10,30,200, ("4 --- On the right\
Majoog\
BjoTos25\
LinCrash\
KazeSM64\
Rawsizer DJ\
Daniel EDC\
ProG64\
SabaJack\
GooseDaJuice\
Sigotu\
Tayyip\
Drunkrazy\
Muimania\
Caasje\
Askary\
Angreifer\
MikkoN64\
\
\
--- On the left\
WWMResident\
KingToad\
GomePlayTV\
Phanton404\
Aglab2\
Badboy\
TheGael95\
Galaxtic\
TheNextGenPlayer\
TheReverserOfTime\
Xalince\
JerodT\
SSBMAstaroth\
MBCollector672\
Tomatobird8 & Katze789\
Molovo\
Dackage"))

smlua_text_utils_dialog_replace(DIALOG_034,1,5,30,200, ("Welcome to Marv's hotel!\
Currently we have no\
rooms left but you are\
still allowed to take a\
look around.\
You can use the elevators\
to get to the upper floors.\
Each elevator gets you to\
a specific floor.\
\
Also, on the left you\
have the hotel owner\
MarvJungs's room and\
on the right the manager\
FrostyZako's room."))

smlua_text_utils_dialog_replace(DIALOG_035,1,8,30,200, ("Look at this. I don't know\
how it's even possible\
for a human body to\
store so much piss in it.\
These guys have been\
here just blasting\
piss at full force\
for days. Apart from the\
smell I guess I can't\
really complain because\
it's really good for my\
entire backyard,\
especially for the farms\
I have here. Speaking of\
which, would you mind\
doing me a small favor?\
I had a bunch of boxes\
piled up near one of my\
tool sheds and yesterday's\
storm blew the boxes\
all over my farms. Or\
maybe the tomato-stealing\
bird knocked them over.\
Ugh, I'll probably\
have to stop farming\
tomatoes at this point...\
Anyway, I need\
those boxes to be removed\
today or half of my crops\
will die."))

smlua_text_utils_dialog_replace(DIALOG_036,1,1,30,200, ("I'm taking a piss!"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("I win! You lose!\
Ha ha ha ha!\
You're no slouch, but I'm\
a better sledder!\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_038,1,1,95,200, ("burger"))

smlua_text_utils_dialog_replace(DIALOG_039,1,6,30,200, ("I love Muimania which\
is why I'm here taking\
care of his backyard\
in my own way with my\
fellow Mario from\
Mario Pissing.\
Here's a question:\
If pee is stored in the\
balls, how big were mine\
before I came here?"))

smlua_text_utils_dialog_replace(DIALOG_040,1,2,30,200, ("He never stopped pissing.\
\
He never pulled his\
pants up either.\
I don't think he'll ever\
stomp on me at this point.\
I know you could\
do it but you shouldn't.\
The ritual must be comp-\
leted by getting stomped\
by the Mario from my\
dimension.\
Only then will social\
media see the truth."))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("Well, you lost. Time\
to report you to the\
Harm Police."))

smlua_text_utils_dialog_replace(DIALOG_042,1,5,30,200, ("Note to self:\
Clean up the red coins\
someone left in the\
rooms on floors 2\
and 4."))

smlua_text_utils_dialog_replace(DIALOG_043,1,3,30,200, ("Oh no! S(t)inky sands\
ahead! Better watch\
your step."))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("Whooo's there? Whooo\
woke me up? It's still\
daylight--I should be\
sleeping!\
\
Hey, as long as I'm\
awake, why not take a\
short flight with me?\
Press and hold [A] to grab\
on. Release [A] to let go.\
I'll take you wherever\
you want to go, as long\
as my wings hold out.\
Watch my shadow, and\
grab on."))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, ("Whew! I'm just about\
flapped out. You should\
lay off the pasta, Mario!\
That's it for now. Press\
[A] to let go. Okay,\
bye byyyyyyeeee!"))

smlua_text_utils_dialog_replace(DIALOG_046,1,1,30,200, ("EEEH"))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Hi! I'll prepare the\
cannon for you!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,1,30,200, ("How"))

smlua_text_utils_dialog_replace(DIALOG_049,1,7,30,200, ("Yes! You did it! The plan\
worked out perfectly.\
Thank you so much\
Mario. Now all I need to\
do is fix this huge leak\
with glue or something\
and also go on a diet\
since I gained a couple\
kilos from eating those\
burgers. I hope Asta has\
now learnt his lesson\
and will just keep\
streaming Mario 64\
hacks like always."))

smlua_text_utils_dialog_replace(DIALOG_050,1,10,30,200, ("Oh no. Asta didn't clean\
his room for 2 years.\
All the crap on the floor\
has caused the bottom\
of the room to smell\
extra bad. Falling down\
there would be a bad\
idea. You can hear Asta\
raging at the top of the\
trash mountain."))

smlua_text_utils_dialog_replace(DIALOG_051,1,2,30,200, ("『It's dark... pitch black...\
\
You're unable to see\
anything...\
Even your own hands right\
in front of your face...\
when suddenly...\
\
...\
\
...\
\
YYYYYEEEEEEEEESSSSSS\
tbYes』\
- A Snippet of Asta's\
TB & Katze fanfic"))

smlua_text_utils_dialog_replace(DIALOG_052,1,6,30,200, ("How did you get up here?\
You must be a skilled\
player! Maybe you should\
challenge yourself and\
try to play through\
something harder!\
Let's see...\
SM64 Trouble Town?\
That's a sweet and\
short hack just like this\
one but gets pretty chal-\
lenging at the end!\
Another Mario Adventure!\
It's a longer hack with\
lots of new and\
interesting challenges that\
get harder\
as you progress.\
Star Revenge 3.9\
A short but very hard\
hack that uses a gimmick\
throughout the whole game\
that is not seen in any\
other hack.\
Or maybe you want\
something easy!\
Try Tomatobird8's\
Single Star Speedruns\
hack or Classic Pack 64.\
\
Or maybe just one\
of the million other\
Star Revenge hacks\
out there (except night\
or remnant of doom!)"))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("Sometimes, if you pass\
through a coin ring or\
find a secret point in a\
course, a red number will\
appear.\
If you trigger five red\
numbers, a secret Star\
will show up."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("Welcome to the snow\
slide! Hop on! To speed\
up, press forward on the\
Control Stick. To slow\
down, pull back."))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("Hey-ey, Mario, buddy,\
howzit goin'? Step right\
up. You look like a fast\
sleddin' kind of guy.\
I know speed when I see\
it, yes siree--I'm the\
world champion sledder,\
you know. Whaddya say?\
How about a race?\
Ready...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("You brrrr-oke my record!\
Unbelievable! I knew\
that you were the coolest.\
Now you've proven\
that you're also the\
fastest!\
I can't award you a gold\
medal, but here, take this\
Star instead. You've\
earned it!"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Egad! My baby!! Have you\
seen my baby??? She's\
the most precious baby in\
the whole wide world.\
(They say she has my\
beak...) I just can't\
remember where I left\
her.\
Let's see...I stopped\
for herring and ice cubes,\
then I...oohh! I just\
don't know!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("You found my precious,\
precious baby! Where\
have you been? How can\
I ever thank you, Mario?\
Oh, I do have this...\
...Star. Here, take it\
with my eternal\
gratitude."))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("That's not my baby! She\
looks nothing like me!\
Her parents must be\
worried sick!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("ATTENTION!\
Read Before Diving In!\
\
\
If you stay under the\
water for too long, you'll\
run out of oxygen.\
\
Return to the surface for\
air or find an air bubble\
or coins to breathe while\
underwater.\
Press [A] to swim. Hold [A]\
to swim slow and steady.\
Tap [A] with smooth timing\
to gain speed.\
Press Up on the\
Control Stick and press [A]\
to dive.\
\
Press Down on the Control\
Stick and press [A] to\
return to the surface.\
\
Hold Down and press [A]\
while on the surface near\
the edge of the water to\
jump out."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("BRRR! Frostbite Danger!\
Do not swim here.\
I'm serious.\
/--The Penguin"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("Hidden inside the green\
block is the amazing\
Metal Cap.\
Wearing it, you won't\
catch fire or be hurt\
by enemy attacks.\
You don't even have to\
breathe while wearing it.\
\
The only problem:\
You can't swim in it."))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("The Vanish Cap is inside\
the blue block. Mr. I.\
will be surprised, since\
you'll be invisible when\
you wear it!\
Even the Big Boo will be\
fooled--and you can walk\
through secret walls, too."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("When you put on the Wing\
Cap that comes from a\
red block, do the Triple\
Jump to soar high into\
the sky.\
Use the Control Stick to\
guide Mario. Pull back to\
to fly up, press forward\
to nose down, and press [Z]\
to land."))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("Swimming Lessons!\
Tap [A] to do the breast\
stroke. If you time the\
taps right, you'll swim\
fast.\
\
Press and hold [A] to do a\
slow, steady flutter kick.\
Press Up on the Control\
Stick to dive, and pull\
back on the stick to head\
for the surface.\
To jump out of the water,\
hold Down on the Control\
Stick, then press [A].\
Easy as pie, right?\
\
\
But remember:\
Mario can't breathe under\
the water! Return to the\
surface for air when the\
Power Meter runs low.\
\
And one last thing: You\
can't open doors that\
are underwater."))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("Mario, it's Peach!\
Please be careful! Bowser\
is so wicked! He will try\
to burn you with his\
horrible flame breath.\
Run around behind and\
grab him by the tail with\
the [B] Button. Once you\
grab hold, swing him\
around in great circles.\
Rotate the Control Stick\
to go faster and faster.\
The faster you swing him,\
the farther he'll fly.\
\
Use the [C] Buttons to look\
around, Mario. You have\
to throw Bowser into one\
of the bombs in the four\
corners.\
Aim well, then press [B]\
again to launch Bowser.\
Good luck, Mario! Our\
fate is in your hands."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("Tough luck, Mario!\
Princess Toadstool isn't\
here...Gwa ha ha!! Go\
ahead--just try to grab\
me by the tail!\
You'll never be able to\
swing ME around! A wimp\
like you won't throw me\
out of here! Never! Ha!"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("It's Lethal Lava Land!\
If you catch fire or fall\
into a pool of flames,\
you'll be hopping mad, but\
don't lose your cool.\
You can still control\
Mario--just try to keep\
calm!"))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("Hello and welcome to my\
mini-ROM hack called\
Super Mario 76 MASHUP\
(Made by PIXELSSM64\
thats right its\
PIXELSM64\
\
\
P I X E L\
S M 6 4\
\
\
There are 1 stars here.\
in. thIs hacCK.\
Credists:\
oreganol levem model\
Normal Y 72\
TomatoBIRD8 for helping\
me to fix my pc when\
i smashed it with a\
hamemr. I cold not have\
made this good hack\
without it.\
other shoutouts:\
\
\
\
toast"))

smlua_text_utils_dialog_replace(DIALOG_070,1,8,30,200, ("Thank you Mario for\
saving my crops!\
Hey, if you ever need\
any of my gardening\
tools you can borrow\
some from my tool\
shed on the side of\
the hill."))

smlua_text_utils_dialog_replace(DIALOG_071,1,1,30,200, ("Praise the pickle gods."))

smlua_text_utils_dialog_replace(DIALOG_072,1,3,30,200, ("Not every model is\
perfect.\
\
But SabaJack still did\
an amazing job with\
this one."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Don't mind me I'm just\
sittin' in the corner\
here hiding absolutely\
nothing."))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("Guest book for visitors\
while we aren't vacant:\
agyrof\
Pluto\
Solo\
ImSilverYay\
MeseInsanity\
Prakxo\
galoomba\
chooch236\
DNVIC\
IcySkid\
soupG\
ShiN3"))

smlua_text_utils_dialog_replace(DIALOG_075,1,3,30,200, ("Hey! You don't belong\
here!\
\
Get out of here and\
be with people that\
value you!"))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting. Oh, by the\
way, look what I found!"))

smlua_text_utils_dialog_replace(DIALOG_077,1,1,30,200, ("Oh wow you did it!"))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("Break open the Blue Coin\
Block by Pounding the\
Ground with the [Z] Button.\
One Blue Coin is worth\
five Yellow Coins.\
But you have to hurry!\
The coins will disappear\
if you're not quick to\
collect them! Too bad."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("Owwwuu! Let me go!\
Uukee-kee! I was only\
teasing! Can't you take\
a joke?\
I'll tell you what, let's\
trade. If you let me go,\
I'll give you something\
really good.\
So, how about it?\
\
//Free him/ Hold on"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("Eeeh hee hee hee!"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("The mystery is of Wet\
or Dry.\
And where does the\
solution lie?\
The city welcomes visitors\
with the depth they bring\
as they enter."))

smlua_text_utils_dialog_replace(DIALOG_082,1,9,30,200, ("AAHHH!!!!\
Wait what??\
How is this even possible?\
How are you here, Mario?\
You found a way to\
print yourself into the\
real world? Huh, I'm\
gonna have to report\
that bug to Kaze.\
Anyway uhh, hi. I'm stuck\
here in the toilet and\
I need to get out of here\
now that I finally have\
some more hacks to play\
after being out of rom-\
hacks for many weeks. How\
did I get stuck in the\
first place? Well, I don't\
know if you saw the\
news but Astaroth has\
gone crazy. It's probably\
related to me being nice\
to him by constantly\
reminding him to finish\
TAIC and making sure\
he knows what his skill\
level is at or something\
like that. Either way\
he came over here while\
I was taking a crap,\
he knocked me out and\
shoved me into here\
without even flushing\
the toilet first.\
It's so gross. But I have\
a plan! Bring me at least\
30 fresh Burgers to\
make me fat enough\
for the toilet to explode\
open. Perfect plan, right?\
No, don't give me the\
ones that are inside my\
house, those have all gone\
bad and I havent gotten\
any new ones for months\
because the competition\
(Spaceman64) got too\
hard to beat and they\
hoarded all the burgers.\
Anyway, 30 fresh\
Burgers, and also go beat\
Asta so he won't do this\
to me again.\
Oh and also, take my\
latest burger. My door\
is very hard to open,\
you'll need at least one\
burger of power to\
open it. This one shouldn't\
be too stale. Here."))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("There's something strange\
about that clock. As you\
jump inside, watch the\
position of the big hand.\
Oh, look what I found!\
Here, Mario, catch!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Yeeoww! Unhand me,\
brute! I'm late, so late,\
I must make haste!\
This shiny thing? Mine!\
It's mine. Finders,\
keepers, losers...\
Late, late, late...\
Ouch! Take it then! A\
gift from Bowser, it was.\
Now let me be! I have a\
date! I cannot be late\
for tea!"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("You don't stand a ghost\
of a chance in this house.\
If you walk out of here,\
you deserve...\
...a Ghoul Medal..."))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("Running around in circles\
makes some bad guys roll\
their eyes."))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("Santa Claus isn't the only\
one who can go down a\
chimney! Come on in!\
/--Cabin Proprietor"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("Work Elevator\
For those who get off\
here: Grab the pole to the\
left and slide carefully\
down."))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("Both ways fraught with\
danger! Watch your feet!\
Those who can't do the\
Long Jump, tsk, tsk. Make\
your way to the right.\
Right: Work Elevator\
/// Cloudy Maze\
Left: Black Hole\
///Underground Lake\
\
Red Circle: Elevator 2\
//// Underground Lake\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("Bwa ha ha ha!\
You've stepped right into\
my trap, just as I knew\
you would! I warn you,\
『Friend,』 watch your\
step!"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("Danger!\
Strong Gusts!\
But the wind makes a\
comfy ride."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("Pestering me again, are\
you, Mario? Can't you see\
that I'm having a merry\
little time, making\
mischief with my minions?\
Now, return those Stars!\
My troops in the walls\
need them! Bwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("Mario! You again! Well\
that's just fine--I've\
been looking for something\
to fry with my fire\
breath!\
Your Star Power is\
useless against me!\
Your friends are all\
trapped within the\
walls...\
And you'll never see the\
Princess again!\
Bwa ha ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("Get a good run up the\
slope! Do you remember\
the Long Jump? Run, press\
[Z], then jump!"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("To read a sign, stand in\
front of it and press [B],\
like you did just now.\
\
When you want to talk to\
a Koopa Troopa or other\
animal, stand right in\
front of it.\
Please recover the Stars\
that were stolen by\
Bowser in this course."))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("The path is narrow here.\
Easy does it! No one is\
allowed on top of the\
mountain!\
And if you know what's\
good for you, you won't\
wake anyone who's\
sleeping!\
Move slowly,\
tread lightly."))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("Don't be a pushover!\
If anyone tries to shove\
you around, push back!\
It's one-on-one, with a\
fiery finish for the loser!"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("Come on in here...\
...heh, heh, heh..."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("Eh he he...\
You're mine, now, hee hee!\
I'll pass right through\
this wall. Can you do\
that? Heh, heh, heh!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("Ukkiki...Wakkiki...kee kee!\
Ha! I snagged it!\
It's mine! Heeheeheeee!"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("Ackk! Let...go...\
You're...choking...me...\
Cough...I've been framed!\
This Cap? Oh, all right,\
take it. It's a cool Cap,\
but I'll give it back.\
I think it looks better on\
me than it does on you,\
though! Eeeee! Kee keee!"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("Pssst! The Boos are super\
shy. If you look them\
in the eyes, they fade\
away, but if you turn\
your back, they reappear.\
It's no use trying to hit\
them when they're fading\
away. Instead, sneak up\
behind them and punch."))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Upon four towers\
one must alight...\
Then at the peak\
shall shine the light..."))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("The shadowy star in front\
of you is a 『Star\
Marker.』 When you collect\
all 8 Red Coins, the Star\
will appear here."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!\
\
You can reach the Star on\
the floating island by\
using the four cannons.\
Use the Control Stick to\
aim, then press [A] to fire.\
\
If you're handy, you can\
grab on to trees or poles\
to land."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("Ghosts...\
...don't...\
...DIE!\
Heh, heh, heh!\
Can you get out of here...\
...alive?"))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("Boooooo-m! Here comes\
the master of mischief,\
the tower of terror,\
the Big Boo!\
Ka ha ha ha..."))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("Ooooo Nooooo!\
Talk about out-of-body\
experiences--my body\
has melted away!\
Have you run in to any\
headhunters lately??\
I could sure use a new\
body!\
Brrr! My face might\
freeze like this!"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("I need a good head on my\
shoulders. Do you know of\
anybody in need of a good\
body? Please! I'll follow\
you if you do!"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Perfect! What a great\
new body! Here--this is a\
present for you. It's sure\
to warm you up."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("Collect as many coins as\
possible! They'll refill\
your Power Meter.\
\
You can check to see how\
many coins you've\
collected in each of the\
15 enemy worlds.\
You can also recover\
power by touching the\
Spinning Heart.\
\
The faster you run\
through the heart, the\
more power you'll recover."))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("There are special Caps in\
the red, green and blue\
blocks. Step on the\
switches in the hidden\
courses to activate the\
Cap Blocks."))

smlua_text_utils_dialog_replace(DIALOG_114,1,6,95,200, ("wait... WHAT ARE YOU\
DOING HERE?!? I don't\
want visitors during tea\
time! Hold on... You must\
be here because of what\
I did, right? HAH!\
Katze deserved it, man.\
He kept bullying me all\
the time for so long, I\
could not take more of\
it from him. So I decided\
to show him who's\
in charge around here.\
I'm not even done yet!\
Soon I'll open the door of\
my room and let the\
smell of my victory take\
over his entire world!\
If you think you're\
here to stop me from\
doing that, you're wrong!\
Prepare to get crushed!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("NOO! My perfect plan\
is ruined! If only I wasn't\
busy eating chocolate I\
would've opened the door\
already... Damn it, man.\
Well, at least you\
pounded me really well,\
Mario. That felt pretty\
good, not gonna ngl."))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Whaaa....Whaaat?\
Can it be that a\
pipsqueak like you has\
defused the Bob-omb\
king????\
You might be fast enough\
to ground me, but you'll\
have to pick up the pace\
if you want to take King\
Bowser by the tail.\
Methinks my troops could\
learn a lesson from you!\
Here is your Star, as I\
promised, Mario.\
\
If you want to see me\
again, select this Star\
from the menu. For now,\
farewell."))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Who...walk...here?\
Who...break...seal?\
Wake..ancient..ones?\
We no like light...\
Rrrrummbbble...\
We no like...intruders!\
Now battle...\
...hand...\
...to...\
...hand!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Grrrrumbbble!\
What...happen?\
We...crushed like pebble.\
You so strong!\
You rule ancient pyramid!\
For today...\
Now, take Star of Power.\
We...sleep...darkness."))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("Grrr! I was a bit\
careless. This is not as I\
had planned...but I still\
hold the power of the\
Stars, and I still have\
Peach.\
Bwa ha ha! You'll get no\
more Stars from me! I'm\
not finished with you yet,\
but I'll let you go for\
now. You'll pay for this...\
later!"))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("Ooowaah! Can it be that\
I've lost??? The power of\
the Stars has failed me...\
this time.\
Consider this a draw.\
Next time, I'll be in\
perfect condition.\
\
Now, if you want to see\
your precious Princess,\
come to the top of the\
tower.\
I'll be waiting!\
Gwa ha ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Nooo! It can't be!\
You've really beaten me,\
Mario?!! I gave those\
troops power, but now\
it's fading away!\
Arrgghh! I can see peace\
returning to the world! I\
can't stand it! Hmmm...\
It's not over yet...\
\
C'mon troops! Let's watch\
the ending together!\
Bwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("The Black Hole\
Right: Work Elevator\
/// Cloudy Maze\
Left: Underground Lake"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("Metal Cavern\
Right: To Waterfall\
Left: Metal Cap Switch"))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("Work Elevator\
Danger!!\
Read instructions\
thoroughly!\
Elevator continues in the\
direction of the arrow\
activated."))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("Hazy Maze-Exit\
Danger! Closed.\
Turn back now."))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("Up: Black Hole\
Right: Work Elevator\
/// Hazy Maze"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Underground Lake\
Right: Metal Cave\
Left: Abandoned Mine\
///(Closed)\
A gentle sea dragon lives\
here. Pound on his back to\
make him lower his head.\
Don't become his lunch."))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("You must fight with\
honor! It is against the\
royal rules to throw the\
king out of the ring!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("Welcome to the Vanish\
Cap Switch Course! All of\
the blue blocks you find\
will become solid once you\
step on the Cap Switch.\
You'll disappear when you\
put on the Vanish Cap, so\
you'll be able to elude\
enemies and walk through\
many things. Try it out!"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("Welcome to the Metal Cap\
Switch Course! Once you\
step on the Cap Switch,\
the green blocks will\
become solid.\
When you turn your body\
into metal with the Metal\
Cap, you can walk\
underwater! Try it!"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("Welcome to the Wing Cap\
Course! Step on the red\
switch at the top of the\
tower, in the center of\
the rainbow ring.\
When you trigger the\
switch, all of the red\
blocks you find will\
become solid.\
\
Try out the Wing Cap! Do\
the Triple Jump to take\
off and press [Z] to land.\
\
\
Pull back on the Control\
Stick to go up and push\
forward to nose down,\
just as you would when\
flying an airplane."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Whoa, Mario, pal, you\
aren't trying to cheat,\
are you? Shortcuts aren't\
allowed.\
Now, I know that you\
know better. You're\
disqualified! Next time,\
play fair!"))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("Am I glad to see you! The\
Princess...and I...and,\
well, everybody...we're all\
trapped inside the castle\
walls.\
\
Bowser has stolen the\
castle's Stars, and he's\
using their power to\
create his own world in\
the paintings and walls.\
\
Please recover the Power\
Stars! As you find them,\
you can use their power\
to open the doors that\
Bowser has sealed.\
\
There are four rooms on\
the first floor. Start in\
the one with the painting\
of Bob-omb inside. It's\
the only room that Bowser\
hasn't sealed.\
When you collect eight\
Power Stars, you'll be\
able to open the door\
with the big star. The\
Princess must be inside!"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("The names of the Stars\
are also hints for\
finding them. They are\
displayed at the beginning\
of each course.\
You can collect the Stars\
in any order. You won't\
find some Stars, enemies\
or items unless you select\
a specific Star.\
After you collect some\
Stars, you can try\
another course.\
We're all waiting for\
your help!"))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("It was Bowser who stole\
the Stars. I saw him with\
my own eyes!\
\
\
He's hidden six Stars in\
each course, but you\
won't find all of them in\
some courses until you\
press the Cap Switches.\
The Stars you've found\
will show on each course's\
starting screen.\
\
\
If you want to see some\
of the enemies you've\
already defeated, select\
the Stars you recovered\
from them."))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("Wow! You've already\
recovered that many\
Stars? Way to go, Mario!\
I'll bet you'll have us out\
of here in no time!\
\
Be careful, though.\
Bowser and his band\
wrote the book on 『bad.』\
Take my advice: When you\
need to recover from\
injuries, collect coins.\
Yellow Coins refill one\
piece of the Power Meter,\
Red Coins refill two\
pieces, and Blue Coins\
refill five.\
\
To make Blue Coins\
appear, pound on Blue\
Coin Blocks.\
\
\
\
Also, if you fall from\
high places, you'll\
minimize damage if you\
Pound the Ground as you\
land."))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("Thanks, Mario! The castle\
is recovering its energy\
as you retrieve Power\
Stars, and you've chased\
Bowser right out of here,\
on to some area ahead.\
Oh, by the by, are you\
collecting coins? Special\
Stars appear when you\
collect 100 coins in each\
of the 15 courses!"))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Down: Underground Lake\
Left: Black Hole\
Right: Hazy Maze (Closed)"))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("Above: Automatic Elevator\
Elevator begins\
automatically and follows\
pre-set course.\
It disappears\
automatically, too."))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("Elevator Area\
Right: Hazy Maze\
/// Entrance\
Left: Black Hole\
///Elevator 1\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_141,1,7,150,200, ("Oh hey, look at that!\
You've got enough\
burgers to get Katze out\
of the toilet! Time to\
beat up Asta so Katze\
will be safe from getting\
stuck there again."))

smlua_text_utils_dialog_replace(DIALOG_142,1,2,150,200, ("Wow! You got all of the\
burgers! Congrats!"))

smlua_text_utils_dialog_replace(DIALOG_143,1,2,150,200, ("this message is not\
supposed to show up"))

smlua_text_utils_dialog_replace(DIALOG_144,1,2,150,200, ("this message is also\
not supposed to show up."))

smlua_text_utils_dialog_replace(DIALOG_145,1,2,150,200, ("how are you getting\
these messages bro"))

smlua_text_utils_dialog_replace(DIALOG_146,1,2,150,200, ("wtf"))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("Are you using the Cap\
Blocks? You really should,\
you know.\
\
\
To make them solid so you\
can break them, you have\
to press the colored Cap\
Switches in the castle's\
hidden courses.\
You'll find the hidden\
courses only after\
regaining some of the\
Power Stars.\
\
The Cap Blocks are a big\
help! Red for the Wing\
Cap, green for the Metal\
Cap, blue for the Vanish\
Cap."))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("Snowman Mountain ahead.\
Keep out! And don't try\
the Triple Jump over the\
ice block shooter.\
\
\
If you fall into the\
freezing pond, your power\
decreases quickly, and\
you won't recover\
automatically.\
//--The Snowman"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("Welcome to\
Princess Toadstool's\
secret slide!\
There's a Star hidden\
here that Bowser couldn't\
find.\
When you slide, press\
forward to speed up,\
pull back to slow down.\
If you slide really\
fast, you'll win the Star!"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("Waaaa! You've flooded my\
house! Wh-why?? Look at\
this mess! What am I\
going to do now?\
\
The ceiling's ruined, the\
floor is soaked...what to\
do, what to do? Huff...\
huff...it makes me so...\
MAD!!!\
Everything's been going\
wrong ever since I got\
this Star...It's so shiny,\
but it makes me feel...\
strange..."))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("I can't take this\
anymore! First you get\
me all wet, then you\
stomp on me!\
Now I'm really, really,\
REALLY mad!\
Waaaaaaaaaaaaaaaaa!!!"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("Owwch! Uncle! Uncle!\
Okay, I give. Take this\
Star!\
Whew! I feel better now.\
I don't really need it\
anymore, anyway--\
I can see the stars\
through my ceiling at\
night.\
They make me feel...\
...peaceful. Please, come\
back and visit anytime."))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("Hey! Who's there?\
What's climbing on me?\
Is it an ice ant?\
A snow flea?\
Whatever it is, it's\
bugging me! I think I'll\
blow it away!"))

smlua_text_utils_dialog_replace(DIALOG_154,1,6,30,200, ("Why are you still\
here? You should go\
get me burgers so that\
I can get out of here.\
Well, now that I think\
of it, I guess\
I could tell you that I\
heard there are 40\
burgers to be collected\
around here. Saw that\
on the news. Now good\
luck on your journey."))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting."))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("The world inside the\
clock is so strange!\
When you jump inside,\
watch the position of\
the big hand!"))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("Watch out! Don't let\
yourself be swallowed by\
quicksand.\
\
\
If you sink into the sand,\
you won't be able to\
jump, and if your head\
goes under, you'll be\
smothered.\
The dark areas are\
bottomless pits."))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("1. If you jump repeatedly\
and time it right, you'll\
jump higher and higher.\
If you run really fast and\
time three jumps right,\
you can do a Triple Jump.\
2. Jump into a solid wall,\
then jump again when you\
hit the wall. You can\
bounce to a higher level\
using this Wall Kick."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("3. If you stop, press [Z]\
to crouch, then jump, you\
can perform a Backward\
Somersault. To do a Long\
Jump, run fast, press [Z],\
then jump."))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("Press [B] while running\
fast to do a Body Slide\
attack. To stand while\
sliding, press [A] or [B]."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("Mario!!!\
It that really you???\
It has been so long since\
our last adventure!\
They told me that I might\
see you if I waited here,\
but I'd just about given\
up hope!\
Is it true? Have you\
really beaten Bowser? And\
restored the Stars to the\
castle?\
And saved the Princess?\
I knew you could do it!\
Now I have a very special\
message for you.\
『Thanks for playing Super\
Mario 64! This is the\
end of the game, but not\
the end of the fun.\
We want you to keep on\
playing, so we have a\
little something for you.\
We hope that you like it!\
Enjoy!!!』\
\
The Super Mario 64 Team"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("No, no, no! Not you\
again! I'm in a great\
hurry, can't you see?\
\
I've no time to squabble\
over Stars. Here, have it.\
I never meant to hide it\
from you...\
It's just that I'm in such\
a rush. That's it, that's\
all. Now, I must be off.\
Owww! Let me go!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Noooo! You've really\
beaten me this time,\
Mario! I can't stand\
losing to you!\
\
My troops...worthless!\
They've turned over all\
the Power Stars! What?!\
There are 120 in all???\
\
Amazing! There were some\
in the castle that I\
missed??!!\
\
\
Now I see peace\
returning to the world...\
Oooo! I really hate that!\
I can't watch--\
I'm outta here!\
Just you wait until next\
time. Until then, keep\
that Control Stick\
smokin'!\
Buwaa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("Mario! What's up, pal?\
I haven't been on the\
slide lately, so I'm out\
of shape.\
Still, I'm always up for a\
good race, especially\
against an old sleddin'\
buddy.\
Whaddya say?\
Ready...set...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I take no responsibility\
whatsoever for those who\
get dizzy and pass out\
from running around\
this post."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("I'll be back soon.\
I'm out training now,\
so come back later.\
//--Koopa the Quick"))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("Princess Toadstool's\
castle is just ahead.\
\
\
Press [A] to jump, [Z] to\
crouch, and [B] to punch,\
read a sign, or grab\
something.\
Press [B] again to throw\
something you're holding."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("Hey! Knock it off! That's\
the second time you've\
nailed me. Now you're\
asking for it, linguine\
breath!"))

smlua_text_utils_dialog_replace(DIALOG_169,1,9,30,200, ("Astaroth has gone insane!\
He released his poop\
balls (mutated goombas)\
into the world and\
threatens to do more\
to get revenge on Katze.\
Uhh yeah that's pretty\
much it. Nothing else on\
the news..."))