-- name: 121rst star
-- description: This mod adds a brand new level hidden somewhere in the castle! it contains 1 star\nThis mod was made by Blo\\#0000ff\\cky

LEVEL_NS = level_register('level_ns_entry', 1, 'Starry Night Sky', 'ns', 28000, 0x28, 0x28, 0x28)

function lvl_init()
    if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE and gNetworkPlayers[0].currAreaIndex == 2 then
        if gMarioStates[0].pos.x == -410 and gMarioStates[0].pos.z <= 1742 and gMarioStates[0].pos.z >= 1410 and gMarioStates[0].pos.y >= 1380 and gMarioStates[0].pos.y <= 1685 and gMarioStates[0].pos.y ~= gMarioStates[0].floorHeight then
            warp_to_level(LEVEL_NS, 1, 1)
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, lvl_init)
