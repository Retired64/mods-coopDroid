-- name: Speedrun Timer V3
-- description: An Update for EmeraldLockdown's timer, but it's spawns on the right place for Vanilla Mario 64, This is Really helpful for people who want to speedrun so No More Cheating! Just Type /start-timer and then you good to go! \n\nTweak by Mr.Needlemouse, Sunk and JairoThePlumber \n\n Bingo Command Mod By Blocky and Skeltan

gGlobalSyncTable.startspeedruntime = 0
gGlobalSyncTable.startspeedrun = 0
gGlobalSyncTable.beatedGame = true
gGlobalSyncTable.startTimer = false
gGlobalSyncTable.stopTimer = false
gGlobalSyncTable.speedrunTimer = false

local startTimer = true
local speedrunTimer = true
local showSpeedrunTimer = true

local startspeedruntime = 4 * 30
local startspeedrun = 0
local showSpeedrunTimer = true

--- @param m MarioState
function mario_update(m)

    if m.playerIndex ~= 0 then return end

    if gGlobalSyncTable.startTimer and network_is_server() then 

        startTimer = true
        gGlobalSyncTable.beatedGame = false
		
		
    end
	
	if not gGlobalSyncTable.startTimer and network_is_server() then 

        stopTimer = true
        gGlobalSyncTable.beatedGame = true
		
    end
			

    if gGlobalSyncTable.startspeedruntime > 0 then
        m.freeze = true
		
if gGlobalSyncTable.startspeedruntime > 0 then
    gMarioStates[0].pos.x = -1328
end
if gGlobalSyncTable.startspeedruntime > 0 then
    gMarioStates[0].pos.y = 260
end
if gGlobalSyncTable.startspeedruntime > 0 then
    gMarioStates[0].pos.z = 4664
end
        m.faceAngle.y = m.intendedYaw
        m.health = 0x880
		end 
    end

function allowinteract()
    if not gGlobalSyncTable.startTimer then
        return false
    end
end

hook_event(HOOK_ALLOW_INTERACT, allowinteract)

function update()
    if network_is_server() then
        if startspeedruntime > 0 and not gGlobalSyncTable.beatedGame then
            startspeedruntime = startspeedruntime - 1
            gGlobalSyncTable.startspeedruntime = startspeedruntime / 30
            gGlobalSyncTable.startspeedrun = 0
            startspeedrun = 0
        else
            if not gGlobalSyncTable.beatedGame then
                startspeedrun = startspeedrun + 1
                gGlobalSyncTable.startspeedrun = startspeedrun
            end
        end
    end
end

function hud_center_render()

    if gGlobalSyncTable.startspeedruntime <= 0 then
        return
    end

    -- set text
    local text = tostring(math.floor(gGlobalSyncTable.startspeedruntime))

    -- set scale
    local scale = 1

    -- get width of screen and text
    local screenWidth = djui_hud_get_screen_width()
    local screenHeight = djui_hud_get_screen_height()
    local width = djui_hud_measure_text(text) * scale
    local height = 32 * scale

    local x = (screenWidth - width) / 2.0
    local y = (screenHeight - height) / 2.0

    -- render
    djui_hud_set_color(0, 0, 0, 128);
    djui_hud_render_rect(x - 6 * scale, y, width + 12 * scale, height);

    djui_hud_set_color(255, 255, 255, 255);
    djui_hud_print_text(text, x, y, scale);
end

function hud_bottom_render()

    if not showSpeedrunTimer then return end

    -- thanks mj for this code
    local minutes = 0
    local Seconds = 0
    local MilliSeconds = 0
    local Hours = 0
    if math.floor(gGlobalSyncTable.startspeedrun/30/60) < 0 then
        Seconds = math.ceil(gGlobalSyncTable.startspeedrun/30)
        MilliSeconds = (1000 - math.ceil(gGlobalSyncTable.startspeedrun/30%1 * 1000)) % 1000
    else
        Hours = math.floor(gGlobalSyncTable.startspeedrun/30/60/60)
        minutes = math.floor(gGlobalSyncTable.startspeedrun/30/60%60)
        Seconds = math.floor(gGlobalSyncTable.startspeedrun/30)%60
        MilliSeconds = math.floor(gGlobalSyncTable.startspeedrun/30%1 * 1000)
    end

    -- set text
    local text = string.format("%s:%s:%s.%s", string.format("%d", Hours), string.format("%02d", minutes), string.format("%02d", Seconds), string.format("%03d", MilliSeconds))

    -- set scale
    local scale = 0.50

    -- get width of screen and text
    local screenWidth = djui_hud_get_screen_width()
    local screenHeight = djui_hud_get_screen_height()
    local width = djui_hud_measure_text(text) * scale

    local x = (screenWidth - width) / 2.0
    local y = screenHeight - 16

    -- render
    djui_hud_set_color(0, 0, 0, 128);
    djui_hud_render_rect(x - 6, y, width + 12, 16);

    djui_hud_set_color(255, 255, 255, 255);
    djui_hud_print_text(text, x, y, scale);
end

function on_render()
    djui_hud_set_font(FONT_NORMAL)
    djui_hud_set_resolution(RESOLUTION_N64)

    hud_center_render()
    hud_bottom_render()
end

---@param m MarioState
---@param o Object
---@param intee InteractionType
---@param interacted any
function on_interact(m, o, intee, interacted)
    if get_id_from_behavior(o.behavior) == id_bhvGrandStar then
        gGlobalSyncTable.beatedGame = true
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_UPDATE, update)
hook_event(HOOK_ON_HUD_RENDER, on_render)
hook_event(HOOK_ON_INTERACT, on_interact)

hook_chat_command('speedrun-timer', '[on|off]Shows the speedrun timer', function (msg)
    if msg == 'on' then
        showSpeedrunTimer = true
        djui_chat_message_create('The Speedrun Timer is now Enabled')
    elseif msg == 'off' then
        showSpeedrunTimer = false
        djui_chat_message_create('The Speedrun Timer is now Disabled')
    else
        djui_chat_message_create('Please enter a valid input')
    end

    return true
end)

function start_timer_command()
    if gGlobalSyncTable.startTimer then
        djui_chat_message_create("\\#ff0000\\The Speedrun is already running!")
        return true
    end
    gGlobalSyncTable.startTimer = true
    return true
end

function stop_timer_command()
	if gGlobalSyncTable.stopTimer then
		djui_chat_message_create("\\#ff0000\\The Speedrun is paused!")
		return true
    end
    gGlobalSyncTable.startTimer = false
    return true
end

-----------
-- hooks --
-----------
if network_is_server() then
    hook_chat_command('start_timer', 'starts the speedrun', start_timer_command)
    hook_chat_command('stop_timer', 'paused the timer', stop_timer_command)
end
