-- name: Change Skybox & Lighting
-- description: Change the lighting and skybox with /lighting_changer.
gGlobalSyncTable.lightingColorR = 255
gGlobalSyncTable.lightingColorG = 255
gGlobalSyncTable.lightingColorB = 255
gGlobalSyncTable.lightingDir0 = 0
gGlobalSyncTable.lightingDir1 = 0
gGlobalSyncTable.lightingDir2 = 0
gGlobalSyncTable.skybox = -1

local function set_lighting()
    set_lighting_color(0, gGlobalSyncTable.lightingColorR)
    set_lighting_color(1, gGlobalSyncTable.lightingColorG)
    set_lighting_color(2, gGlobalSyncTable.lightingColorB)
    set_lighting_dir(0, gGlobalSyncTable.lightingDir0)
    set_lighting_dir(1, gGlobalSyncTable.lightingDir1)
    set_lighting_dir(2, gGlobalSyncTable.lightingDir2)
    set_override_skybox(gGlobalSyncTable.skybox)
end

local function on_packet_receive(dataTable)
    if dataTable.change_lighting then
        set_lighting()
    end
end

local function lighting_changer_command(msg)
    msg = string.lower(msg)
    local args = {}
    for argument in msg:gmatch("%S+") do table.insert(args, argument) end
    if args[1] == "color" then
        if tonumber(args[2]) ~= nil and tonumber(args[3]) ~= nil and tonumber(args[4]) ~= nil then
            gGlobalSyncTable.lightingColorR = tonumber(args[2])
            gGlobalSyncTable.lightingColorG = tonumber(args[3])
            gGlobalSyncTable.lightingColorB = tonumber(args[4])
        else
            djui_chat_message_create("Usage of command: /lighting_changer color R G B")
        end
    elseif args[1] == "direction" then
        if tonumber(args[2]) ~= nil and tonumber(args[3]) ~= nil and tonumber(args[4]) ~= nil then
            gGlobalSyncTable.lightingDir0 = tonumber(args[2])
            gGlobalSyncTable.lightingDir1 = tonumber(args[3])
            gGlobalSyncTable.lightingDir2 = tonumber(args[4])
        else
            djui_chat_message_create("Usage of command: /lighting_changer color number number number")
        end
    elseif args[1] == "skybox" then
        if args[2] ~= nil and _G["BACKGROUND_"..string.upper(args[2])] ~= nil then
            gGlobalSyncTable.skybox = _G["BACKGROUND_"..string.upper(args[2])]
        elseif args[2] == "off" then
            gGlobalSyncTable.skybox = -1
        elseif args[2] == "current" then
            local currentSkybox = get_skybox()
            gGlobalSyncTable.skybox = currentSkybox
        else
            djui_chat_message_create("List of skybox names:\\#00FFFF\\\nABOVE_CLOUDS BELOW_CLOUDS\nCUSTOM DESERT\nFLAMING_SKY GREEN_SKY\nHAUNTED OCEAN_SKY\nPURPLE_SKY SNOW_MOUNTAINS\nUNDERWATER_CITY OFF\nCURRENT")
        end
    end
    set_lighting()
    network_send(true, { change_lighting = true })
    return true
end

hook_event(HOOK_ON_PACKET_RECEIVE, on_packet_receive)
hook_event(HOOK_ON_LEVEL_INIT, set_lighting)
if network_is_server() then
    hook_chat_command("lighting_changer", "[color|direction|skybox]", lighting_changer_command)
end