-- name: King in SM64Ex Co-op V2
-- description: \\#8080E0\\King the Memer\\#dbdbdb\\ is back, with extra skins and a bunch of new additions\n'\\#8080e0\\/king on\\#dbdbdb\\' in chat to activate\n \n\\#8080E0\\Abilities:\\#dbdbdb\\\n(A) midair - Double Jump\n(Z) midair - Bubble Bounce\n(Z) while running - Roll\n(A) while rolling - Long Jump\n(Z) + (B) on ground - Rolldash\n \n\\#8080E0\\Skins:\\#dbdbdb\\\n - King\n - Freezy\n - Billy\n - Sonic\n \nCode - \\#00FFFF\\steven.\\#dbdbdb\\ \\#8080e0\\king the memer\\#dbdbdb\\\nModels - \\#8080e0\\king the memer\\#dbdbdb\\

E_MODEL_W_BALL = smlua_model_util_get_id("woken_ball_geo")
E_MODEL_M_BALL = smlua_model_util_get_id("mario_ball_geo")
E_MODEL_BALL = smlua_model_util_get_id("ball_geo")
E_MODEL_KING = smlua_model_util_get_id("king_geo")
E_MODEL_FREZ = smlua_model_util_get_id("frez_geo")
E_MODEL_BILLY = smlua_model_util_get_id("billy_geo")
E_MODEL_SONIC = smlua_model_util_get_id("sonic_geo")
E_MODEL_WOKEN = smlua_model_util_get_id("woken_geo")
E_MODEL_SONIC_W_CAP = smlua_model_util_get_id("sonic_with_cap_geo")

local king = 0
local woken = 0
local ball = 0
local doubleJump = 0
local doubleShellJump = 0
local doubleHoldJump = 0
local doubleBurnJump = 0
local wardrobeMode = false
local hasGot70Stars = 0
local specialBounce = 0
local JumpSFX = audio_sample_load("Jump.mp3")
local DjumpSFX = audio_sample_load("Djump.mp3")
local SpringSFX = audio_sample_load("Spring.mp3")
local BoingSFX = audio_sample_load("Boing.mp3")
local ChargeSFX = audio_sample_load("Charge.mp3")
local DashSFX = audio_sample_load("Dash.mp3")
local WokenOnSFX = audio_sample_load("WokenOn.mp3")
local WokenOffSFX = audio_sample_load("WokenOff.mp3")

ACT_BOUNCE = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ATTACKING | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_ROLLDASH = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_MOVING | ACT_FLAG_ATTACKING | ACT_FLAG_BUTT_OR_STOMACH_SLIDE)
ACT_WARDROBE = allocate_mario_action(ACT_GROUP_STATIONARY | ACT_FLAG_STATIONARY | ACT_FLAG_IDLE | ACT_FLAG_INVULNERABLE | ACT_FLAG_INTANGIBLE | ACT_FLAG_PAUSE_EXIT)

modelSkin = 0
modelList = {'King', 'Freezy', 'Billy', 'Sonic', 'Woken King', 'None'}
modelSkin_limit = 5

gMarioStateExtras = {}
for i=0,(MAX_PLAYERS-1) do
    gMarioStateExtras[i] = {}
    local m = gMarioStates[i]
    local e = gMarioStateExtras[i]
    e.rotAngle = 0
    e.animFrame = 0
    e.runspeed = 0
    e.lastforwardVel = 0
    e.squishFrame = 0
end

function king_command(msg)
    if msg == 'on' then
        king = 1
        modelSkin = 0
        djui_chat_message_create('no way king in sm64 real')
        djui_chat_message_create('press (L) and use the d-pad to change model')
        return true
    elseif msg == 'off' then
        king = 0
        djui_chat_message_create('no memer?? sad')
        return true
    end
end

function mario_update(m)
    local e = gMarioStateExtras[m.playerIndex]

    if m.playerIndex == 0 then
        mario_update_local(m)
    end

    if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
        obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
    end

    -- woken unlock --

    if m.numStars >= 70 then
        if hasGot70Stars == 0 then
            woken = 1
            djui_chat_message_create('woken king is a playable character now !1 !')
            djui_chat_message_create('activate him by selecting king and pressing d-pad up')
            play_puzzle_jingle()
            hasGot70Stars = 1
        end
    end
end

function mario_update_local(m)
    local e = gMarioStateExtras[m.playerIndex]

    if king == 1 then

    -- sound effects --

        if m.action == ACT_DOUBLE_JUMP or m.action == ACT_WATER_JUMP or m.action == ACT_JUMP_KICK then
            m.actionTimer = m.actionTimer + 1
        end

        if m.actionTimer == 2 then
            if m.action == ACT_JUMP or m.action == ACT_WATER_JUMP or m.action == ACT_METAL_WATER_JUMP or m.action == ACT_TOP_OF_POLE_JUMP then
                audio_sample_play(JumpSFX, m.pos, 1)
            end
            if (m.action == ACT_DOUBLE_JUMP and (m.flags & MARIO_WING_CAP) == 0 and modelSkin ~= 4) then
                audio_sample_play(DjumpSFX, m.pos, 1)
            end
            if m.action == ACT_BURNING_JUMP then
                if doubleBurnJump == 1 then
                    audio_sample_play(DjumpSFX, m.pos, 1)
                else
                    audio_sample_play(JumpSFX, m.pos, 1)
                end
            end
            if m.action == ACT_HOLD_JUMP then
                if doubleHoldJump == 1 then
                    audio_sample_play(DjumpSFX, m.pos, 1)
                else
                    audio_sample_play(JumpSFX, m.pos, 1)
                end
            end
            if m.action == ACT_RIDING_SHELL_JUMP then
                if doubleShellJump == 1 then
                    audio_sample_play(DjumpSFX, m.pos, 1)
                else
                    audio_sample_play(JumpSFX, m.pos, 1)
                end
            end
            if m.action == ACT_DIVE then
                audio_sample_play(SpringSFX, m.pos, 0.5)
            end
            if m.action == ACT_TRIPLE_JUMP then
                audio_sample_play(BoingSFX, m.pos, 1)
            end
            if m.action == ACT_MOVE_PUNCHING or m.action == ACT_JUMP_KICK then
                play_sound(SOUND_ACTION_SPIN, m.marioObj.header.gfx.cameraToObject)
            end
        end

    -- player models --

        if modelSkin <= -1 then
            modelSkin = modelSkin_limit
        end
        if modelSkin >= modelSkin_limit + 1 then
            modelSkin = 0
        end

        if wardrobeMode == true then
            set_mario_action(m, ACT_WARDROBE, 0)
        end

        if wardrobeMode == true then
            if modelSkin ~= 4 then
                if (m.controller.buttonPressed & R_JPAD) ~= 0 then
                    play_sound(SOUND_MENU_CHANGE_SELECT, m.marioObj.header.gfx.cameraToObject)
                    if modelSkin == 3 then
                        modelSkin = modelSkin + 2
                    else
                        modelSkin = modelSkin + 1
                    end
                end
                if (m.controller.buttonPressed & L_JPAD) ~= 0 then
                    play_sound(SOUND_MENU_CHANGE_SELECT, m.marioObj.header.gfx.cameraToObject)
                    if modelSkin == 5 then
                        modelSkin = modelSkin - 2
                    else
                        modelSkin = modelSkin - 1
                    end
                end
            end
            if woken == 1 then
                if modelSkin == 0 then
                    if (m.controller.buttonPressed & U_JPAD) ~= 0 then
                        audio_sample_play(WokenOnSFX, m.pos, 0.5)
                        modelSkin = 4
                    end
                end
                if modelSkin == 4 then
                    if (m.controller.buttonPressed & D_JPAD) ~= 0 then
                        audio_sample_play(WokenOffSFX, m.pos, 0.5)
                        modelSkin = 0
                    end
                end
            end
        end
        if woken == 0 then
            if modelSkin == 4 then
                audio_sample_play(WokenOffSFX, m.pos, 0.5)
                modelSkin = 0
            end
        end
        if (m.controller.buttonPressed & L_TRIG) ~= 0 then
            if wardrobeMode == true then
                play_sound(SOUND_MENU_HAND_DISAPPEAR, m.marioObj.header.gfx.cameraToObject)
                wardrobeMode = false
                return true
            end
            if wardrobeMode == false then
                if (m.action & ACT_FLAG_ALLOW_FIRST_PERSON) ~= 0 then
                    play_sound(SOUND_MENU_HAND_APPEAR, m.marioObj.header.gfx.cameraToObject)
                    wardrobeMode = true
                    return true
                end
            end
        end

        if modelSkin == modelSkin_limit then
            if ball == 0 then
                gPlayerSyncTable[0].modelId = nil
            elseif ball == 1 then
                -- same as regular jumpball but has the --
                -- default metal texture to match mario --
                gPlayerSyncTable[0].modelId = E_MODEL_M_BALL
            end
        else
            if modelSkin == 0 then
                if ball == 0 then
                    gPlayerSyncTable[0].modelId = E_MODEL_KING
                elseif ball == 1 then
                    gPlayerSyncTable[0].modelId = E_MODEL_BALL
                end
            elseif modelSkin == 1 then
                if ball == 0 then
                    gPlayerSyncTable[0].modelId = E_MODEL_FREZ
                elseif ball == 1 then
                    gPlayerSyncTable[0].modelId = E_MODEL_BALL
                end
            elseif modelSkin == 2 then
                if ball == 0 then
                    gPlayerSyncTable[0].modelId = E_MODEL_BILLY
                elseif ball == 1 then
                    gPlayerSyncTable[0].modelId = E_MODEL_BALL
                end
            elseif modelSkin == 3 then
                if ball == 0 then
                    if m.flags ~= m.flags | MARIO_WING_CAP and m.flags ~= m.flags | MARIO_VANISH_CAP and m.flags ~= m.flags | MARIO_METAL_CAP then
                        gPlayerSyncTable[0].modelId = E_MODEL_SONIC
                    elseif m.flags == m.flags | MARIO_WING_CAP or m.flags == m.flags | MARIO_VANISH_CAP or m.flags == m.flags | MARIO_METAL_CAP then
                        gPlayerSyncTable[0].modelId = E_MODEL_SONIC_W_CAP
                    end
                elseif ball == 1 then
                    gPlayerSyncTable[0].modelId = E_MODEL_BALL
                end
            elseif modelSkin == 4 then
                m.health = 0x880
                m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
                if ball == 0 then
                    gPlayerSyncTable[0].modelId = E_MODEL_WOKEN
                elseif ball == 1 then
                    -- same as regular jumpball but is pink --
                    -- to match woken king's regular colors --
                    gPlayerSyncTable[0].modelId = E_MODEL_W_BALL
                end
            end
        end

    -- animations --

        if m.action == ACT_SHOT_FROM_CANNON or m.action == ACT_JUMP or (m.action == ACT_DOUBLE_JUMP and (m.flags & MARIO_WING_CAP) == 0 and modelSkin ~= 4) or m.action == ACT_TRIPLE_JUMP or m.action == ACT_TOP_OF_POLE_JUMP or m.action == ACT_CROUCH_SLIDE or m.action == ACT_METAL_WATER_JUMP or m.action == ACT_WATER_JUMP or m.action == ACT_BURNING_JUMP or m.action == ACT_LONG_JUMP then
            set_mario_animation(m, MARIO_ANIM_FORWARD_SPINNING)
            set_anim_to_frame(m, e.animFrame)
            if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
                e.animFrame = e.animFrame - m.marioObj.header.gfx.animInfo.curAnim.loopEnd
            end
            e.animFrame = e.animFrame + 2
        end

        if m.action == ACT_JUMP_LAND_STOP then
            set_mario_animation(m, MARIO_ANIM_A_POSE)
        end
        
        if m.action == ACT_WALKING then
            if m.forwardVel >= 30 then
                if (m.flags & MARIO_WING_CAP) ~= 0 or modelSkin == 4 then
                    set_mario_animation(m, MARIO_ANIM_WING_CAP_FLY)
                    set_anim_to_frame(m, e.animFrame)
                        if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
                        e.animFrame = e.animFrame - m.marioObj.header.gfx.animInfo.curAnim.loopEnd
                    end
                    e.animFrame = e.animFrame + 2
                    m.marioBodyState.handState = 1
                    m.marioBodyState.torsoAngle.x = 0
                    m.marioObj.header.gfx.pos.y = m.marioObj.header.gfx.pos.y + 50
                end
            end
        end

    -- squish squish --

        if m.action == ACT_BOUNCE then
            m.marioObj.header.gfx.scale.x = m.marioObj.header.gfx.scale.x / 2
            m.marioObj.header.gfx.scale.y = m.marioObj.header.gfx.scale.y * 1.5
            m.marioObj.header.gfx.scale.z = m.marioObj.header.gfx.scale.z / 2
        end

        if m.action == ACT_CROUCHING or m.action == ACT_START_CRAWLING or m.action == ACT_CRAWLING or m.action == ACT_STOP_CRAWLING or m.action == ACT_GROUND_POUND_LAND or m.action == ACT_JUMP_LAND_STOP or m.action == ACT_HOLD_JUMP_LAND_STOP then
            m.marioObj.header.gfx.scale.x = m.marioObj.header.gfx.scale.x * 1.5
            m.marioObj.header.gfx.scale.y = m.marioObj.header.gfx.scale.y / 2
            m.marioObj.header.gfx.scale.z = m.marioObj.header.gfx.scale.z * 1.5
        end

    -- actions that use the jumpball --

        if m.action == ACT_SHOT_FROM_CANNON or m.action == ACT_BOUNCE or m.action == ACT_TOP_OF_POLE_JUMP or m.action == ACT_JUMP_LAND_STOP or m.action == ACT_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_GROUND_POUND_LAND or m.action == ACT_CROUCH_SLIDE or m.action == ACT_WATER_JUMP or m.action == ACT_METAL_WATER_JUMP or m.action == ACT_BURNING_JUMP or m.action == ACT_ROLLDASH or m.action == ACT_LONG_JUMP then
            ball = 1
        else
            ball = 0
        end

    -- actions with smooth turning --

        if m.action == ACT_HANG_MOVING or m.action == ACT_WALKING or m.action == ACT_MOVE_PUNCHING or m.action == ACT_CROUCH_SLIDE or m.action == ACT_TOP_OF_POLE_JUMP or m.action == ACT_CRAWLING or m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_RIDING_SHELL_GROUND or m.action == ACT_RIDING_SHELL_JUMP or m.action == ACT_HOLD_WALKING or m.action == ACT_HOLD_JUMP or m.action == ACT_BURNING_GROUND or m.action == ACT_BURNING_JUMP or m.action == ACT_BURNING_FALL or m.action == ACT_LAVA_BOOST or m.action == ACT_LONG_JUMP or (m.action & ACT_FLAG_METAL_WATER) ~= 0 then
            m.faceAngle.y = m.intendedYaw
        end

        if m.action == ACT_SHOT_FROM_CANNON or m.action == ACT_FREEFALL or m.action == ACT_JUMP_KICK or m.action == ACT_DIVE or m.action == ACT_FORWARD_ROLLOUT or m.action == ACT_BACKWARD_ROLLOUT then
            update_air_with_turn(m)
        end

    -- faster jump landing --

        if m.action == ACT_JUMP_LAND_STOP then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                set_mario_action(m, ACT_IDLE, 0)
            end
        end

        if m.action == ACT_HOLD_JUMP_LAND_STOP then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                set_mario_action(m, ACT_HOLD_IDLE, 0)
            end
        end

    -- bounce landing code --

        if m.action == ACT_GROUND_POUND_LAND then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 2 then
                set_mario_action(m, ACT_TRIPLE_JUMP, 0)
                mario_set_forward_vel(m, e.lastforwardVel)
                if modelSkin == 4 then
                    m.vel.y = m.vel.y * 1.5
                end
            elseif m.actionTimer < 2 then
                set_mario_action(m, ACT_GROUND_POUND_LAND, 99)
            end
        end

    -- double jumping --

        if m.action == ACT_SHOT_FROM_CANNON or m.action == ACT_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_LONG_JUMP or m.action == ACT_BUTT_SLIDE_AIR or m.action == ACT_FREEFALL or m.action == ACT_TOP_OF_POLE_JUMP or m.action == ACT_LAVA_BOOST or m.action == ACT_TWIRLING then
            m.actionTimer = m.actionTimer + 1
            if m.actionTimer > 1 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                if doubleJump == 0 then
                    doubleJump = 1
                    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
                    set_mario_action(m, ACT_DOUBLE_JUMP, 0)
                end
            end
        end

        if m.action == ACT_DOUBLE_JUMP then
            if (m.flags & MARIO_WING_CAP) == 0 and modelSkin ~= 4 then
                ball = 1
            else
                ball = 0
                if (m.controller.buttonDown & A_BUTTON) ~= 0 then
                    m.vel.y = 50
                end
            end
        end

        if doubleJump == 1 then
            if m.action ~= ACT_DOUBLE_JUMP then
                doubleJump = 0
            end
        end

        if m.action == ACT_RIDING_SHELL_JUMP or m.action == ACT_RIDING_SHELL_FALL then
            m.actionTimer = m.actionTimer + 1
            if m.actionTimer > 1 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                if doubleShellJump == 0 then
                    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
                    set_mario_action(m, ACT_RIDING_SHELL_JUMP, 0)
                    doubleShellJump = 1
                end
            end
            if doubleShellJump == 1 then
                if m.actionTimer <= 10 then
                    m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + (m.actionTimer * 6553.6)
                end
            end
        end

        if doubleShellJump == 1 then
            if m.action ~= ACT_RIDING_SHELL_JUMP then
                doubleShellJump = 0
            end
        end

        if m.action == ACT_HOLD_JUMP or m.action == ACT_HOLD_FREEFALL then
            m.actionTimer = m.actionTimer + 1
            if m.actionTimer > 1 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                if doubleHoldJump == 0 then
                    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
                    set_mario_action(m, ACT_HOLD_JUMP, 0)
                    doubleHoldJump = 1
                end
            end
        end

        if doubleHoldJump == 1 then
            if m.action ~= ACT_HOLD_JUMP then
                doubleHoldJump = 0
            end
        end

        if m.action == ACT_BURNING_FALL or m.action == ACT_BURNING_JUMP then
            m.actionTimer = m.actionTimer + 1
            if m.actionTimer > 1 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                if doubleBurnJump == 0 then
                    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
                    set_mario_action(m, ACT_BURNING_JUMP, 0)
                    doubleBurnJump = 1
                end
            end
        end

        if doubleBurnJump == 1 then
            if m.action ~= ACT_BURNING_JUMP then
                doubleBurnJump = 0
            end
        end

        if m.action == ACT_METAL_WATER_JUMP or m.action == ACT_METAL_WATER_FALLING then
            m.actionTimer = m.actionTimer + 1
            if m.actionTimer > 1 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                set_mario_action(m, ACT_METAL_WATER_JUMP, 0)
            end
        end

    -- extra crouch code --

        if m.action == ACT_CROUCHING then
            m.actionTimer = m.actionTimer + 1
            if m.actionTimer > 0 then 
                if (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_JUMP, 0)
                end
                if (m.controller.buttonDown & Z_TRIG) ~= 0 and (m.controller.buttonPressed & B_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_ROLLDASH, 0)
                    audio_sample_play(ChargeSFX, m.pos, 0.5)
                end
            end
        end

    -- extra crouch slide code --

        if m.action == ACT_CROUCH_SLIDE then
            m.actionTimer = m.actionTimer + 1

            e.lastforwardVel = m.forwardVel

            if m.actionTimer > 0 and (m.controller.buttonDown & Z_TRIG) ~= 0 and (m.controller.buttonPressed & B_BUTTON) ~= 0 then
                if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
                    m.particleFlags = m.particleFlags | PARTICLE_VERTICAL_STAR
                    audio_sample_play(DashSFX, m.pos, 1)
                    mario_set_forward_vel(m, m.forwardVel + m.forwardVel)
                else
                    set_mario_action(m, ACT_ROLLDASH, 0)
                end
            end

            if (m.controller.buttonDown & Z_TRIG) == 0 then
                set_mario_action(m, ACT_WALKING, 0)
                m.forwardVel = e.lastforwardVel
            end
        end

    -- extra punching code --

		if m.action == ACT_PUNCHING then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_JUMP, 0)
                end
            end

            if m.actionArg == 6 then
			    return set_mario_action(m, ACT_PUNCHING, 0)
            end
		end

		if m.action == ACT_MOVE_PUNCHING then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_JUMP, 0)
                end
            end

            if m.actionArg == 6 then
			    return set_mario_action(m, ACT_MOVE_PUNCHING, 0)
            end
        end

    -- extra long jump code --

        if m.action == ACT_LONG_JUMP then
            m.actionTimer = m.actionTimer + 1

            m.particleFlags = m.particleFlags | PARTICLE_DUST

            if m.actionTimer == 2 then
                m.particleFlags = m.particleFlags | PARTICLE_VERTICAL_STAR
                audio_sample_play(SpringSFX, m.pos, 0.5)
            end

            if m.actionTimer <= 2 then
                if m.forwardVel < 48 then
                    m.forwardVel = 48
                else
                    m.forwardVel = e.lastforwardVel
                end
                set_mario_y_vel_based_on_fspeed(m, m.vel.y, (10 / m.forwardVel))
            end

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & Z_TRIG) ~= 0 then
                    set_mario_action(m, ACT_GROUND_POUND, 0)
                end
                if (m.controller.buttonPressed & B_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_DIVE, 0)
                end
            end
        end

    -- extra dive code --

        if m.action == ACT_DIVE then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer <= 2 then
                m.faceAngle.y = m.intendedYaw

                if m.vel.y < 25 then
                    m.vel.y = 25
                end

                if m.forwardVel < 10 then
                    m.forwardVel = 10
                end
            end
        end

        if m.action == ACT_DIVE_SLIDE then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & B_BUTTON) ~= 0 or (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                    if m.forwardVel >= 0 then
                        set_mario_action(m, ACT_FORWARD_ROLLOUT, 0)
                    elseif m.forwardVel < 0 then
                        set_mario_action(m, ACT_BACKWARD_ROLLOUT, 0)
                    end
                end
            end
        end

    -- extra butt slide code --

        if m.action == ACT_BUTT_SLIDE then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & A_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_JUMP, 0)
                end
            end
        end

    -- extra tree/pole jump code --

        if m.action == ACT_TOP_OF_POLE_JUMP then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & B_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_DIVE, 0)
                end
                if (m.controller.buttonPressed & Z_TRIG) ~= 0 then
                    set_mario_action(m, ACT_GROUND_POUND, 0)
                end
            end
        end

    -- extra twirling code --

        if m.action == ACT_TWIRLING then
            m.actionTimer = m.actionTimer + 1

            if m.actionTimer > 1 then
                if (m.controller.buttonPressed & B_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_FREEFALL, 0)
                end
                if (m.controller.buttonPressed & Z_TRIG) ~= 0 then
                    set_mario_action(m, ACT_GROUND_POUND, 0)
                end
            end

            if specialBounce == 1 then
                m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
            end
        else
            specialBounce = 0
        end

    -- no more fall damage!1 ! --

        m.peakHeight = m.pos.y

    -- og mario swimming is ass --

        if (m.action & ACT_GROUP_MASK) == ACT_GROUP_SUBMERGED and (m.action & ACT_FLAG_METAL_WATER) == 0 and m.action ~= ACT_BACKWARD_WATER_KB and m.action ~= ACT_FORWARD_WATER_KB and m.action ~= ACT_WATER_PLUNGE then
            m.faceAngle.y = m.faceAngle.y + m.controller.stickX * -20
            if m.controller.stickY ~= 0 then
                if m.faceAngle.x < 15000 and m.faceAngle.x > -15000 then
                    m.faceAngle.x = m.faceAngle.x + m.controller.stickY * -20
                end
            elseif m.faceAngle.x ~= 0 then
                m.faceAngle.x = m.faceAngle.x - (m.faceAngle.x * 0.25)
            end
        end

    -- SOMEONE PLEASE FIND A WAY TO MUTE MARIO IM ACTUALLY DYING --

    else

    -- sets player model to mario --

        gPlayerSyncTable[0].modelId = nil
    end
end

function mario_on_set_action(m)
    if king == 1 then

    -- actions that are set to jump --

        if m.action == ACT_STEEP_JUMP or m.action == ACT_SIDE_FLIP or m.action == ACT_BACKFLIP or (m.action == ACT_DOUBLE_JUMP and doubleJump == 0) then
            return set_mario_action(m, ACT_JUMP, 0)
        end

    -- special bounce jump --

        if m.action == ACT_SPECIAL_TRIPLE_JUMP then
            set_mario_action(m, ACT_TWIRLING, 0)
            audio_sample_play(SpringSFX, m.pos, 0.5)
            specialBounce = 1
            if modelSkin == 4 then
                m.vel.y = 150
            else
                m.vel.y = 100
            end
        end

    -- actions that are set to jump land stop --

        if m.action == ACT_JUMP_LAND or m.action == ACT_DOUBLE_JUMP_LAND or m.action == ACT_TRIPLE_JUMP_LAND or m.action == ACT_LONG_JUMP_LAND or m.action == ACT_FREEFALL_LAND or m.action == ACT_AIR_THROW_LAND or m.action == ACT_TWIRL_LAND then
            return set_mario_action(m, ACT_JUMP_LAND_STOP, 0)
        end

    -- actions that are set to hold jump land stop --

        if m.action == ACT_HOLD_JUMP_LAND or m.action == ACT_HOLD_FREEFALL_LAND then
            return set_mario_action(m, ACT_HOLD_JUMP_LAND_STOP, 0)
        end

    -- fast crouch slide from jump land --

        if m.action == ACT_JUMP_LAND_STOP then
            if (m.controller.buttonDown & Z_TRIG) ~= 0 then
                if m.forwardVel > 0 then
                    set_mario_action(m, ACT_CROUCH_SLIDE, 0)
                else
                    set_mario_action(m, ACT_CROUCHING, 0)
                end
            end
        end

    -- long jump always enabled when crouch sliding --

        if m.action == ACT_JUMP and m.prevAction == ACT_CROUCH_SLIDE then
            set_mario_action(m, ACT_LONG_JUMP, 0)
        end

    -- setting ground pound to bounce --

        if m.action == ACT_GROUND_POUND then
            return set_mario_action(m, ACT_BOUNCE, 0)
        end

    -- fast crouching --

        if m.action == ACT_START_CROUCHING then
            return set_mario_action(m, ACT_CROUCHING, 0)
        end
        if m.action == ACT_STOP_CROUCHING then
            return set_mario_action(m, ACT_IDLE, 0)
        end

    -- instant crawling --

        if m.action == ACT_START_CRAWLING then
            return set_mario_action(m, ACT_CRAWLING, 0)
        end
        if m.action == ACT_STOP_CRAWLING then
            return set_mario_action(m, ACT_CROUCHING, 0)
        end

    -- fast hanging --

        if m.action == ACT_START_HANGING then
            return set_mario_action(m, ACT_HANGING, 0)
        end

    -- actions that are set to crouch sliding/rolldashing --

        if m.action == ACT_SLIDE_KICK or m.action == ACT_SLIDE_KICK_SLIDE or m.action == ACT_SLIDE_KICK_STOP then
            return set_mario_action(m, ACT_CROUCH_SLIDE, 0)
        end

        if (m.action == ACT_MOVE_PUNCHING or m.action == ACT_PUNCHING) and (m.actionArg == 9 or m.prevAction == ACT_CRAWLING) then
            return set_mario_action(m, ACT_ROLLDASH, 0)
        end

    -- why are dive sliding and stomach sliding different actions like what --

        if m.action == ACT_STOMACH_SLIDE then
            return set_mario_action(m, ACT_DIVE_SLIDE, 0)
        end

    -- disable dive from ground --

        if m.action == ACT_DIVE and m.prevAction == ACT_WALKING then
            return set_mario_action(m, ACT_MOVE_PUNCHING, 0)
        end

    -- more controlable jump kick --

        if m.prevAction ~= ACT_WALKING then
            if m.action == ACT_DIVE then
                if (m.controller.buttonDown & A_BUTTON) ~= 0 then
                    set_mario_action(m, ACT_JUMP_KICK, 0)
                end
            end
            if m.action == ACT_JUMP_KICK then
                if (m.controller.buttonDown & A_BUTTON) == 0 then
                    set_mario_action(m, ACT_DIVE, 0)
                end
            end
        end

    -- king is a strong bith --

        if m.action == ACT_HOLD_HEAVY_IDLE then
            return set_mario_action(m, ACT_HOLD_IDLE, 0)
        end

    -- fuck knockback smh --

        if m.action == ACT_HARD_BACKWARD_AIR_KB then
            return set_mario_action(m, ACT_BACKWARD_AIR_KB, 0)
        end
        if m.action == ACT_HARD_FORWARD_AIR_KB then
            return set_mario_action(m, ACT_FORWARD_AIR_KB, 0)
        end
        if m.action == ACT_HARD_BACKWARD_KB then
            return set_mario_action(m, ACT_BACKWARD_KB, 0)
        end
        if m.action == ACT_HARD_FORWARD_KB then
            return set_mario_action(m, ACT_FORWARD_KB, 0)
        end

    -- actions that are set to freefall --

        if m.action == ACT_FLYING or m.action == ACT_BUTT_SLIDE_AIR then
            return set_mario_action(m, ACT_FREEFALL, 0)
        end
    end
end

function mario_before_phys_step(m)
    local e = gMarioStateExtras[m.playerIndex]
    local speed = 1

    if king == 1 then

    -- speed --

        if m.forwardVel > 100 then
            m.forwardVel = 100
        end

        if m.forwardVel < -100 then
            m.forwardVel = -100
        end

    -- actions with increased speed --

        if m.action == ACT_MOVE_PUNCHING or m.action == ACT_JUMP_KICK or m.action == ACT_TOP_OF_POLE_JUMP or m.action == ACT_TWIRLING or m.action == ACT_WALKING or m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_FREEFALL or m.action == ACT_CROUCH_SLIDE or m.action == ACT_HOLD_WALKING or m.action == ACT_HOLD_JUMP or m.action == ACT_BURNING_GROUND or m.action == ACT_BURNING_JUMP or m.action == ACT_BURNING_FALL or m.action == ACT_LAVA_BOOST or m.action == ACT_LONG_JUMP or m.action == ACT_BOUNCE or (m.action & ACT_FLAG_METAL_WATER) ~= 0 then
            if modelSkin == 4 then
                speed = speed * 4
            else
                speed = speed * 2
            end
        end

        if m.action == ACT_SHOT_FROM_CANNON or m.action == ACT_RIDING_SHELL_GROUND or m.action == ACT_RIDING_SHELL_JUMP or m.action == ACT_RIDING_SHELL_FALL or m.action == ACT_DIVE or m.action == ACT_DIVE_SLIDE or m.action == ACT_FORWARD_ROLLOUT or m.action == ACT_BACKWARD_ROLLOUT or m.action == ACT_BUTT_SLIDE or m.action == ACT_WALL_KICK_AIR then
            if modelSkin == 4 then
                speed = speed * 3
            else
                speed = speed * 1.5
            end
        end

    -- swim speed --

        if (m.action & ACT_FLAG_SWIMMING) ~= 0 then
            if m.action ~= ACT_BACKWARD_WATER_KB and m.action ~= ACT_FORWARD_WATER_KB then
                if modelSkin == 4 then
                    speed = speed * 4
                else
                    speed = speed * 2
                end
                if m.action ~= ACT_WATER_PLUNGE then
                    if modelSkin == 4 then
                        m.vel.y = m.vel.y * 4
                    else
                        m.vel.y = m.vel.y * 2
                    end
                end
            end
        end

    -- slow af actions --

        if m.action == ACT_CRAWLING then
            if modelSkin == 4 then
                speed = speed * 10
            else
                speed = speed * 5
            end
        end

    -- running --

        if m.action == ACT_WALKING then
            if m.forwardVel >= 30 then
                if (m.flags & MARIO_WING_CAP) == 0 and modelSkin ~= 4 then
                    m.particleFlags = m.particleFlags | PARTICLE_DUST
                end
            end
        end

    -- keep momentum for certain actions --

        if m.action == ACT_CROUCH_SLIDE or m.action == ACT_MOVE_PUNCHING then
            if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
                if m.forwardVel < 30 and m.forwardVel > 0 then
                    mario_set_forward_vel(m, m.forwardVel * 1.1)
                end
            end
        end

    -- character select --

        if wardrobeMode == true then
            m.vel.x = 0
            if m.vel.y > 0 then
                m.vel.y = 0
            end
            m.vel.z = 0
        end

        m.vel.x = m.vel.x * speed
        m.vel.z = m.vel.z * speed
    end
end

------------------------------------------------
-- bounce edited from steven's sonic char mod --
------------------------------------------------

function act_bounce(m)
    local e = gMarioStateExtras[m.playerIndex]

    update_air_with_turn(m)

    m.actionState = 1

    -- landing code --

    e.lastforwardVel = m.forwardVel * 0.85

    if perform_air_step(m, 0) == AIR_STEP_LANDED then
        set_mario_action(m, ACT_GROUND_POUND_LAND, 0)
        if modelSkin == 4 then
            m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE | PARTICLE_HORIZONTAL_STAR
        else
            m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
        end
    else

    -- main code --

        if modelSkin == 4 then
            m.vel.y = -150
        else
            m.vel.y = -100
        end

        set_mario_animation(m, MARIO_ANIM_FORWARD_SPINNING)
        set_anim_to_frame(m, e.animFrame)
        if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
            e.animFrame = e.animFrame - m.marioObj.header.gfx.animInfo.curAnim.loopEnd
        end
        e.animFrame = e.animFrame + 2

        if m.actionTimer < 1 then
            audio_sample_play(BoingSFX, m.pos, 1)
        end
    end

    -- bounce dive --

    if (m.input & INPUT_B_PRESSED) ~= 0 then
        set_mario_action(m, ACT_DIVE, 0)
    end

    m.actionTimer = m.actionTimer + 1

    return 0
end

function act_rolldash(m)
    local e = gMarioStateExtras[m.playerIndex]
    local rolldashCharge = off
    local rolldashSpeed = 1
    local rolldashAnimSpeed = 0

    m.actionTimer = m.actionTimer + 1

    -- dash speed and charge timer --

    if rolldashCharge == on then
        if m.actionTimer >= 20 then
            rolldashSpeed = 100
        elseif m.actionTimer <= 10 then
            rolldashSpeed = 50
        else
            rolldashSpeed = m.actionTimer * 5
        end
    elseif rolldashCharge == off then
        rolldashSpeed = 1
    end

    -- funi roll animation speed --

    if m.actionTimer > 20 then
        rolldashAnimSpeed = 4
    else
        rolldashAnimSpeed = m.actionTimer * 0.2
    end

    m.actionState = 1

    -- setting the roll animation --

    set_mario_animation(m, MARIO_ANIM_FORWARD_SPINNING)
    set_anim_to_frame(m, e.animFrame)
    if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
        e.animFrame = e.animFrame - m.marioObj.header.gfx.animInfo.curAnim.loopEnd
        play_sound(SOUND_ACTION_SPIN, m.marioObj.header.gfx.cameraToObject)
    end
    e.animFrame = e.animFrame + rolldashAnimSpeed

    m.faceAngle.y = m.intendedYaw
    m.marioObj.header.gfx.angle.y = m.intendedYaw

    -- starts charging a rolldash if ur currently rolldashing too slow --

    if m.forwardVel < 25 then
        m.actionArg = 1
    end

    -- rolldash charging code --

    stationary_ground_step(m)

    if (m.controller.buttonDown & Z_TRIG) ~= 0 and (m.controller.buttonDown & B_BUTTON) ~= 0 then
        rolldashCharge = on
        m.particleFlags = m.particleFlags | PARTICLE_DUST
        mario_set_forward_vel(m, m.forwardVel - (m.forwardVel / 2))
        if m.actionTimer > 1 and (m.controller.buttonPressed & A_BUTTON) ~= 0 then
            set_mario_action(m, ACT_JUMP, 0)
        end
        if m.actionTimer == 2 then
            audio_sample_play(ChargeSFX, m.pos, 0.5)
        end
    elseif (m.controller.buttonDown & Z_TRIG) == 0 or (m.controller.buttonDown & B_BUTTON) == 0 then
        m.particleFlags = m.particleFlags | PARTICLE_VERTICAL_STAR
        audio_sample_play(DashSFX, m.pos, 1)
        set_mario_action(m, ACT_CROUCH_SLIDE, 0)
        mario_set_forward_vel(m, rolldashSpeed)
        rolldashCharge = off
    end

    return 0
end

function act_wardrobe(m)
    local e = gMarioStateExtras[m.playerIndex]

    m.actionState = 1

    m.forwardVel = 0
    m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + 1000
    set_mario_animation(m, MARIO_ANIM_A_POSE)

    if wardrobeMode == false then
        set_mario_action(m, ACT_IDLE, 0)
        m.marioObj.header.gfx.angle.y = m.faceAngle.y
    end

    return 0
end

function hud_char()
    djui_hud_set_resolution(RESOLUTION_DJUI);
    djui_hud_set_font(FONT_MENU);

    local screenHeight = djui_hud_get_screen_height()
    local screenWidth = djui_hud_get_screen_width()
    local scale = 1
    local width = 0
    local height = 64 * scale

    if modelSkin >= modelSkin_limit + 1 then
        width = djui_hud_measure_text(modelList[1]) * scale
    elseif modelSkin <= -1 then
        width = djui_hud_measure_text(modelList[modelSkin_limit + 1]) * scale
    else
        width = djui_hud_measure_text(modelList[modelSkin + 1]) * scale
    end

    local y = (screenHeight / 2) - (height / 2)
    local x = (screenWidth / 2) - (width / 2)

    if wardrobeMode == true then
        if modelSkin >= modelSkin_limit + 1 then
            djui_hud_print_text(modelList[1], x, y + (screenWidth / 5), scale)
        elseif modelSkin <= -1 then
            djui_hud_print_text(modelList[modelSkin_limit + 1], x, y + (screenWidth / 5), scale)
        else
            djui_hud_print_text(modelList[modelSkin + 1], x, y + (screenWidth / 5), scale)
        end
        djui_hud_print_text("Model Select", (screenWidth / 2) - ((djui_hud_measure_text("Model Select") * 1.5) / 2), y - (screenWidth / 5), 1.5)
        if modelSkin ~= 4 then
            djui_hud_print_text("<", ((screenWidth / 2) - ((djui_hud_measure_text("<") * 2) / 2)) - (screenWidth / 3), y, 2)
            djui_hud_print_text(">", ((screenWidth / 2) - ((djui_hud_measure_text("<") * 2) / 2)) + (screenWidth / 3), y, 2)
        end
        if woken == 1 then
            if modelSkin == 0 then
                djui_hud_print_text("^", (screenWidth / 2) - ((djui_hud_measure_text("^") * 2) / 2), y - (screenWidth / 8), 2)
            end
            if modelSkin == 4 then
                djui_hud_print_text("v", (screenWidth / 2) - ((djui_hud_measure_text("v") * 2) / 2), y + (screenWidth / 8), 2)
            end
        end
    end
end

function on_hud_render()
    hud_char()
end

-----------
-- hooks --
-----------
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)
hook_event(HOOK_BEFORE_PHYS_STEP, mario_before_phys_step)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_mario_action(ACT_BOUNCE, act_bounce, INT_GROUND_POUND_OR_TWIRL)
hook_mario_action(ACT_ROLLDASH, act_rolldash)
hook_mario_action(ACT_WARDROBE, act_wardrobe)
hook_chat_command('king', "[on|off]", king_command)