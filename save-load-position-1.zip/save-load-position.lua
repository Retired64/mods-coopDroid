-- name: Save and Load Position
-- description: Press X and Up DPAD to save the position of Mario.\n\nPress X and Down DPAD to teleport Mario to that saved position.\n\nTeleporting Mario will reset the saved position.\n\n\n\nMod by GroovyBeardLover

local save_y = nil
local save_x = nil
local save_z = nil


function save_pos(m)
    if (m.controller.buttonDown & X_BUTTON) ~= 0 and (m.controller.buttonDown & U_JPAD) ~= 0 then
        save_y = m.pos.y
        save_x = m.pos.x
        save_z = m.pos.z
        play_sound(SOUND_GENERAL_GRAND_STAR_JUMP, m.marioObj.header.gfx.cameraToObject)
    end
end

function load_pos(m)
    if (m.controller.buttonDown & X_BUTTON) ~= 0 and (m.controller.buttonDown & D_JPAD) ~= 0 then
        if save_y ~= nil then
            m.pos.y = save_y
            m.pos.x = save_x
            m.pos.z = save_z
            m.particleFlags = PARTICLE_HORIZONTAL_STAR
            play_sound(SOUND_GENERAL_GRAND_STAR, m.marioObj.header.gfx.cameraToObject)
            save_y = nil
            save_x = nil
            save_z = nil
        end
    end
end 

hook_event(HOOK_MARIO_UPDATE, save_pos)
hook_event(HOOK_MARIO_UPDATE, load_pos)