-- name: Progress Pop-ups Lib
-- incompatible: progress_popups
-- description: Version: \\#0FFF3F\\1.0\\#DEDEDE\\\n\nA library allowing the creation of mods to display a pop-up when a player achieves progress. No more guessing what someone just did!\n\nAuthor: \\#FF7F5F\\Altiami

if _G.progressPopupsTamperFlag then
    return
end

local THIS_VERSION = 1

local ERR_MSG_MOD_NAME = "Progress Pop-ups Lib"

local ERR_MSG_PREFIX = "[ERROR] " .. ERR_MSG_MOD_NAME .. ": "

local function print_err_msg(msg)
    if msg then
        msg = ERR_MSG_PREFIX .. msg
    else
        args[1] = msg
    end

    local popupMsgFmt = "[" .. ERR_MSG_MOD_NAME
        .. "]\nSomething went wrong!\nCheck %slog for info!"

    if gNetworkPlayers[0].type == NPT_UNKNOWN then
        --pop-up
        djui_popup_create(string.format(popupMsgFmt, ""), 3)
    else
        --pop-up
        djui_popup_create(string.format(popupMsgFmt, "chat or "), 3)
        --chat
        djui_chat_message_create(msg)
    end
    --log
    print(msg)

    play_sound(SOUND_GENERAL_BOWSER_BOMB_EXPLOSION, {x = 0, y = 0, z = 0})
    play_sound(SOUND_MARIO_DOH, {x = 0, y = 0, z = 0})
end

--fail if another version is already loaded
if _G.progressPopupsLib then
    --wait! Is it tampered?
    if
        type(_G.progressPopupsLib) ~= "table"
        or math.type(_G.progressPopupsLib.VERSION) ~= "integer"
    then
        print_err_msg(
            "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                .. "erroneous mod."
        )
        _G.progressPopupsTamperFlag = true
        return
    end

    print_err_msg(string.format(
        "Cannot load version %d over existing version %s",
        THIS_VERSION,
        _G.progressPopupsLib.VERSION
    ))
    return
end

if _G.progressPopupsLib_load_dependent then
    print_err_msg(
        "A mod has tampered with the Progress Pop-ups dependent loader. Please fix or remove the "
            .. "erroneous mod."
    )
end

local function check_require_table()
    local requireTblCheck = type(_G.progressPopupsLibRequireCallbacks)
    if requireTblCheck == "table" then
        for k, v in ipairs(_G.progressPopupsLibRequireCallbacks) do
            if
                type(v) ~= "table"
                or type(v.dependentID) ~= "string"
                or type(v.callback) ~= "function"
                or type(v.dependencies) ~= "table"
            then
                return false
            end

            for _, dpnd in ipairs(v.dependencies) do
                if type(dpnd) ~= "string" then
                    return false
                end
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireTblCheck ~= "nil" then
        return false
    end

    return true
end

if not check_require_table() then
    --it's been tampered
    print_err_msg(
        "A mod has tampered with the require callback table for the Progress Pop-ups library. "
            .. "Please fix or remove the erroneous mod"
    )
    _G.progressPopupsTamperFlag = true

    return
end

local function check_require_index_LUT()
    local requireIndexLUTCheck = type(_G.progressPopupsLibRequireIndexLUT)
    if requireIndexLUTCheck == "table" then
        for k, v in pairs(_G.progressPopupsLibRequireIndexLUT) do
            if type(k) ~= "string" or math.type(v) ~= "integer" then
                return false
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireIndexLUTCheck ~= "nil" then
        return false
    end

    return true
end

if not check_require_index_LUT() then
    --it's been tampered
    print_err_msg(
        "A mod has tampered with the require index LUT for the Progress Pop-ups library. Please "
            .. "fix or remove the erroneous mod"
    )
    _G.progressPopupsTamperFlag = true

    return
end

--//==================\\
--||CLEAR FOR TAKE-OFF||
--\\==================//

local PROG_POPUP_SYNC_TABLE_PREFIX = "progPopup_"
local PROG_POPUP_SERVER_SETTING_PREFIX = "serverSetting_"

local PROG_STATE_UNINITIALIZED = -2
local PROG_STATE_STANDBY = -1
--local PROG_STATE_DUPE = -1

local PROG_STATE_DEFAULT = network_is_server() and PROG_STATE_STANDBY or PROG_STATE_UNINITIALIZED

local PROG_POPUP_COMMAND_NAME = "progpopup"

local chatCommandColors = {
    fail = "\\#FF3F3F\\",
    success = "\\#00FF00\\",
    positive = "\\#00DFFF\\",
    negative = "\\#FF7F00\\",
    important = "\\#CF3FFF\\",
    myColor = "\\#FF7F5F\\",
    default = "\\#FFFFFF\\"
}

local prefSettingValsLUT = {
    yes = 1,
    y = 1,
    ["true"] = 1,
    t = 1,
    enabled = 1,
    e = 1,
    ["1"] = 1,
    no = 0,
    n = 0,
    ["false"] = 0,
    f = 0,
    disabled = 0,
    di = 0,
    ["0"] = 0,
    server = -1,
    s = -1,
    ["nil"] = -1,
    ni = -1,
    default = -1,
    de = -1,
    ["-1"] = -1
}

local prefSettingReadableLUT = {
    [1] = chatCommandColors.positive .. "enabled",
    [0] = chatCommandColors.negative .. "disabled"
}

--alphabetical-ordered "list" of the subcommands
local progPopupsSubcomAlpha

local progPopupsSubcomLUT = {}

local progPopupsSettingsAlpha

local progPopupsSettings = {}

--where local preferences are stored
local localPrefs = {}

local privateHandlerData = {}

local function str_cmp(s1, s2)
    local len1 = s1:len()
    local len2 = s2:len()
    for i = 1, math.min(len1, len2) do
        local byte1 = s1:byte(i)
        local byte2 = s1:byte(i)
        if byte1 < byte2 then
            return -1
        end
        if byte1 > byte2 then
            return 1
        end
    end

    if len1 < len2 then
        return -1
    end
    if len1 > len2 then
        return 1
    end
    return 0
end

local function insert_alphabetically(list, item)
    for alphIndex, cmp in ipairs(list) do
        if str_cmp(item, cmp) < 0 then
            table.insert(list, alphIndex, item)
            return
        end
    end

    table.insert(list, item)
end

local function make_alphabetized_keys(tbl)
    local alphaKeys = {}
    for subcom, _ in pairs(tbl) do
        insert_alphabetically(alphaKeys, subcom)
    end

    return alphaKeys
end

local function add_prog_popup_subcommand(name, args, shortDesc, fullDesc, func)
    progPopupsSubcomLUT[name] = {
        args = args,
        shortDesc = shortDesc,
        fullDesc = fullDesc,
        func = func
    }
end

local function verify_raw_setting_value(value, validVals)
    return validVals[value]
end

local function add_prog_popup_setting(
    name,
    desc,
    info,
    validVals,
    serverDef,
    defToServerVal,
    readableFromVal
)
    serverDef = serverDef:lower()
    defToServerVal = defToServerVal:lower()

    local tmp = verify_raw_setting_value(serverDef, validVals)
    if not tmp then
        print_err_msg(string.format(
            "Attempt to set server default for setting (%s) to invalid value (%s)",
            name,
            serverDef
        ))
        return
    end
    serverDef = tmp

    tmp = verify_raw_setting_value(defToServerVal, validVals)
    if not tmp then
        print_err_msg(string.format(
            "Attempt to set default-to-server value for setting (%s) to invalid value (%s)",
            name,
            defToServerVal
        ))
        return
    end
    defToServerVal = tmp

    progPopupsSettings[name] = {
        localSet = defToServerVal,
        desc = desc,
        info = info,
        validVals = validVals,
        serverDef = serverDef,
        defToServerVal = defToServerVal,
        readableFromVal = readableFromVal
    }
end

local function make_prog_popup_sync_table_index(index)
    return PROG_POPUP_SYNC_TABLE_PREFIX .. tostring(index)
end

local function make_prog_popup_server_setting_index(index)
    return make_prog_popup_sync_table_index(PROG_POPUP_SERVER_SETTING_PREFIX .. tostring(index))
end

local function get_prog_popup_sync_table_val(index)
    return gGlobalSyncTable[make_prog_popup_sync_table_index(index)]
end

local function set_prog_popup_sync_table(index, value)
    gGlobalSyncTable[make_prog_popup_sync_table_index(index)] = value
end

local function send_prog_popup(index, player)
    set_prog_popup_sync_table(index, player)
end

local function send_dupe_prog_alert(index, player)
    --set_prog_popup_sync_table(index, PROG_STATE_DUPE)
    local sendVal
    if get_prog_popup_sync_table_val(index) < MAX_PLAYERS * 2 then
        sendVal = player + MAX_PLAYERS * 2
    else
        sendVal = player + MAX_PLAYERS
    end
    send_prog_popup(index, sendVal)
end

local function get_prog_popup_server_setting(index)
    return gGlobalSyncTable[make_prog_popup_server_setting_index(index)]
end

local function set_prog_popup_server_setting(index, value)
    gGlobalSyncTable[make_prog_popup_server_setting_index(index)] = value
end

local function get_prog_popup_setting(setting)
    local settingTbl = progPopupsSettings[setting]
    local localVal = settingTbl.localSet

    if localVal == settingTbl.defToServerVal then
        return get_prog_popup_server_setting(setting), true
    end

    return localVal
end

local function protect_dependent_function(callback, relevantID, errMsgFmt, ...)
    local results = {pcall(callback, ...)}

    if not results[1] then
        print_err_msg(string.format(errMsgFmt, relevantID, results[2]))
        return false
    end

    table.remove(results, 1)

    return true, table.unpack(results)
end

local function is_invalid_hook_event(hookEventType)
    return hookEventType < 0 or hookEventType >= HOOK_MAX
end

local function validate_hook_event_table(hookEventType)
    for _, v in ipairs(hookEventType) do
        if is_invalid_hook_event(hookEventType) then
            return false, hookEventType
        end
    end
    return true
end

local function hook_handler_prog_check_callback(
    hookEventType,
    handlerID,
    is_callback_valid,
    make_ID_number_from_callback_info,
    get_player_from_callback_info,
    is_dupe_prog
)
    hook_event(
        hookEventType,
        function(...)
            local callbackArgs, ok, isValid = {hookEventType, ...}

            ok, isValid = protect_dependent_function(
                is_callback_valid,
                handlerID,
                "Function to check callback validity for handler (%s) errored\n%s",
                table.unpack(callbackArgs)
            )
            if not (ok and isValid) then return end

            local progIndex
            if make_ID_number_from_callback_info then
                local progIDNumber
                ok, progIDNumber = protect_dependent_function(
                    make_ID_number_from_callback_info,
                    handlerID,
                    "Function to make an ID number for handler (%s) errored\n%s",
                    table.unpack(callbackArgs)
                )
                if not ok then return end

                local progIDNumber = tonumber(progIDNumber)
                if not progIDNumber or math.type(progIDNumber) ~= "integer" then
                    print_err_msg(string.format(
                        "Function to make ID number for handler (%s) returned non-integer (%s)",
                        handlerID,
                        progIDNumber
                    ))
                    return
                end

                progIndex = handlerID .. progIDNumber
            else
                progIndex = handlerID .. tostring(1)
            end

            local progPlayer
            ok, progPlayer = protect_dependent_function(
                get_player_from_callback_info,
                handlerID,
                "Function to get player for handler (%s) errored\n%s",
                table.unpack(callbackArgs)
            )
            if not ok then return end

            progPlayer = tonumber(progPlayer)
            if not progPlayer or math.type(progPlayer) ~= "integer" then
                print_err_msg(string.format(
                    "Function to get player for handler (%s) returned non-integer (%s)",
                    handlerID,
                    progPlayer
                ))
                return
            end

            if progPlayer < 0 or progPlayer >= MAX_PLAYERS then
                print_err_msg(string.format(
                    "Function to get player for handler (%s) returned out-of-bounds index (%d)",
                    handlerID,
                    progPlayer
                ))
                return
            end

            --always send as if dupe unless it can be detected as not a dupe
            local isDupe = true
            if is_dupe_prog then
                ok, isDupe = protect_dependent_function(
                    is_dupe_prog,
                    handlerID,
                    "Function to check duplicate progress for handler (%s) errored\n%s",
                    table.unpack(callbackArgs)
                )
                if not ok then return end
            end

            if isDupe then
                send_dupe_prog_alert(progIndex, progPlayer)
                return
            end

            send_prog_popup(progIndex, progPlayer)
        end
    )
end

local function set_up_prog_update_callback(
    handlerID,
    idNumber,
    defaultValue,
    make_popup_msg
)
    if idNumber then
        fullID = handlerID .. tostring(idNumber)
    else
        fullID = handlerID
    end

    set_prog_popup_sync_table(fullID, defaultValue)

    hook_on_sync_table_change(
        gGlobalSyncTable,
        make_prog_popup_sync_table_index(fullID),
        fullID,
        function(tag, oldValue, newValue)
            if newValue < 0 then
                --this is just signaling. No pop-up
                return
            end

            if oldValue == newValue then
                --this is either a dupe packet, or someone joined and forced a resync
                return
            end

            --try to get the message ahead of time to check for errors
            local localizedProgressorIndex = network_local_index_from_global(newValue % MAX_PLAYERS)
            local ok, progMsg = protect_dependent_function(
                make_popup_msg,
                handlerID,
                "Function to make pop-up message for handler (%s) errored\n%s",
                gNetworkPlayers[localizedProgressorIndex].name .. "\\#FFFFFF\\",
                network_get_player_text_color_string(localizedProgressorIndex),
                idNumber
            )
            if not ok then return end

            if not progMsg then
                print_err_msg(string.format(
                    "Function to make pop-up message for handler (%s) failed for progress ID "
                        .. "number (%d)",
                    handlerID,
                    idNumber
                ))
                return
            end

            if oldValue == PROG_STATE_UNINITIALIZED then
                --this is just the sync on join. No pop-up
                return
            end

            if
                --if this could have been distinguished as a dupe in the first place
                privateHandlerData[handlerID].canDetectDupes
                --if incoming values suggest this is a dupe
                --and (oldValue == PROG_STATE_DUPE or oldValue >= 0 and newValue >= 0)
                and (newValue >= MAX_PLAYERS or oldValue >= 0)
                --FUTURE: when there's something that uses this
                and get_prog_popup_setting("display_dupes") == 0 --if preference is okay with dupes
            then
                --no dupes
                return
            end

            --don't display local progress unless desired
            if get_prog_popup_setting("display_local") ~= 0 or localizedProgressorIndex ~= 0 then
                --TODO: fit line count to message size
                djui_popup_create(progMsg, 3)
            end
        end
    )
end

local function get_handler(handlerID, errMsgFmt)
    local handlerData = privateHandlerData[handlerID]

    if not handlerData then
        print_err_msg(string.format(errMsgFmt, handlerID))
        return
    end

    return handlerData
end

local progPopupsLib = {
    --the version, used to inform error reports for duplicate loads
    VERSION = THIS_VERSION
}

--adds a handler according to the given arguments
function progPopupsLib.add_prog_popup_handler(
    --how the system identifies this handler.
    --part of building full ID for the progress table.

    --NOTE: IDs which are already in use will be rejected.
    handlerID,

    --how many values are needed for this handler.
    --IDs stored are `id .. tostring(n)` where `n` is 1 through `count`.
    count,

    --which event to use to know when progress might have been made.
    --can be a single hook event, or an array-like table for multiple.

    --NOTE: all handler functions called upon hook callback start with the hook event constant
    --    that fired, followed by the standard arguments for the hook callback, i.e. if
    --    HOOK_MARIO_UPDATE is used, then the handler function arguments will be
    --    (HOOK_MARIO_UPDATE, mario).
    hookEventType,

    --called upon hook callback to know if progress is relevant at all.
    --arguments depend on the hook event type (see `hookEventType`).
    --return `true` if the progress is relevant, or `false` otherwise.
    is_callback_valid,

    --called upon hook callback to get the number for the full progress table ID.
    --for example, to identify a Power Star, you'd return a number between 1 and 120.
    --make sure the number is the same for the same progress!
    --this IS NOT called if `count` is 1.
    --arguments depend on the hook event type (see `hookEventType`).
    --return a number between 1 and `count`.
    make_ID_number_from_callback_info,

    --called upon hook callback to get the global index of the player that achieved progress.
    --arguments depend on the hook event type (see `hookEventType`).
    --return a number between 1 and `MAX_PLAYERS`.
    get_player_from_callback_info,

    --called upon hook callback to know if progress is a duplicate.
    --progress is a duplicate if progress would have been achieved if it wasn't already
    --    achieved.
    --this function determines if a message will display even if the progress was already
    --    achieved.
    --if it is not possible to detect duplicates, leave this as nil
    --arguments depend on the hook event type (see `hookEventType`).
    --return `true` if the progress is a duplicate, or `false` otherwise.
    --in the case where it is sometimes possible to detect duplicates, but not always, treat it as
    --    it isn't possible at all. This is to reduce confusion on the user's end.
    is_dupe_prog,

    --called when a pop-up message for this progress needs to be made.
    --arguments:
    --    playerName: the name of the player who achieved the progress.
    --                the end of the name has a color command to reset the text color in case the
    --                    player name itself uses color commands.
    --    playerColor: the color normally used for the player name
    --    idNumber: the number part of the ID indicating which progress this is.
    --return a string to use as the pop-up message, or nil if there was an error.
    --progress pop-ups allow up to three lines, so make sure the message fits!
    --please return nil for an error so that an error message is displayed for all players
    --    regardless of pop-up display preferences.
    make_popup_msg,

    --a function to be used to modify values for the handler.
    --this function is not used by the library.
    --instead, it is exposed so that handler values can be changed by additional packs.
    --for example, a pack could rename a Power Star for a given ID number.
    --there are no restrictions; arguments, return values, etc. are implementation-defined.
    change_handler_data
)
    --//=====================\\
    --||ARGUMENT SANITIZATION||
    --\\=====================//

    handlerID = tostring(handlerID)

    if math.type(count) ~= "integer" then
        print_err_msg(
            string.format("Attempt to add handler with non-integer count (%s)", count)
        )
        return false
    end

    if count < 1 then
        print_err_msg(
            string.format("Attempt to add handler with non-positive count (%d)", count)
        )
        return false
    end

    if privateHandlerData[handlerID] then
        print_err_msg(
            string.format("Attempt to add handler with ID already in use (%s)", handlerID)
        )
        return false
    end

    if type(hookEventType) == "table" then
        local ok, badHook = validate_hook_event_table(hookEventType)
        if not ok then
            print_err_msg(string.format(
                "Attempt to add handler with a hook event table containing an invalid event "
                    .. "(%d)",
                badHook
            ))
            return false
        end
    elseif math.type(hookEventType) == "integer" then
        if is_invalid_hook_event(hookEventType) then
            print_err_msg(string.format(
                "Attempt to add handler with an invalid hook event constant (%d)",
                hookEventType
            ))
            return false
        end
    else
        print_err_msg(string.format(
            "Attempt to add handler without a hook event constant or table (%s)",
            hookEventType
        ))
        return false
    end

    if type(is_callback_valid) ~= "function" then
        print_err_msg(string.format(
            "Attempt to add handler with non-function value for validation callback (%s)",
            is_callback_valid
        ))
        return false
    end

    if count > 1 then
        if type(make_ID_number_from_callback_info) ~= "function" then
            print_err_msg(string.format(
                "Attempt to add handler for multiple values with non-function value for making an "
                    .. "ID number (%s)",
                make_ID_number_from_callback_info
            ))
            return false
        end
    elseif make_ID_number_from_callback_info ~= nil then
        print_err_msg(string.format(
            "Attempt to add handler for one value with function for making an ID number (%s)",
            make_ID_number_from_callback_info
        ))
        return false
    end

    if type(get_player_from_callback_info) ~= "function" then
        print_err_msg(string.format(
            "Attempt to add handler with non-function value for getting a player (%s)",
            get_player_from_callback_info
        ))
        return false
    end

    if is_dupe_prog and type(is_dupe_prog) ~= "function" then
        print_err_msg(string.format(
            "Attempt to add handler with non-function value for duplicate checker (%s)",
            is_dupe_prog
        ))
        return false
    end

    if type(make_popup_msg) ~= "function" then
        print_err_msg(string.format(
            "Attempt to add handler with non-function value for making a pop-up message (%s)",
            make_popup_msg
        ))
        return false
    end

    if change_handler_data and type(change_handler_data) ~= "function" then
        print_err_msg(string.format(
            "Attempt to add handler with non-function value for setting handler data (%s)",
            change_handler_data
        ))
        return false
    end

    --//=========================\\
    --||END ARGUMENT SANITIZATION||
    --\\=========================//

    --hook sync table updates
    local function hook_new_prog_update_callback(idNumber)
        set_up_prog_update_callback(handlerID, idNumber, PROG_STATE_DEFAULT, make_popup_msg)
    end

    for i = 1, count do
        hook_new_prog_update_callback(i)
    end

    --hook onto general hook events
    local hookArgs = {
        handlerID,
        is_callback_valid,
        make_ID_number_from_callback_info,
        get_player_from_callback_info,
        is_dupe_prog
    }
    if type(hookEventType) == "table" then
        for _, v in ipairs(hookEventType) do
            hook_handler_prog_check_callback(v, table.unpack(hookArgs))
        end
    else
        hook_handler_prog_check_callback(hookEventType, table.unpack(hookArgs))
    end

    --add private data
    local canDetectDupes = is_dupe_prog ~= nil
    privateHandlerData[handlerID] = {
        count = count,
        change_handler_data = change_handler_data,

        canDetectDupes = canDetectDupes,
        canToggleDupeChecks = canDetectDupes,
        hook_new_prog_update_callback = hook_new_prog_update_callback
    }

    --report success
    return true
end

--requests to change the handler according to the arguments given
--the arguments required depend on the implementation of `change_handler_data` for the handler
function progPopupsLib.change_handler_data(handlerID, ...)
    local handlerData = get_handler(
        handlerID,
        "Attempt to change data for handler (%s) that does not exist"
    )
    if not handlerData then
        return
    end

    local change_data_func = handlerData.change_handler_data
    if not handlerData.change_handler_data then
        print_err_msg(string.format(
            "Attempt to change data for handler (%s) that has no function for such",
            handlerID
        ))
        return
    end

    local results = {protect_dependent_function(
        change_data_func,
        handlerID,
        "Function to change data for handler (%s) errored\n%s",
        ...
    )}
    if not results[1] then
        return
    end

    table.remove(results, 1)
    return table.unpack(results)
end

--adds more values for the handler to use for sync hooks
--if the value is not greater than the current count, then nothing happens
function progPopupsLib.reallocate_handler_count(handlerID, newCount)
    local handlerData = get_handler(
        handlerID,
        "Attempt to reallocate count for handler (%s) that does not exist"
    )
    if not handlerData then
        return
    end

    if math.type(newCount) ~= "integer" then
        print_err_msg(string.format(
            "Attempt to reallocate count for handler (%s) with non-integer count (%s)",
            handlerID,
            newCount
        ))
    end

    if newCount <= 1 then
        print_err_msg(string.format(
            "Attempt to reallocate count for handler (%s) with unreasonable count (%d)",
            handlerID,
            newCount
        ))
    end

    local curCount = handlerData.count
    if newCount <= curCount then
        return --lol, why?
    end

    for i = curCount, newCount do
        handlerData.hook_new_prog_update_callback(i)
    end

    handlerData.count = newCount
end

--enable and disable for checking dupes, regardless of if a function for it exists
--meant for use if, for whatever reason, changing the handler makes it impossible to check for dupes
function progPopupsLib.enable_handler_dupe_checking(handlerID)
    local handlerData = get_handler(
        handlerID,
        "Attempt to enable duplicate progress checking for handler (%s) that does not exist"
    )
    if not handlerData then
        return
    end

    if not handlerData.canToggleDupeChecks then
        print_err_msg(string.format(
            "Attempt to enable duplicate progress checking for handler (%s) with no function for "
                .. "such",
            handlerID
        ))
        return
    end

    handlerData.canDetectDupes = true
end

function progPopupsLib.disable_handler_dupe_checking(handlerID)
    local handlerData = get_handler(
        handlerID,
        "Attempt to disable duplicate progress checking for handler (%s) that does not exist"
    )
    if not handlerData then
        return
    end

    if not handlerData.canToggleDupeChecks then
        print_err_msg(string.format(
            "Attempt to disable duplicate progress checking for handler (%s) with no function for "
                .. "such",
            handlerID
        ))
        return
    end

    handlerData.canDetectDupes = false
end

--store globally so packs and updated libs can access
--READ-ONLY
progPopupsLib.__index = progPopupsLib

function progPopupsLib.__newindex(tbl, key, value)
    print_err_msg(string.format(
        "A mod attempted to directly modify the Progress Pop-ups Library (key %s, value %s)",
        key,
        value
    ))
end

_G.progressPopupsLib = {}
setmetatable(_G.progressPopupsLib, progPopupsLib)

--//=============\\
--||CHAT COMMANDS||
--\\=============//

add_prog_popup_setting(
    "display_local",
    "Display local progress pop-ups.",
    "When a player achieves progress, this setting decides if that player sees their own pop-up.\n"
        .. "Valid new values are:\n"
        .. " * Yes (Y, True, T, Enabled, E, 1)\n"
        .. " * No (N, False, F, Disabled, Di, 0)\n"
        .. " * Server (S, Nil, Ni, Default, De, -1)\n"
        .. "Character case does not matter.\n"
        .. "The Server value and its aliases indicate no personal preference, defaulting to the "
            .. "server's default.",
    prefSettingValsLUT,
    "No",
    "Server",
    prefSettingReadableLUT
)

--FUTURE: for when there's something that can follow this rule
add_prog_popup_setting(
    "display_dupes",
    "Display suplicate progress pop-ups.",
    "Some actions that achieve progress can be done repeatedly. Progress Pop-ups always sends a "
            .. "pop-up even when these actions would no longer achieve progress, thus being "
            .. "\"duplicate progress\".\n"
        .. "This setting decides if pop-ups sent for duplicate progress will still display.\n"
        .. "Not all progress pop-up handlers can tell if an action is for duplicate progress. A "
            .. "pop-up will always display for these, no matter what this setting is set to.\n"
        .. "Valid new values are:\n"
        .. " * Yes (Y, True, T, Enabled, E, 1)\n"
        .. " * No (N, False, F, Disabled, Di, 0)\n"
        .. " * Server (S, Nil, Ni, Default, De, -1)\n"
        .. "Character case does not matter.\n"
        .. "The Server value and its aliases indicate no personal preference, defaulting to the "
            .. "server's default.",
    prefSettingValsLUT,
    "No",
    "Server",
    prefSettingReadableLUT
)

--setup the server settings
for k, v in pairs(progPopupsSettings) do
    set_prog_popup_server_setting(k, v.serverDef)
end

local function is_host(action)
    if not network_is_server() then
        djui_chat_message_create(string.format(
            chatCommandColors.fail .. "You must be the " .. chatCommandColors.important .. "host"
                .. chatCommandColors.fail " in order to %s.",
            action
        ))
        return false
    end

    return true
end

local function get_trim_desc_end_index(desc, start, ending)
    local newEnd = ending

    --ensure we're not in a DJUI escape sequence
    local matches = {}
    for match in desc:sub(start, newEnd + 1):gmatch("()\\") do
        table.insert(matches, match)
    end
    if #matches & 1 == 1 then
        --odd number of backslashes means this is inside of a DJUI escape sequence
        newEnd = matches[#matches] - 1
    end

    if newEnd < start then
        return ending
    end

    local match = desc:sub(start, newEnd):find("[ \n]+$")
    if match then
        newEnd = start + match - 2
    end

    if newEnd < start then
        return ending
    end

    local match = desc:sub(start, newEnd):find("[^ \n]+$")
    if match then
        newEnd = start + match - 2
    end

    if newEnd < start then
        return ending
    end

    return newEnd
end

local function display_details(header, short, full)
    djui_chat_message_create(header)
    djui_chat_message_create(short)
    --the limitations of a chat box are difficult to calculate, so this is unoptimal
    local i = 1
    local fullDescLen = full:len()
    while i <= fullDescLen do
        local endIndex = math.min(i + 199, fullDescLen)
        if endIndex < fullDescLen then
            endIndex = get_trim_desc_end_index(full, i, endIndex + 1)
        end
        djui_chat_message_create(full:sub(i, endIndex))
        i = endIndex + 1
    end
end

--prepare the subcommands
add_prog_popup_subcommand(
    "help",
    "([page] | [subcommand])",
    "Displays information about commands.",
    "Given a page number, a set of commands on that page with short descriptions will be "
        .. "provided.\n"
        .. "Given a subcommand, a detailed description of the subcommand will be provided.\n"
        .. "Given no argument, the argument defaults to page 1.",
    function(arg)
        if arg == nil then
            arg = "1"
        end

        --first try to get a subcommand
        local subcom = progPopupsSubcomLUT[arg]
        if subcom then
            display_details(
                chatCommandColors.important .. "Progress Pop-ups Help - "
                    .. chatCommandColors.positive .. arg,
                subcom.shortDesc,
                subcom.fullDesc
            )
            return
        end

        --not a subcommand. A page number?
        local pageNumber = math.tointeger(tonumber(arg))
        if not pageNumber then
            djui_chat_message_create(
                chatCommandColors.fail .. "Progress Pop-ups Help cannot display help for "
                    .. "subcommand (" .. chatCommandColors.positive .. arg
                    .. chatCommandColors.fail .. ") that does not exist."
            )
            return
        end

        subcomPageCount = math.floor((#progPopupsSubcomAlpha + 9) / 10)
        if pageNumber < 1 or pageNumber > subcomPageCount then
            djui_chat_message_create(
                chatCommandColors.fail .. "Progress Pop-ups Help page number ("
                    .. chatCommandColors.positive .. tostring(pageNumber) .. chatCommandColors.fail
                    .. ") must be in range [" .. chatCommandColors.positive .. "1"
                    .. chatCommandColors.fail .. ", " .. chatCommandColors.positive
                    .. tostring(subcomPageCount) .. chatCommandColors.fail .. "]."
            )
            return
        end

        djui_chat_message_create(
            chatCommandColors.important .. "Progress Pop-ups Help - Page "
                .. chatCommandColors.positive .. tostring(pageNumber) .. chatCommandColors.important
                .. " of " .. chatCommandColors.positive .. tostring(subcomPageCount)
        )
        for i = pageNumber * 10 - 9, math.min(pageNumber * 10, #progPopupsSubcomAlpha) do
            local subcomName = progPopupsSubcomAlpha[i]
            subcom = progPopupsSubcomLUT[subcomName]
            djui_chat_message_create(
                chatCommandColors.negative .. subcomName .. " " .. subcom.args
                    .. chatCommandColors.default .. ": " .. subcom.shortDesc
            )
        end
    end
)

local function check_setting_exists(setting, errMsgFmt)
    if not progPopupsSettings[setting:lower()] then
        djui_chat_message_create(string.format(
            chatCommandColors.fail .. errMsgFmt,
            chatCommandColors.positive .. setting .. chatCommandColors.fail
        ))
        return false
    end
    return true
end

local function get_readable_setting(setting, value)
    local readable = progPopupsSettings[setting].readableFromVal[value]
    return readable and readable or tostring(value)
end

local function inform_cur_setting_val(setting, msgFmt)
    local settingVal, isServer = get_prog_popup_setting(setting)
    local readable = get_readable_setting(setting, settingVal)

    if isServer then
        readable = chatCommandColors.positive .. "the server default (" .. readable
            .. chatCommandColors.positive .. ")"
    end

    djui_chat_message_create(string.format(msgFmt, readable))
end

local function common_setting_set_process(setting, value, noArgsName, badSettingAction)
    if not setting or not value then
        djui_chat_message_create(
            chatCommandColors.fail .. "Progress Pop-ups Settings requires a "
                .. chatCommandColors.positive .. "setting name" .. chatCommandColors.fail
                .. " and " .. chatCommandColors.positive .. "new value"
                .. chatCommandColors.fail .. " for the " .. noArgsName .. " option."
        )
        return false
    end

    if
        not check_setting_exists(
            setting,
            "Cannot " .. badSettingAction .. " Progress Pop-ups setting (%s) that does not exist."
        )
    then
        return false
    end

    local settingTbl = progPopupsSettings[setting:lower()]
    local newValue = settingTbl.validVals[value:lower()]
    if not newValue then
        djui_chat_message_create(
            chatCommandColors.fail .. "Invalid value (" .. chatCommandColors.positive .. value
                .. chatCommandColors.fail .. ") for Progress Pop-ups setting ("
                .. chatCommandColors.positive .. setting .. chatCommandColors.fail
                .. ")."
        )
        return false
    end

    return true, settingTbl, newValue
end

local commandSettingsOptionsLUT = {
    list = function()
        djui_chat_message_create(
            chatCommandColors.important .. "Available Progress Pop-ups Settings"
        )

        for _, v in ipairs(progPopupsSettingsAlpha) do
            djui_chat_message_create(
                chatCommandColors.important .. " * " .. chatCommandColors.negative .. v
                    .. chatCommandColors.important .. ": " .. progPopupsSettings[v].desc
            )
        end
    end,

    info = function(setting)
        if not setting then
            djui_chat_message_create(
                chatCommandColors.fail .. "Progress Pop-ups Settings requires a "
                    .. chatCommandColors.positive .. "setting name" .. chatCommandColors.fail
                    .. " for the info option."
            )
            return
        end

        if
            not check_setting_exists(
                setting,
                "Cannot display info for Progress Pop-ups setting (%s) that does not exist."
            )
        then
            return
        end

        local settingLower = setting:lower()
        local settingTbl = progPopupsSettings[settingLower]
        display_details(
            chatCommandColors.important .. "Progress Pop-up Settings Info - "
                .. chatCommandColors.positive .. settingLower,
            settingTbl.desc,
            settingTbl.info
        )
    end,

    get = function(setting)
        if not setting then
            djui_chat_message_create(
                chatCommandColors.fail .. "Progress Pop-ups Settings requires a "
                    .. chatCommandColors.positive .. "setting name" .. chatCommandColors.fail
                    .. " for the get option."
            )
            return
        end

        if
            not check_setting_exists(
                setting,
                "Cannot get Progress Pop-ups setting (%s) that does not exist."
            )
        then
            return
        end

        inform_cur_setting_val(
            setting:lower(),
            chatCommandColors.important .. "Progress Pop-ups setting " .. chatCommandColors.positive
                .. setting .. chatCommandColors.important .. " is currently set to %s"
                .. chatCommandColors.important .. "."
        )
    end,

    set = function(setting, value)
        local ok, settingTbl, newValue = common_setting_set_process(setting, value, "set", "set")
        if not ok then
            return
        end

        settingTbl.localSet = newValue

        inform_cur_setting_val(
            setting:lower(),
            chatCommandColors.success .. "Progress Pop-ups setting " .. chatCommandColors.positive
                .. setting .. chatCommandColors.success .. " is now set to %s"
                .. chatCommandColors.success .. "."
        )
    end,

    setdef = function(setting, value)
        if not is_host("set the server default for a Progress Pop-up setting") then
            return
        end

        local ok, settingTbl, newValue = common_setting_set_process(
            setting,
            value,
            "setdef",
            "set server default for"
        )
        if not ok then
            return
        end

        if newValue == settingTbl.defToServerVal then
            djui_chat_message_create(
                chatCommandColors.fail .. "Cannot set server default for Progress Pop-ups setting ("
                    .. chatCommandColors.positive .. setting .. chatCommandColors.fail
                    .. ") to a server default value (" .. chatCommandColors.positive .. value
                    .. chatCommandColors.fail .. ")."
            )
            return
        end

        set_prog_popup_server_setting(setting:lower(), newValue)
        djui_chat_message_create(
            chatCommandColors.success .. "Server default for Progress Pop-ups setting "
                .. chatCommandColors.positive .. setting .. chatCommandColors.success
                .. " is now set to " .. settingTbl.readableFromVal[newValue]
                .. chatCommandColors.success .. "."
        )
    end
}

add_prog_popup_subcommand(
    "settings",
    "(get [setting] | set [setting] [value] | setdef [setting] [value] | list | info [setting])",
    "Utilities for Progress Pop-ups settings.",
    "The get option displays what the setting is set to.\n"
        .. "The set option changes the setting for the local player.\n"
        .. "The setdef option changes the default setting. The default setting is what a player "
            .. "uses until they change the value for themself.\n"
        .. "The list option lists the available settings. This is the default option.\n"
        .. "The info option gives a more detailed description about a specific setting.",
    function(option, setting, value)
        if not option then
            option = "list"
        end

        local option_func = commandSettingsOptionsLUT[option]

        if not option_func then
            djui_chat_message_create(
                chatCommandColors.fail .. "Progress Pop-ups settings option ("
                    .. chatCommandColors.positive .. option .. chatCommandColors.fail
                    .. ") does not exist. Double-check the " .. "help page!\n"
                    .. chatCommandColors.important .. "/progpopup help settings"
            )
            return
        end

        option_func(setting, value)
    end
)

progPopupsSettingsAlpha = make_alphabetized_keys(progPopupsSettings)
progPopupsSubcomAlpha = make_alphabetized_keys(progPopupsSubcomLUT)

local function get_chat_command_args(message)
    local args = {}

    for arg in message:gmatch("[^%s]+") do
        table.insert(args, arg)
    end

    return args
end

local function command_prog_popups(msg)
    local args = get_chat_command_args(msg)
    local argsCount = #args

    if argsCount == 0 then
        --basic usage
        djui_chat_message_create(
            "Progress Pop-ups Lib V" .. tostring(THIS_VERSION) .. "\n"
                .. "Usage: /" .. PROG_POPUP_COMMAND_NAME .. " [subcommand]\n"
                .. "Each subcommand has its own set of arguments.\n"
                .. "Use the help subcommand to see the list of subcommands.\n"
                .. chatCommandColors.important .. "/" .. PROG_POPUP_COMMAND_NAME .. " help"
        )
        return
    end

    --get function
    local subcomInfo = progPopupsSubcomLUT[args[1]]

    --try function
    if not subcomInfo then
        --bad subcom
        djui_chat_message_create(
            chatCommandColors.fail .. "Given Progress Pop-ups subcommand ("
                .. chatCommandColors.positive .. args[1]
                .. chatCommandColors.fail .. ") does not exist."
        )
        return
    end

    table.remove(args, 1)
    subcomInfo.func(table.unpack(args))
end

--local function on_command_prog_popups(message)
--    command_get_set_server_local_pref("displayLocal", message, "local progress pop-ups")
--    return true
--end

local function on_command_prog_popups(message)
    --leaving it like this so players don't get too confused
    local ok, err = pcall(command_prog_popups, message)
    if not ok then
        djui_chat_message_create(
            chatCommandColors.fail .. "Something went very wrong with the Progress Pop-ups "
                    .. "command.\n"
                .. "Please report this to " .. chatCommandColors.myColor .. "Altiami"
                    .. chatCommandColors.fail .. "."
        )
        djui_chat_message_create(err)
        print(err)
    end
    return true
end

hook_chat_command(
    PROG_POPUP_COMMAND_NAME,
    "- Main command for Progress Pop-ups. Use for usage details.",
    on_command_prog_popups
)

--//=================\\
--||END CHAT COMMANDS||
--\\=================//

local preload_dependent

local waitingDependentsLUT = {}
local waitingDependenciesLUT = {}
local loadedDependentsLUT = {}

local function wrap_dependent_data(dependentID, dependent_function, dependencyTable)
    return {
        dependentID = dependentID,
        callback = dependent_function,
        dependencies = dependencyTable
    }
end

local function check_dupe_dependent(dependentID)
    if waitingDependentsLUT[dependentID] or loadedDependentsLUT[dependentID] then
        print_err_msg(string.format(
            "Cannot load dependent (%s), for it already exists",
            dependentID
        ))
        return true
    end
    return false
end

local function try_preload_dependency_from_list(dependencyID)
    local dependencyIndex = _G.progressPopupsLibRequireIndexLUT[dependencyID]
    if dependencyIndex then
        --dependency is in the preload list, so try to load it first
        local dependency = _G.progressPopupsLibRequireCallbacks[dependencyIndex]
        --try to preload it
        local result = preload_dependent(
            dependency.dependentID,
            dependency.callback,
            dependency.dependencies
        )

        if
            preload_dependent(dependency.dependentID, dependency.callback, dependency.dependencies)
        then
            --clear it from the require list so it doesn't get loaded twice
            --DO NOT REMOVE; it will shift the indices and `_G.progressPopupsLibRequireIndexLUT`
            --    will be inaccurate!
            _G.progressPopupsLibRequireCallbacks[dependencyIndex] = nil
            return true
        end

        --didn't load
    end

    --rip
    return false
end

function preload_dependent(dependentID, dependent_function, dependencyTable)
    if check_dupe_dependent(dependentID) then
        return false
    end

    --first make sure all dependencies are loaded
    while dependencyTable[1] do
        local dependency = dependencyTable[1]
        local dependencyLoaded = loadedDependentsLUT[dependency]
        if not dependencyLoaded then
            --dependency isn't loaded yet. Is it in the preload list?
            if not try_preload_dependency_from_list(dependency) then
                --dependency isn't available yet; store dependent for later
                if not waitingDependenciesLUT[dependency] then
                    waitingDependenciesLUT[dependency] = {}
                end

                table.insert(
                    waitingDependenciesLUT[dependency],
                    wrap_dependent_data(dependentID, dependent_function, dependencyTable)
                )

                waitingDependentsLUT[dependentID] = true
                return false
            end

            --dependency was successfully loaded; continue
        end

        --dependency is loaded; remove from dependencies list
        table.remove(dependencyTable, 1)
    end

    --go ahead!
    local ok, errMsg = protect_dependent_function(
        dependent_function,
        dependentID,
        "Require callback for dependent (%s) errored\n%s"
    )
    if not ok then
        return false
    end

    --mark this dependent as loaded
    loadedDependentsLUT[dependentID] = true
    return true
end

--mods loaded before the library can use this system to alert the library to run them after it loads
--this was validated early in the file
if _G.progressPopupsLibRequireCallbacks then
    for _, v in ipairs(_G.progressPopupsLibRequireCallbacks) do
        preload_dependent(v.dependentID, v.callback, v.dependencies)
    end
end

--not needed any more
_G.progressPopupsLibRequireCallbacks = nil
_G.progressPopupsLibRequireIndexLUT = nil


function load_dependent(dependentID, dependent_function, dependencyTable)
    --first make sure all dependencies are loaded
    while dependencyTable[1] do
        local dependency = dependencyTable[1]
        local dependencyLoaded = loadedDependentsLUT[dependency]
        if not dependencyLoaded then
            --dependency isn't loaded yet; store dependent for later
            if not waitingDependenciesLUT[dependency] then
                waitingDependenciesLUT[dependency] = {}
            end

            table.insert(
                waitingDependenciesLUT[dependency],
                wrap_dependent_data(dependentID, dependent_function, dependencyTable)
            )

            waitingDependentsLUT[dependentID] = true
            return false
        end

        --dependency is loaded; remove from dependencies list
        table.remove(dependencyTable, 1)
    end

    --go ahead!
    local ok, errMsg = protect_dependent_function(
        dependent_function,
        dependentID,
        "Require callback for dependent (%s) errored\n%s"
    )
    if not ok then
        return false
    end

    --mark this dependent as loaded
    loadedDependentsLUT[dependentID] = true
    waitingDependentsLUT[dependentID] = nil

    --load dependents for this dependent
    if waitingDependenciesLUT[dependentID] then
        for _, v in ipairs(waitingDependenciesLUT[dependentID]) do
            --remove dependency. This mod that just loaded is the leading dependency
            table.remove(v.dependencies, 1)
            load_dependent(v.dependentID, v.callback, v.dependencies)
        end

        --don't need it anymore
        waitingDependenciesLUT[dependentID] = nil
    end

    return true
end

local function check_before_load_dependent(dependentID, dependent_function, dependencyTable)
    if check_dupe_dependent(dependentID) then
        return false
    end

    load_dependent(dependentID, dependent_function, dependencyTable)
end

_G.progressPopupsLib_load_dependent = check_before_load_dependent