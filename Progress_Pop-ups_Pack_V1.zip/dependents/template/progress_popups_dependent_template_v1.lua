-- name: Progress Pop-ups Dpnd. Template
-- incompatible: progress_popups_template
-- description: Version: \\#0FFF3F\\1.0\n\n\\#FF4F4F\\THIS IS A TEMPLATE FOR MAKING A PROGRESS POP-UPS DEPENDENT. DO NOT LOAD THIS IN-GAME\\#DEDEDE\\\n\nAuthor: \\#FF7F5F\\Altiami

--//================================================================\\
--||CHANGE THE INCOMPATIBLE TAG OF THE SCRIPT HEADER TO YOUR OWN TAG||
--||    CHANGE THE DESCRIPTION OF THE SCRIPT HEADER TO YOUR OWN     ||
--\\================================================================//

--//=================================================\\
--||LOOK TOWARD THE BOTTOM FOR WHERE TO PUT YOUR CODE||
--\\=================================================//

local function check_require_table()
    local requireTblCheck = type(_G.progressPopupsLibRequireCallbacks)
    if requireTblCheck == "table" then
        for _, v in ipairs(_G.progressPopupsLibRequireCallbacks) do
            if
                type(v) ~= "table"
                or type(v.callback) ~= "function"
                or type(v.dependencies) ~= "table"
            then
                return false
            end

            for _, dpnd in ipairs(v.dependencies) do
                if type(dpnd) ~= "string" then
                    return false
                end
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireTblCheck ~= "nil" then
        return false
    end

    _G.progressPopupsLibRequireCallbacks = {}
    return true
end

local function check_require_index_LUT()
    local requireIndexLUTCheck = type(_G.progressPopupsLibRequireIndexLUT)
    if requireIndexLUTCheck == "table" then
        for k, v in pairs(_G.progressPopupsLibRequireIndexLUT) do
            if type(k) ~= "string" or math.type(v) ~= "integer" then
                return false
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireIndexLUTCheck ~= "nil" then
        return false
    end

    _G.progressPopupsLibRequireIndexLUT = {}
    return true
end

local function require_progress_popups(dependentID, dependent_function, dependencyTable)
    --//======================\\
    --||ERROR-CHECKING UTILITY||
    --\\======================//

    if _G.progressPopupsTamperFlag then
        return
    end

    --this is here to show how up-to-date the base template is
    local THIS_VERSION = 1

    local ERR_MSG_MOD_NAME = "Progress Pop-ups"

    local ERR_MSG_PREFIX = "[ERROR] " .. ERR_MSG_MOD_NAME .. ": "

    local function print_err_msg(msg)
        if msg then
            msg = ERR_MSG_PREFIX .. msg
        else
            args[1] = msg
        end

        local popupMsgFmt = "[" .. ERR_MSG_MOD_NAME
            .. "]\nSomething went wrong!\nCheck %slog for info!"

        if gNetworkPlayers[0].type == NPT_UNKNOWN then
            --pop-up
            djui_popup_create(string.format(popupMsgFmt, ""), 3)
        else
            --pop-up
            djui_popup_create(string.format(popupMsgFmt, "chat or "), 3)
            --chat
            djui_chat_message_create(msg)
        end
        --log
        print(msg)

        play_sound(SOUND_GENERAL_BOWSER_BOMB_EXPLOSION, {x = 0, y = 0, z = 0})
        play_sound(SOUND_MARIO_DOH, {x = 0, y = 0, z = 0})
    end

    --//==========================\\
    --||END ERROR-CHECKING UTILITY||
    --\\==========================//

    if type(dependentID) ~= "string" then
        print_err_msg(string.format(
            "Attempt to add dependent with non-string ID (%s)",
            dependentID
        ))
        return
    end

    if type(dependent_function) ~= "function" then
        print_err_msg(string.format(
            "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                .. "erroneous mod."
        ))
    end

    --check if the library has been made
    if _G.progressPopupsLib ~= nil then
        --has it been tampered?
        if
            type(_G.progressPopupsLib) ~= "table"
            or math.type(_G.progressPopupsLib.VERSION) ~= "integer"
            or type(_G.progressPopupsLib.add_prog_popup_handler) ~= "function"
            or type(_G.progressPopupsLib.change_handler_data) ~= "function"
            or type(_G.progressPopupsLib.reallocate_handler_count) ~= "function"
            or type(_G.progressPopupsLib.enable_handler_dupe_checking) ~= "function"
            or type(_G.progressPopupsLib.disable_handler_dupe_checking) ~= "function"
            or type(_G.progressPopupsLib_load_dependent) ~= "function"
        then
            print_err_msg(
                "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                    .. "erroneous mod"
            )
            --prevent multiple alerts
            _G.progressPopupsTamperFlag = true
            return
        end

        --hopefully not tampered; add the dependent
        _G.progressPopupsLib_load_dependent(dependentID, dependent_function, dependencyTable)
    end

    --library hasn't been made yet
    --first check require table if it hasn't been made by another mod
    if not check_require_table() then
        --it's been tampered
        print_err_msg(
            "A mod has tampered with the require callback table for the Progress Pop-ups library. "
                .. "Please fix or remove the erroneous mod"
        )
        _G.progressPopupsTamperFlag = true

        return
    end

    if not check_require_index_LUT() then
        --it's been tampered
        print_err_msg(
            "A mod has tampered with the require index LUT for the Progress Pop-ups library. "
                .. "Please fix or remove the erroneous mod."
        )
        _G.progressPopupsTamperFlag = true

        return
    end

    --store dependent function in table for library to run when it is ready
    table.insert(
        _G.progressPopupsLibRequireCallbacks,
        {dependentID = dependentID, callback = dependent_function, dependencies = dependencyTable}
    )
    _G.progressPopupsLibRequireIndexLUT[dependentID] = #_G.progressPopupsLibRequireCallbacks
end

local function main()
    --//=====================================================\\
    --||               YOUR DEPENDENT CODE HERE              ||
    --||USE `_G.progressPopupsLib` TO ACCESS LIBRARY FEATURES||
    --\\=====================================================//
end

require_progress_popups(
    --//==================================\\
    --||CHANGE ADDON ID TO YOUR OWN STRING||
    --\\==================================//
    nil,

    main,

    {
        --//============================================\\
        --||ADD COMMA-SEPARATED IDS OF DEPENDENCIES HERE||
        --||      LEAVE EMPTY FOR NO DEPENDENCIES       ||
        --\\============================================//
    }
)