-- name: Bowser Key Progress Pop-ups
-- incompatible: key_progress_popups
-- description: Version: \\#0FFF3F\\1.0\n\n\\#FF4F4F\\This mod depends on \\#7DFF7F\\Progress Pop-ups Lib\\#FF4F4F\\!! Please enable it!!\\#DEDEDE\\\n\nAdds support for \\#FFAF00\\Bowser Keys\\#DEDEDE\\ to \\#7DFF7F\\Progress Pop-ups\\#DEDEDE\\.\n\nAuthor: \\#FF7F5F\\Altiami

--//================================================================\\
--||CHANGE THE INCOMPATIBLE TAG OF THE SCRIPT HEADER TO YOUR OWN TAG||
--||    CHANGE THE DESCRIPTION OF THE SCRIPT HEADER TO YOUR OWN     ||
--\\================================================================//

--//=================================================\\
--||LOOK TOWARD THE BOTTOM FOR WHERE TO PUT YOUR CODE||
--\\=================================================//

local function check_require_table()
    local requireTblCheck = type(_G.progressPopupsLibRequireCallbacks)
    if requireTblCheck == "table" then
        for _, v in ipairs(_G.progressPopupsLibRequireCallbacks) do
            if
                type(v) ~= "table"
                or type(v.callback) ~= "function"
                or type(v.dependencies) ~= "table"
            then
                return false
            end

            for _, dpnd in ipairs(v.dependencies) do
                if type(dpnd) ~= "string" then
                    return false
                end
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireTblCheck ~= "nil" then
        return false
    end

    _G.progressPopupsLibRequireCallbacks = {}
    return true
end

local function check_require_index_LUT()
    local requireIndexLUTCheck = type(_G.progressPopupsLibRequireIndexLUT)
    if requireIndexLUTCheck == "table" then
        for k, v in pairs(_G.progressPopupsLibRequireIndexLUT) do
            if type(k) ~= "string" or math.type(v) ~= "integer" then
                return false
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireIndexLUTCheck ~= "nil" then
        return false
    end

    _G.progressPopupsLibRequireIndexLUT = {}
    return true
end

local function require_progress_popups(dependentID, dependent_function, dependencyTable)
    --//======================\\
    --||ERROR-CHECKING UTILITY||
    --\\======================//

    if _G.progressPopupsTamperFlag then
        return
    end

    --this is here to show how up-to-date the base template is
    local THIS_VERSION = 1

    local ERR_MSG_MOD_NAME = "Progress Pop-ups"

    local ERR_MSG_PREFIX = "[ERROR] " .. ERR_MSG_MOD_NAME .. ": "

    local function print_err_msg(msg)
        if msg then
            msg = ERR_MSG_PREFIX .. msg
        else
            args[1] = msg
        end

        local popupMsgFmt = "[" .. ERR_MSG_MOD_NAME
            .. "]\nSomething went wrong!\nCheck %slog for info!"

        if gNetworkPlayers[0].type == NPT_UNKNOWN then
            --pop-up
            djui_popup_create(string.format(popupMsgFmt, ""), 3)
        else
            --pop-up
            djui_popup_create(string.format(popupMsgFmt, "chat or "), 3)
            --chat
            djui_chat_message_create(msg)
        end
        --log
        print(msg)

        play_sound(SOUND_GENERAL_BOWSER_BOMB_EXPLOSION, {x = 0, y = 0, z = 0})
        play_sound(SOUND_MARIO_DOH, {x = 0, y = 0, z = 0})
    end

    --//==========================\\
    --||END ERROR-CHECKING UTILITY||
    --\\==========================//

    if type(dependentID) ~= "string" then
        print_err_msg(string.format(
            "Attempt to add dependent with non-string ID (%s)",
            dependentID
        ))
        return
    end

    if type(dependent_function) ~= "function" then
        print_err_msg(string.format(
            "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                .. "erroneous mod."
        ))
    end

    --check if the library has been made
    if _G.progressPopupsLib ~= nil then
        --has it been tampered?
        if
            type(_G.progressPopupsLib) ~= "table"
            or math.type(_G.progressPopupsLib.VERSION) ~= "integer"
            or type(_G.progressPopupsLib.add_prog_popup_handler) ~= "function"
            or type(_G.progressPopupsLib.change_handler_data) ~= "function"
            or type(_G.progressPopupsLib.reallocate_handler_count) ~= "function"
            or type(_G.progressPopupsLib.enable_handler_dupe_checking) ~= "function"
            or type(_G.progressPopupsLib.disable_handler_dupe_checking) ~= "function"
            or type(_G.progressPopupsLib_load_dependent) ~= "function"
        then
            print_err_msg(
                "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                    .. "erroneous mod"
            )
            --prevent multiple alerts
            _G.progressPopupsTamperFlag = true
            return
        end

        --hopefully not tampered; add the dependent
        _G.progressPopupsLib_load_dependent(dependentID, dependent_function, dependencyTable)
    end

    --library hasn't been made yet
    --first check require table if it hasn't been made by another mod
    if not check_require_table() then
        --it's been tampered
        print_err_msg(
            "A mod has tampered with the require callback table for the Progress Pop-ups library. "
                .. "Please fix or remove the erroneous mod"
        )
        _G.progressPopupsTamperFlag = true

        return
    end

    if not check_require_index_LUT() then
        --it's been tampered
        print_err_msg(
            "A mod has tampered with the require index LUT for the Progress Pop-ups library. "
                .. "Please fix or remove the erroneous mod."
        )
        _G.progressPopupsTamperFlag = true

        return
    end

    --store dependent function in table for library to run when it is ready
    table.insert(
        _G.progressPopupsLibRequireCallbacks,
        {dependentID = dependentID, callback = dependent_function, dependencies = dependencyTable}
    )
    _G.progressPopupsLibRequireIndexLUT[dependentID] = #_G.progressPopupsLibRequireCallbacks
end

local function main()
    --//=====================================================\\
    --||              YOUR DEPENDENT CODE HERE               ||
    --||USE `_G.progressPopupsLib` TO ACCESS LIBRARY FEATURES||
    --\\=====================================================//

    local defKeyType = "Bowser Key"
    local defKeyColor = "\\#FFAF00\\"

    local keyInfoTbl = {}

    --each key stores a table with two fields
    local keyCalcToProgIndexLUT = {}

    local function get_key_calc_index(levelNum)
        return levelNum
    end

    local function get_key_calc_args(key)
        return gNetworkPlayers[0].currLevelNum
    end

    local function make_key_prog_popup_ID_number(...)
        return keyCalcToProgIndexLUT[get_key_calc_index(...)]
    end

    local function add_key_name(keyName, keyType, keyColor, ...)
        if not keyType then
            keyType = defKeyType
        end

        if not keyColor then
            keyColor = defKeyColor
        end

        table.insert(keyInfoTbl, {name = keyName, color = keyColor, keyType = keyType})
        keyCalcToProgIndexLUT[get_key_calc_index(...)] = #keyInfoTbl
    end

    local function check_key_dupe(levelNum)
        local mask
        if levelNum == LEVEL_BOWSER_1 then
            mask = SAVE_FLAG_HAVE_KEY_1 | SAVE_FLAG_UNLOCKED_BASEMENT_DOOR
        else
            mask = SAVE_FLAG_HAVE_KEY_2 | SAVE_FLAG_UNLOCKED_UPSTAIRS_DOOR
        end
        return save_file_get_flags() & mask ~= 0
    end

    local function verify_color(color)
        if not color:match("^\\#[0-9A-Fa-f]+\\$") then
            return false
        end

        local matches = {}
        for match in color:gmatch("[0-9A-Fa-f]") do
            table.insert(matches, match)
        end

        return #matches == 6 or #matches == 8
    end

    local change_data_LUT = {
        ["key_info"] = function(newName, newType, newColor, ...)
            if newName ~= nil and type(newName) ~= "string" then
                error(string.format(
                    "[WARNING] Attempt to change key name to non-string (%s)",
                    newName
                ))
                return false
            end

            if newType ~= nil and type(newType) ~= "string" then
                error(string.format(
                    "[WARNING] Attempt to change key type to non-string (%s)",
                    newType
                ))
                return false
            end

            if newColor ~= nil then
                if type(newColor) ~= "string" then
                    error(string.format(
                        "[WARNING] Attempt to change key color to non-string (%s)",
                        newColor
                    ))
                    return false
                end

                if not verify_color(newColor) then
                    error(string.format(
                        "[WARNING] Attempt to change key color to invalid string (%s)",
                        newColor
                    ))
                    return false
                end
            end

            local cachedIndex = make_key_prog_popup_ID_number(...)
            if cachedIndex then
                local keyInfo = keyInfoTbl[cachedIndex]
                if newName ~= nil then
                    keyInfo.name = newName
                end

                if newType ~= nil then
                    keyInfo.keyType = newType
                end

                if newColor ~= nil then
                    keyInfo.color = newColor
                end
                return true
            end

            --this is a new combo. Run through the addition function
            if not newName then
                error("[WARNING] Attempt to add key with no name")
                return false
            end

            add_key_name(newName, newType, newColor, ...)
            return true
        end,

        ["save_index_info"] = function(new_index_func, new_dupe_func, new_args_func)
            if new_index_func and type(new_index_func) ~= "function" then
                error(string.format(
                    "[WARNING] Attempt to change function for getting a save index index to "
                        .. "non-function (%s)",
                    new_index_func
                ))
                return false
            end

            if new_dupe_func and type(new_dupe_func) ~= "function" then
                error(string.format(
                    "[WARNING] Attempt to change function for checking save duplicates to "
                        .. "non-function (%s)",
                    new_dupe_func
                ))
                return false
            end

            if new_args_func and type(new_args_func) ~= "function" then
                error(string.format(
                    "[WARNING] Attempt to change function for getting save index arguments to "
                        .. "non-function (%s)",
                    new_args_func
                ))
                return false
            end

            if not new_index_func and not new_dupe_func and not new_args_func then
                return false
            end

            if new_index_func then
                get_key_calc_index = new_index_func
            end

            if new_dupe_func then
                get_key_calc_index = new_dupe_func
            end

            if new_args_func then
                get_key_calc_args = new_args_func
            end

            --the table is now inaccurate, so it must be redefined manually
            keyInfoTbl = {}
            keyCalcToProgIndexLUT = {}
            return true
        end
    }

    add_key_name("Bowser's Dark Trap", nil, nil, LEVEL_BOWSER_1)
    add_key_name("Bowser's Fiery Escape", nil, nil, LEVEL_BOWSER_2)

    _G.progressPopupsLib.add_prog_popup_handler(
        --id
        "bowser_key",

        --count
        2,

        --hookEventType
        HOOK_BEFORE_MARIO_UPDATE,

        --is_callback_valid
        --function(hookEventType, interactor, interactee, interactType, interactValue)
        --    if
        --        not interactValue
        --        or interactType ~= INTERACT_STAR_OR_KEY
        --        --Jumbo Star
        --        or interactee.oInteractionSubtype & INT_SUBTYPE_GRAND_STAR ~= 0
        --    then
        --        return false
        --    end
        --
        --    --when `interactValue` is false, `interactor` is always the local player
        --
        --    --Power Star/Bowser 3
        --    local levelNum = gNetworkPlayers[0].currLevelNum
        --    if
        --        levelNum == LEVEL_BOWSER_3
        --        or levelNum ~= LEVEL_BOWSER_1
        --            and levelNum ~= LEVEL_BOWSER_2
        --    then
        --        return false
        --    end
        --
        --    return true
        --end,
        function(hookEventType, mario)
            if
                mario.playerIndex ~= 0
                or mario.action == 0
                or mario.action & ACT_FLAG_INTANGIBLE ~= 0
                or mario.health < 0x100
                or mario.marioObj.collidedObjInteractTypes & INTERACT_STAR_OR_KEY == 0
                or is_player_active(mario) == 0
            then
                return false
            end

            local keyObj = mario_get_collided_object(mario, INTERACT_STAR_OR_KEY)
            if
                not keyObj
                or keyObj.oInteractStatus & INT_STATUS_INTERACTED ~= 0
                --Grand Star
                or keyObj.oInteractionSubtype & INT_SUBTYPE_GRAND_STAR ~= 0
            then
                return false
            end

            --Power Star/Bowser 3
            local levelNum = gNetworkPlayers[0].currLevelNum
            return levelNum ~= LEVEL_BOWSER_3
                and (
                    levelNum == LEVEL_BOWSER_1
                    or levelNum == LEVEL_BOWSER_2
                )
        end,

        --make_ID_number_from_callback_info
        --function(hookEventType, interactor, interactee, interactType, interactValue)
        --    --this function is run only if `is_callback_valid` was true
        --    --this prevents needing to do duplicate checks
        --
        --    return make_key_prog_popup_ID_number(get_key_calc_args(interactee))
        --end,
        function(hookEventType, mario)
            --this function is run only if `is_callback_valid` was true
            --this prevents needing to do duplicate checks
            return make_key_prog_popup_ID_number(get_key_calc_args(
                mario_get_collided_object(mario, INTERACT_STAR_OR_KEY)
            ))
        end,

        --get_player_from_callback_info
        --function(hookEventType, interactor, interactee, interactType, interactValue)
        --    return network_global_index_from_local(0)
        --end,
        function(hookEventType, mario)
            return network_global_index_from_local(0)
        end,

        --is_dupe_prog
        --function(hookEventType, interactor, interactee, interactType, interactValue)
        --    return check_key_dupe(get_key_calc_args(interactee))
        --end,
        function(hookEventType, mario)
            return check_key_dupe(get_key_calc_args(
                mario_get_collided_object(mario, INTERACT_STAR_OR_KEY)
            ))
        end,

        --make_popup_msg
        function(playerName, playerColor, idNumber)
            local keyInfo = keyInfoTbl[idNumber]

            if not keyInfo then
                return
            end

            return playerColor .. playerName .. " got a " .. keyInfo.keyType .. "!\n"
                .. keyInfo.color .. keyInfo.name
        end,

        --change_handler_data
        --LIST OF ELEMENTS THAT CAN BE CHANGED
        --key_info: changes the name of a certain Bowser Key. The key chosen does not have to
        --        already exist.
        --    ARGUMENTS
        --    newName: the new name of the key.
        --    newType: a bit of a misnomer, this is what the pop-up calls the "Bowser Key".
        --        This is for when a mod changes what Bowser Keys are. For example, you could make
        --        this "Grand Star".
        --    newColor: the new color for the key. This is used for the pop-up
        --    both newType and newColor can be nil to use defaults of "Bowser Key" and "\#FFAF00\"
        --        respectively.
        --    subsequent arguments are as specified for the save_index_info index function.
        --    this means that if the save_index_info index function needs to change, IT SHOULD BE
        --        CHANGED FIRST.
        --    see the section for save_index_info for more info.

        --save_index_info: changes the functions used to calculate the index for the Bowser Key.
        --    the result of these functions is used internally to get a value in the handler count
        --        range, which is used for sending the pop-up, and getting the key name.
        --    said conversion is done automatically.
        --    ALL KEY NAMES MUST BE REDEFINED AFTER CHANGING THIS.
        --    ARGUMENTS
        --    new_index_func: the new function to use for calculating the index.
        --        the arguments depend on the args function, described below.
        --    new_dupe_func: the new function to use for checking for duplicate progress.
        --        the arguments depend on the args function, described below.
        --        if the changes make duplicates impossible to check, disable dupe checking through
        --            the main lib.
        --    new_args_func: the new function to use for getting the arguments for the index
        --            function, described above.
        --        it takes one argument, key: the key Object collected
        --    any argument may be nil, in which case, the respective existing function is kept

        --    default arguments for save index info follow.
        --    levelNum: the level in which the Bowser Key was collected.

        --    the arguments function by default gets the arguments as follows:
        --    levelNum: gNetworkPlayers[0].currLevelNum
        function(element, ...)
            local element_change_func = change_data_LUT[element]
            if not element_change_func then
                error(string.format(
                    "[WARNING] Attempted to change Bowser Key Progress Pop-ups data with invalid "
                        .. "element ID (%s)",
                    element
                ))
                return false
            end

            return element_change_func(...)
        end
    )
end

require_progress_popups(
    --//===========================\\
    --||CHANGE ADDON ID TO YOUR OWN||
    --\\===========================//
    "bowser_key_handler",

    main,

    {
        --//============================================\\
        --||ADD COMMA-SEPARATED IDS OF DEPENDENCIES HERE||
        --||      LEAVE EMPTY FOR NO DEPENDENCIES       ||
        --\\============================================//
    }
)