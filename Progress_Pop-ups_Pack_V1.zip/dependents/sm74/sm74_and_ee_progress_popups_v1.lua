-- name: SM 74 (+EE) Progress Pop-ups
-- incompatible: sm74_and_ee_progress_popups
-- description: Version: \\#0FFF3F\\1.0\n\n\\#FF4F4F\\This mod depends on \\#7DFF7F\\Progress Pop-ups Lib\\#FF4F4F\\, \\#FFEF00\\Power Star Progress Pop-ups\\#FF4F4F\\, and \\#FFAF00\\Bowser Key Progress Pop-ups\\#FF4F4F\\!! Please enable them!!\\#DEDEDE\\\n\nAdds support for \\#7FDF3F\\S\\#FF3F3F\\u\\#7F7FFF\\p\\#FF6F3F\\e\\#FFFF3F\\r \\#AFAFAF\\Mario \\#FFFFFF\\74 \\#FF1F1F\\(+EE)\\#DEDEDE\\ to \\#7DFF7F\\Progress Pop-ups\\#DEDEDE\\.\n\nAuthor: \\#FF7F5F\\Altiami

--//================================================================\\
--||CHANGE THE INCOMPATIBLE TAG OF THE SCRIPT HEADER TO YOUR OWN TAG||
--||    CHANGE THE DESCRIPTION OF THE SCRIPT HEADER TO YOUR OWN     ||
--\\================================================================//

--//=================================================\\
--||LOOK TOWARD THE BOTTOM FOR WHERE TO PUT YOUR CODE||
--\\=================================================//

local function check_require_table()
    local requireTblCheck = type(_G.progressPopupsLibRequireCallbacks)
    if requireTblCheck == "table" then
        for _, v in ipairs(_G.progressPopupsLibRequireCallbacks) do
            if
                type(v) ~= "table"
                or type(v.callback) ~= "function"
                or type(v.dependencies) ~= "table"
            then
                return false
            end

            for _, dpnd in ipairs(v.dependencies) do
                if type(dpnd) ~= "string" then
                    return false
                end
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireTblCheck ~= "nil" then
        return false
    end

    _G.progressPopupsLibRequireCallbacks = {}
    return true
end

local function check_require_index_LUT()
    local requireIndexLUTCheck = type(_G.progressPopupsLibRequireIndexLUT)
    if requireIndexLUTCheck == "table" then
        for k, v in pairs(_G.progressPopupsLibRequireIndexLUT) do
            if type(k) ~= "string" or math.type(v) ~= "integer" then
                return false
            end
        end

        return true
    end

    --is it not nil? If so, it's been tampered
    if requireIndexLUTCheck ~= "nil" then
        return false
    end

    _G.progressPopupsLibRequireIndexLUT = {}
    return true
end

local function require_progress_popups(dependentID, dependent_function, dependencyTable)
    --//======================\\
    --||ERROR-CHECKING UTILITY||
    --\\======================//

    if _G.progressPopupsTamperFlag then
        return
    end

    --this is here to show how up-to-date the base template is
    local THIS_VERSION = 1

    local ERR_MSG_MOD_NAME = "Progress Pop-ups"

    local ERR_MSG_PREFIX = "[ERROR] " .. ERR_MSG_MOD_NAME .. ": "

    local function print_err_msg(msg)
        if msg then
            msg = ERR_MSG_PREFIX .. msg
        else
            args[1] = msg
        end

        local popupMsgFmt = "[" .. ERR_MSG_MOD_NAME
            .. "]\nSomething went wrong!\nCheck %slog for info!"

        if gNetworkPlayers[0].type == NPT_UNKNOWN then
            --pop-up
            djui_popup_create(string.format(popupMsgFmt, ""), 3)
        else
            --pop-up
            djui_popup_create(string.format(popupMsgFmt, "chat or "), 3)
            --chat
            djui_chat_message_create(msg)
        end
        --log
        print(msg)

        play_sound(SOUND_GENERAL_BOWSER_BOMB_EXPLOSION, {x = 0, y = 0, z = 0})
        play_sound(SOUND_MARIO_DOH, {x = 0, y = 0, z = 0})
    end

    --//==========================\\
    --||END ERROR-CHECKING UTILITY||
    --\\==========================//

    if type(dependentID) ~= "string" then
        print_err_msg(string.format(
            "Attempt to add dependent with non-string ID (%s)",
            dependentID
        ))
        return
    end

    if type(dependent_function) ~= "function" then
        print_err_msg(string.format(
            "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                .. "erroneous mod."
        ))
    end

    --check if the library has been made
    if _G.progressPopupsLib ~= nil then
        --has it been tampered?
        if
            type(_G.progressPopupsLib) ~= "table"
            or math.type(_G.progressPopupsLib.VERSION) ~= "integer"
            or type(_G.progressPopupsLib.add_prog_popup_handler) ~= "function"
            or type(_G.progressPopupsLib.change_handler_data) ~= "function"
            or type(_G.progressPopupsLib.reallocate_handler_count) ~= "function"
            or type(_G.progressPopupsLib.enable_handler_dupe_checking) ~= "function"
            or type(_G.progressPopupsLib.disable_handler_dupe_checking) ~= "function"
            or type(_G.progressPopupsLib_load_dependent) ~= "function"
        then
            print_err_msg(
                "A mod has tampered with the Progress Pop-ups library. Please fix or remove the "
                    .. "erroneous mod"
            )
            --prevent multiple alerts
            _G.progressPopupsTamperFlag = true
            return
        end

        --hopefully not tampered; add the dependent
        _G.progressPopupsLib_load_dependent(dependentID, dependent_function, dependencyTable)
    end

    --library hasn't been made yet
    --first check require table if it hasn't been made by another mod
    if not check_require_table() then
        --it's been tampered
        print_err_msg(
            "A mod has tampered with the require callback table for the Progress Pop-ups library. "
                .. "Please fix or remove the erroneous mod"
        )
        _G.progressPopupsTamperFlag = true

        return
    end

    if not check_require_index_LUT() then
        --it's been tampered
        print_err_msg(
            "A mod has tampered with the require index LUT for the Progress Pop-ups library. "
                .. "Please fix or remove the erroneous mod."
        )
        _G.progressPopupsTamperFlag = true

        return
    end

    --store dependent function in table for library to run when it is ready
    table.insert(
        _G.progressPopupsLibRequireCallbacks,
        {dependentID = dependentID, callback = dependent_function, dependencies = dependencyTable}
    )
    _G.progressPopupsLibRequireIndexLUT[dependentID] = #_G.progressPopupsLibRequireCallbacks
end

local function main()
    --//=====================================================\\
    --||               YOUR DEPENDENT CODE HERE              ||
    --||USE `_G.progressPopupsLib` TO ACCESS LIBRARY FEATURES||
    --\\=====================================================//

    local function get_star_calc_index(areaIndex, courseNum, starIndex)
        return areaIndex * 1000 + courseNum * 10 + starIndex + 1
    end

    local function get_star_calc_args(star)
        local localPly = gNetworkPlayers[0]

        return localPly.currAreaIndex, localPly.currCourseNum, star.oBehParams >> 24
    end

    local function add_star_name(starName, isEE, courseNum, starIndex)
        _G.progressPopupsLib.change_handler_data(
            "power_star",
            "star_info",
            starName,
            nil,
            isEE and "\\#FF5F3F\\" or nil,
            isEE and 2 or 1,
            courseNum,
            starIndex
        )
    end

    local function check_star_dupe(areaIndex, courseNum, starIndex)
        return (save_file_get_star_flags(get_current_save_file_num() - 1, courseNum - 1) >> starIndex)
            & 1 == 1
    end

    _G.progressPopupsLib.reallocate_handler_count("power_star", 308)
    _G.progressPopupsLib.change_handler_data(
        "power_star",
        "save_index_info",
        get_star_calc_index,
        check_star_dupe,
        get_star_calc_args
    )

    add_star_name("Toad atop Bowser's Barricade", false, COURSE_NONE, 0)
    add_star_name("Toad in the Flower Fields", false, COURSE_NONE, 1)
    add_star_name("Toad at Magma Mountain", false, COURSE_NONE, 2)
    add_star_name("MIPS Visits Valley of the Toads", false, COURSE_NONE, 3)
    add_star_name("Don't Bully MIPS :(", false, COURSE_NONE, 4)

    add_star_name("Walljumping Lesson", false, COURSE_BOB, 0)
    add_star_name("Conquer the Pillars", false, COURSE_BOB, 1)
    add_star_name("The Observation Tower", false, COURSE_BOB, 2)
    add_star_name("Collect 8 Red Coins", false, COURSE_BOB, 3)
    add_star_name("Secrets of the Sky", false, COURSE_BOB, 4)
    add_star_name("The Box's Treasure", false, COURSE_BOB, 5)
    add_star_name("100 Gold Coins; Diced", false, COURSE_BOB, 6)

    add_star_name("To the Top of the Tower", false, COURSE_WF, 0)
    add_star_name("8 Dangerous Red Coins", false, COURSE_WF, 1)
    add_star_name("The Outer Wall", false, COURSE_WF, 2)
    add_star_name("No Time to Waste", false, COURSE_WF, 3)
    add_star_name("Floatation Technology Box", false, COURSE_WF, 4)
    add_star_name("Master of Jumping", false, COURSE_WF, 5)
    add_star_name("100 Suns in the Sky", false, COURSE_WF, 6)

    add_star_name("The Deepest Dive", false, COURSE_JRB, 0)
    add_star_name("Cave Exploration", false, COURSE_JRB, 1)
    add_star_name("Precision Pillars", false, COURSE_JRB, 2)
    add_star_name("Red Treasure Hunt", false, COURSE_JRB, 3)
    add_star_name("Heavy Metal Required", false, COURSE_JRB, 4)
    add_star_name("Wall of Failure?", false, COURSE_JRB, 5)
    add_star_name("100 Spots of Yellow in the Blue", false, COURSE_JRB, 6)

    add_star_name("Rooftop Climbing", false, COURSE_CCM, 0)
    add_star_name("Into the Sewer System", false, COURSE_CCM, 1)
    add_star_name("The Secondary House Entrance", false, COURSE_CCM, 2)
    add_star_name("Find the Secret Room", false, COURSE_CCM, 3)
    add_star_name("The Village's Red Coins", false, COURSE_CCM, 4)
    add_star_name("The Mansion's Secret Star", false, COURSE_CCM, 5)
    add_star_name("Economy of a Town", false, COURSE_CCM, 6)

    add_star_name("Explore the Factory", false, COURSE_BBH, 0)
    add_star_name("Toxic Ride", false, COURSE_BBH, 1)
    add_star_name("Watch Your Step", false, COURSE_BBH, 2)
    add_star_name("Blocks of Doom", false, COURSE_BBH, 3)
    add_star_name("8 Spooky Red Coins", false, COURSE_BBH, 4)
    add_star_name("The Hidden Room", false, COURSE_BBH, 5)
    add_star_name("The Factory's 100 Gold Scraps", false, COURSE_BBH, 6)

    add_star_name("Downwards", false, COURSE_HMC, 0)
    add_star_name("Burning-Hot Tunnel", false, COURSE_HMC, 1)
    add_star_name("Red Coins in the Cavern", false, COURSE_HMC, 2)
    add_star_name("Hot Obstacle Course", false, COURSE_HMC, 3)
    add_star_name("Chuckya's Challenge", false, COURSE_HMC, 4)
    add_star_name("Cap-Combination", false, COURSE_HMC, 5)
    add_star_name("Stalagmite Gold Rush", false, COURSE_HMC, 6)

    add_star_name("Rematch with King Whomp", false, COURSE_LLL, 0)
    add_star_name("Scalding Waters", false, COURSE_LLL, 1)
    add_star_name("Almost to the Top", false, COURSE_LLL, 2)
    add_star_name("Frozen Red Coins", false, COURSE_LLL, 3)
    add_star_name("How High Can You Go?", false, COURSE_LLL, 4)
    add_star_name("Down-Low Secret Star", false, COURSE_LLL, 5)
    add_star_name("Iced-Over 100 Coins", false, COURSE_LLL, 6)

    add_star_name("Under Construction", false, COURSE_SSL, 0)
    add_star_name("Hidden Inside the Labyrinth", false, COURSE_SSL, 1)
    add_star_name("The Pyramids of Tutanpokey", false, COURSE_SSL, 2)
    add_star_name("Thunder Mountain", false, COURSE_SSL, 3)
    add_star_name("8 Hot Red Coins", false, COURSE_SSL, 4)
    add_star_name("The Pharaoh's Sandy Secret", false, COURSE_SSL, 5)
    add_star_name("100 Coins Across the Sand", false, COURSE_SSL, 6)

    add_star_name("King Bob-omb's Revenge", false, COURSE_DDD, 0)
    add_star_name("Red Coins in the Gardens", false, COURSE_DDD, 1)
    add_star_name("Vast Wooden Structure", false, COURSE_DDD, 2)
    add_star_name("Lumberjack Jumping", false, COURSE_DDD, 3)
    add_star_name("The Windmill's Star", false, COURSE_DDD, 4)
    add_star_name("A Hidden Cave", false, COURSE_DDD, 5)
    add_star_name("Are Coins Good Fertilizer?", false, COURSE_DDD, 6)

    add_star_name("Koopa the Cheater", false, COURSE_SL, 0)
    add_star_name("Grounded Red Coins", false, COURSE_SL, 1)
    add_star_name("The Tower of Power", false, COURSE_SL, 2)
    add_star_name("The Other Power-Tower", false, COURSE_SL, 3)
    add_star_name("Fearful Failure Blocks", false, COURSE_SL, 4)
    add_star_name("A Cliff's Hidden Star", false, COURSE_SL, 5)
    add_star_name("Find 100 Coins in the Swamp", false, COURSE_SL, 6)

    add_star_name("Mystery of the Sapphires", false, COURSE_WDW, 0)
    add_star_name("Golden Glimmer", false, COURSE_WDW, 1)
    add_star_name("Thing with Spikes", false, COURSE_WDW, 2)
    add_star_name("Treasure Hunt", false, COURSE_WDW, 3)
    add_star_name("Shiny Object", false, COURSE_WDW, 4)
    add_star_name("Starlight", false, COURSE_WDW, 5)
    add_star_name("Beach Hectacoin", false, COURSE_WDW, 6)

    add_star_name("King Boo's Invasion", false, COURSE_TTM, 0)
    add_star_name("Tricky Pillars", false, COURSE_TTM, 1)
    add_star_name("Red Coin Quest", false, COURSE_TTM, 2)
    add_star_name("Walljumping Madness", false, COURSE_TTM, 3)
    add_star_name("Problematic Box", false, COURSE_TTM, 4)
    add_star_name("Look Out", false, COURSE_TTM, 5)
    add_star_name("Wrathful Coins by the Hundred", false, COURSE_TTM, 6)

    add_star_name("High in the Sky", false, COURSE_THI, 0)
    add_star_name("Red Coin Flight", false, COURSE_THI, 1)
    add_star_name("Inside a Cave", false, COURSE_THI, 2)
    add_star_name("The Mountain Peaks", false, COURSE_THI, 3)
    add_star_name("Hot and Spicy", false, COURSE_THI, 4)
    add_star_name("Acrobatic Flier", false, COURSE_THI, 5)
    add_star_name("100 Molten Treasures", false, COURSE_THI, 6)

    add_star_name("Tower of the West", false, COURSE_TTC, 0)
    add_star_name("Jumping Maestro", false, COURSE_TTC, 1)
    add_star_name("Bottomless Fortress", false, COURSE_TTC, 2)
    add_star_name("Behind the Wall", false, COURSE_TTC, 3)
    add_star_name("Treasure-Tower", false, COURSE_TTC, 4)
    add_star_name("Red Frustration", false, COURSE_TTC, 5)
    add_star_name("Luminous 100 Coins", false, COURSE_TTC, 6)

    add_star_name("The Same Place Again?", false, COURSE_RR, 0)
    add_star_name("Tiny Tower", false, COURSE_RR, 1)
    add_star_name("The High Building", false, COURSE_RR, 2)
    add_star_name("Intense Challenge", false, COURSE_RR, 3)
    add_star_name("Flight for Sight", false, COURSE_RR, 4)
    add_star_name("More Red Frustration", false, COURSE_RR, 5)
    add_star_name("Umbral 100 Coins", false, COURSE_RR, 6)

    add_star_name("Shoot to the Battletower", false, COURSE_BITDW, 0)
    add_star_name("Hidden Stash of the Badlands", false, COURSE_BITDW, 1)
    add_star_name("Badlands Balance Beams", false, COURSE_BITDW, 2)
    add_star_name("Red Coin Battlefield Rations", false, COURSE_BITDW, 3)

    add_star_name("Scale the Lone Aquatic Mountain", false, COURSE_BITFS, 0)
    add_star_name("Aquatic Castle's Reservoir Gold", false, COURSE_BITFS, 1)
    add_star_name("Jump Fast O'er Bowser's Lake", false, COURSE_BITFS, 2)
    add_star_name("Broken Walls of Aquatic Castle", false, COURSE_BITFS, 3)
    add_star_name("Bowser's Red Wishing Fountain", false, COURSE_BITFS, 4)

    add_star_name("Wall Sidle for the Crystal Gem", false, COURSE_BITS, 0)
    add_star_name("Shining from the Crystal Tower", false, COURSE_BITS, 1)
    add_star_name("Shard in the Incinerator", false, COURSE_BITS, 2)
    add_star_name("High-up Crystal Palace Stowaway", false, COURSE_BITS, 3)
    add_star_name("Thread the Crystalline Path", false, COURSE_BITS, 4)
    add_star_name("Fire Quartz for the Koopa King", false, COURSE_BITS, 5)

    add_star_name("Not Your Average Slip 'n' Slide", false, COURSE_PSS, 0)
    add_star_name("The Frozen Scenic Route", false, COURSE_PSS, 1)
    add_star_name("Slide into the Icy Depths", false, COURSE_PSS, 2)
    add_star_name("Frosty Slide for 8 Re--Wait...", false, COURSE_PSS, 3)

    add_star_name("Wall Kicks are Dangerous", false, COURSE_COTMC, 0)
    add_star_name("Metal Spelunkin' Time", false, COURSE_COTMC, 1)
    add_star_name("This Hiding Spot Is Just Toxic", false, COURSE_COTMC, 2)
    add_star_name("Is It More Toxic Higher Up?", false, COURSE_COTMC, 3)
    add_star_name("Toxins, Metal, and Red Coins", false, COURSE_COTMC, 4)

    add_star_name("Lava-Red Coins of the Towers", false, COURSE_TOTWC, 0)
    add_star_name("Search the Towers, Not the Lava", false, COURSE_TOTWC, 1)
    add_star_name("Lowly Lava Tower Prize", false, COURSE_TOTWC, 2)

    add_star_name("First, Check the Dust Bin", false, COURSE_VCUTM, 0)
    add_star_name("Across a Narrow Dusty Path", false, COURSE_VCUTM, 1)
    add_star_name("Lightly Dusted Red Coins", false, COURSE_VCUTM, 2)
    add_star_name("Dust in the Big Blue House", false, COURSE_VCUTM, 3)
    add_star_name("Vanish and Go Long", false, COURSE_VCUTM, 4)
    add_star_name("To the Duststorm Heights", false, COURSE_VCUTM, 5)

    add_star_name("Secret Eastern Alcove", false, COURSE_WMOTR, 0)
    add_star_name("Just Outside the Frozen Slide", false, COURSE_WMOTR, 1)
    add_star_name("Bowser's Eastward Hiding Spot", false, COURSE_WMOTR, 2)
    add_star_name("Red Riches of the East", false, COURSE_WMOTR, 3)
    add_star_name("Up the East-side Mountains", false, COURSE_WMOTR, 4)
    add_star_name("East...Startower?", false, COURSE_WMOTR, 5)

    add_star_name("Behold, Your Champion", false, COURSE_SA, 0)
    add_star_name("YOU ARE A SUPER CHAMPION!!", false, COURSE_SA, 2)

    add_star_name("Toad Who Hates Everything", true, COURSE_NONE, 0)
    add_star_name("Toad Traumatized Forever", true, COURSE_NONE, 1)
    add_star_name("Toad Doomed to a Dwindling Hope", true, COURSE_NONE, 2)
    add_star_name("MIPS's Hopping Days Are Over", true, COURSE_NONE, 3)
    add_star_name("Wasn't MIPS Caught Already?", true, COURSE_NONE, 4)

    add_star_name("Little Warm-Up", true, COURSE_BOB, 0)
    add_star_name("Let's-a-Go!", true, COURSE_BOB, 1)
    add_star_name("Scale the Tower", true, COURSE_BOB, 2)
    add_star_name("Fundamental Tunnel Problems", true, COURSE_BOB, 3)
    add_star_name("First Red Katastrophe", true, COURSE_BOB, 4)
    add_star_name("You Won't Find Me!", true, COURSE_BOB, 5)
    add_star_name("Devil's Dicey 100 Coins", true, COURSE_BOB, 6)

    add_star_name("The Vine's Treasure", true, COURSE_WF, 0)
    add_star_name("Time Pressure Travel", true, COURSE_WF, 1)
    add_star_name("On Top of That Wall!", true, COURSE_WF, 2)
    add_star_name("Jumping-Parcour 1", true, COURSE_WF, 3)
    add_star_name("Jumping-Parcour 2", true, COURSE_WF, 4)
    add_star_name("Light Red Coins", true, COURSE_WF, 5)
    add_star_name("100 Fruits from the Vineyard", true, COURSE_WF, 6)

    add_star_name("The Upper End of the Crater", true, COURSE_JRB, 0)
    add_star_name("Small Pillar Training", true, COURSE_JRB, 1)
    add_star_name("Hot Step Stones", true, COURSE_JRB, 2)
    add_star_name("Deep Within the Volcano", true, COURSE_JRB, 3)
    add_star_name("Artistic Coin Search", true, COURSE_JRB, 4)
    add_star_name("Painful Experience", true, COURSE_JRB, 5)
    add_star_name("Not-So-Deepred 100 Coins", true, COURSE_JRB, 6)

    add_star_name("Ghost Odyssee", true, COURSE_CCM, 0)
    add_star_name("Guardian of the Village", true, COURSE_CCM, 1)
    add_star_name("Expanded Secret Room", true, COURSE_CCM, 2)
    add_star_name("Death Pit", true, COURSE_CCM, 3)
    add_star_name("So Close and Yet So Far Away", true, COURSE_CCM, 4)
    add_star_name("Hidden Coward", true, COURSE_CCM, 5)
    add_star_name("Collapsed Downtown Economy", true, COURSE_CCM, 6)

    add_star_name("Pearl Diver", true, COURSE_BBH, 0)
    add_star_name("The Tunnel Labyrinth Part 1", true, COURSE_BBH, 1)
    add_star_name("The Tunnel Labyrinth Part 2", true, COURSE_BBH, 2)
    add_star_name("The Tunnel Labyrinth Part 3", true, COURSE_BBH, 3)
    add_star_name("The Tunnel Labyrinth Part 4", true, COURSE_BBH, 4)
    add_star_name("The Tunnel Labyrinth Part 5", true, COURSE_BBH, 5)
    add_star_name("The Tunnel Labyrinth Part Coins", true, COURSE_BBH, 6)

    add_star_name("Deep Within the Cauldron", true, COURSE_HMC, 0)
    add_star_name("Balls of Steel and Fire", true, COURSE_HMC, 1)
    add_star_name("Blue Contrast Blocks", true, COURSE_HMC, 2)
    add_star_name("Side Cauldron Shananigans", true, COURSE_HMC, 3)
    add_star_name("Dance with the Have-Hos", true, COURSE_HMC, 4)
    add_star_name("Red Sin", true, COURSE_HMC, 5)
    add_star_name("Inferno's 100 Coins a-Blazing", true, COURSE_HMC, 6)

    add_star_name("Brick Battle", true, COURSE_LLL, 0)
    add_star_name("Floatation in Block Form", true, COURSE_LLL, 1)
    add_star_name("Soul of a Climber", true, COURSE_LLL, 2)
    add_star_name("Blood-Red Finances", true, COURSE_LLL, 3)
    add_star_name("Annoying Search", true, COURSE_LLL, 4)
    add_star_name("Unjustifiable Search", true, COURSE_LLL, 5)
    add_star_name("Freshly Thawed 100 Coins", true, COURSE_LLL, 6)

    add_star_name("Still Under Construction", true, COURSE_SSL, 0)
    add_star_name("Flood Landing Stage", true, COURSE_SSL, 1)
    add_star_name("Not So Secret Secret Anymore", true, COURSE_SSL, 2)
    add_star_name("Doubtful Pyramid", true, COURSE_SSL, 3)
    add_star_name("Hidden Hermit", true, COURSE_SSL, 4)
    add_star_name("You Shall Drown!", true, COURSE_SSL, 5)
    add_star_name("Lost, Overgrown 100 Coins", true, COURSE_SSL, 6)

    add_star_name("Another Rematch with King Bob-omb", true, COURSE_DDD, 0)
    add_star_name("Windy Mill", true, COURSE_DDD, 1)
    add_star_name("Way Too Easy Coins", true, COURSE_DDD, 2)
    add_star_name("The Unstable Wooden Construction", true, COURSE_DDD, 3)
    add_star_name("Not So Secret Cavern", true, COURSE_DDD, 4)
    add_star_name("Bark Beetle Jumps", true, COURSE_DDD, 5)
    add_star_name("Fire Up Those 100 Coins", true, COURSE_DDD, 6)

    add_star_name("Secret of the Smaragds", true, COURSE_SL, 0)
    add_star_name("Hot Pole-Dance", true, COURSE_SL, 1)
    add_star_name("Somewhere in the Nowhere", true, COURSE_SL, 2)
    add_star_name("Nowhere in the Somewhere", true, COURSE_SL, 3)
    add_star_name("Cold Tomb", true, COURSE_SL, 4)
    add_star_name("Hemoglobin-Coins", true, COURSE_SL, 5)
    add_star_name("Windswept Beach Hundred", true, COURSE_SL, 6)

    add_star_name("Burning Feet", true, COURSE_WDW, 0)
    add_star_name("Airy Stored Coins", true, COURSE_WDW, 1)
    add_star_name("The Old Hideout", true, COURSE_WDW, 2)
    add_star_name("Grave Digger", true, COURSE_WDW, 3)
    add_star_name("Cemetary Artistics", true, COURSE_WDW, 4)
    add_star_name("The Sand Plateau's Torture", true, COURSE_WDW, 5)
    add_star_name("Dried-Out Folliful Greed", true, COURSE_WDW, 6)

    add_star_name("Move Your Butt up There!", true, COURSE_TTM, 0)
    add_star_name("Way Too High", true, COURSE_TTM, 1)
    add_star_name("Another Problematic Box", true, COURSE_TTM, 2)
    add_star_name("Heave-Ho Cave", true, COURSE_TTM, 3)
    add_star_name("You-Can-Guess-Which Coins", true, COURSE_TTM, 4)
    add_star_name("Brazenly Placed", true, COURSE_TTM, 5)
    add_star_name("Pain of 100 Coins", true, COURSE_TTM, 6)

    add_star_name("Welcome to the Acid Swamp", true, COURSE_THI, 0)
    add_star_name("Eye to Eye", true, COURSE_THI, 1)
    add_star_name("Acidproof Boxes", true, COURSE_THI, 2)
    add_star_name("In the Big Cave", true, COURSE_THI, 3)
    add_star_name("Another Climbing Challenge", true, COURSE_THI, 4)
    add_star_name("Lava-Colored Glitter", true, COURSE_THI, 5)
    add_star_name("100 Acid-Tainted Coins", true, COURSE_THI, 6)

    add_star_name("The Same Place in a Worse World", true, COURSE_TTC, 0)
    add_star_name("Through the Heart of the World", true, COURSE_TTC, 1)
    add_star_name("The Edge of the World", true, COURSE_TTC, 2)
    add_star_name("The Roof of the World", true, COURSE_TTC, 3)
    add_star_name("Worldwide Pain", true, COURSE_TTC, 4)
    add_star_name("Bloodred Coins of Ruination", true, COURSE_TTC, 5)
    add_star_name("Sick-Yellow Coins of Malignancy", true, COURSE_TTC, 6)

    add_star_name("The Nightmare Begins", true, COURSE_RR, 0)
    add_star_name("Just Go Crazy", true, COURSE_RR, 1)
    add_star_name("Straight from Hell", true, COURSE_RR, 2)
    add_star_name("Traumatising Experience", true, COURSE_RR, 3)
    add_star_name("Morbid Deadly Puzzle", true, COURSE_RR, 4)
    add_star_name("Bloody Scream of Rage", true, COURSE_RR, 5)
    add_star_name("One Hundred Lashes", true, COURSE_RR, 6)

    add_star_name("Beautiful Backyard Adornment", true, COURSE_BITDW, 0)
    add_star_name("Lost to the Backyard Corner", true, COURSE_BITDW, 1)
    add_star_name("Backyard Battlement Stash", true, COURSE_BITDW, 2)
    add_star_name("Red Complements Backyard Green", true, COURSE_BITDW, 3)

    add_star_name("Pro: Great View; Con: Quicksand", true, COURSE_BITFS, 0)
    add_star_name("Quicksand Mountain Surfin'", true, COURSE_BITFS, 1)
    add_star_name("A Sinking Feeling in the Pit", true, COURSE_BITFS, 2)
    add_star_name("Precarious Quicksand Parkour", true, COURSE_BITFS, 3)
    add_star_name("Quicksand, Not the Red You Want", true, COURSE_BITFS, 4)

    add_star_name("Shattered Zig-Zag Plasma Path", true, COURSE_BITS, 0)
    add_star_name("A Quick Zip Underneath", true, COURSE_BITS, 1)
    add_star_name("Thirty Red Coins; You Heard Me", true, COURSE_BITS, 2)
    add_star_name("Zoom Back to the Blast Zone", true, COURSE_BITS, 3)
    add_star_name("Zilch Room on the Wall", true, COURSE_BITS, 4)
    add_star_name("One Ztar's Trash...", true, COURSE_BITS, 5)

    add_star_name("Old Supplies' Final Stop", true, COURSE_PSS, 0)
    add_star_name("Supplies Thrown Aside", true, COURSE_PSS, 1)
    add_star_name("Express Supply Delivery", true, COURSE_PSS, 2)
    add_star_name("The 8 Precious Red Packages", true, COURSE_PSS, 3)

    add_star_name("Toxic Pillar Leap Frog", true, COURSE_COTMC, 0)
    add_star_name("Caustic Toxi-fall Climb", true, COURSE_COTMC, 1)
    add_star_name("In the Biting Maw of Toxins", true, COURSE_COTMC, 2)
    add_star_name("Mind the Thin Toxic Path", true, COURSE_COTMC, 3)
    add_star_name("Surmount the Terrace", true, COURSE_COTMC, 4)
    add_star_name("Toxin-Corroded Red Coins", true, COURSE_COTMC, 5)

    add_star_name("Boiling in the Devil's Pool", true, COURSE_TOTWC, 0)
    add_star_name("Fly into the Devil's Skies", true, COURSE_TOTWC, 1)
    add_star_name("Eight Deadly Demon Coins", true, COURSE_TOTWC, 2)

    add_star_name("As Dust Floats Down to the Side", true, COURSE_VCUTM, 0)
    add_star_name("Vanish Quick Before They Do", true, COURSE_VCUTM, 1)
    add_star_name("A Dance over Dusty Depths", true, COURSE_VCUTM, 2)
    add_star_name("Destination: The Structure Top", true, COURSE_VCUTM, 3)
    add_star_name("Leap into the Duststorm", true, COURSE_VCUTM, 4)
    add_star_name("Red Coins Dustswept Blue", true, COURSE_VCUTM, 5)

    add_star_name("Red Lake Lord Wealth", true, COURSE_WMOTR, 0)
    add_star_name("Bowser's Lake Barricade", true, COURSE_WMOTR, 1)
    add_star_name("Slip Jumps Over the Lake", true, COURSE_WMOTR, 2)
    add_star_name("Lords Observe Your Wall Kicks", true, COURSE_WMOTR, 3)
    add_star_name("Little Lake Jump Course", true, COURSE_WMOTR, 4)
    add_star_name("The Lords' Sneaky Prank", true, COURSE_WMOTR, 5)

    add_star_name("You ARE a Supreme Player Right?", true, COURSE_SA, 0)
    add_star_name("Supreme Crane", true, COURSE_SA, 1)
    add_star_name("Supreme Bridge", true, COURSE_SA, 2)
    add_star_name("Supreme Pillar", true, COURSE_SA, 3)
    add_star_name("Supreme Ending", true, COURSE_SA, 4)
    add_star_name("Supreme Wall", true, COURSE_SA, 5)
    add_star_name("Supreme Underside", true, COURSE_SA, 6)

    local function get_key_calc_index(areaIndex, levelNum)
        return areaIndex * 100 + levelNum
    end

    local function get_key_calc_args(star)
        local localPly = gNetworkPlayers[0]

        return localPly.currAreaIndex, localPly.currLevelNum
    end

    local function add_key_name(keyName, isEE, levelNum)
        _G.progressPopupsLib.change_handler_data(
            "bowser_key",
            "key_info",
            keyName,
            nil,
            nil,
            isEE and 2 or 1,
            levelNum
        )
    end

    _G.progressPopupsLib.reallocate_handler_count("bowser_key", 4)
    _G.progressPopupsLib.change_handler_data(
        "bowser_key",
        "save_index_info",
        get_key_calc_index,
        nil,
        get_key_calc_args
    )

    add_key_name("Badlands Bowser Battle", false, LEVEL_BOWSER_1)
    add_key_name("Bowser Under the Lake", false, LEVEL_BOWSER_2)

    add_key_name("Weed Out Bowser", true, LEVEL_BOWSER_1)
    add_key_name("A Sinking Bowser Feeling", true, LEVEL_BOWSER_2)
end

require_progress_popups(
    --//==================================\\
    --||CHANGE ADDON ID TO YOUR OWN STRING||
    --\\==================================//
    "sm74_mod",

    main,

    {
        --//============================================\\
        --||ADD COMMA-SEPARATED IDS OF DEPENDENCIES HERE||
        --||      LEAVE EMPTY FOR NO DEPENDENCIES       ||
        --\\============================================//

        "power_star_handler",
        "bowser_key_handler"
    }
)