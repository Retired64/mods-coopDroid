smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, ("This maze here...\
is impossible. Your only\
chance of beating it\
and finding the golden\
treasure of treasureness\
is to cheat.\
\
\
\
Not really... but if\
you REALLY want that\
super awesome treasure\
of memes, then cheat\
my child! CHEAT!\
3F.\
50^\
51|\
52<\
53>\
54[A]\
55[B]\
56[C]\
57[Z]\
58[R]\
6F,\
9E \
9F-\
D -- I'm stable!"))

smlua_text_utils_dialog_replace(DIALOG_001,1,4,95,200, ("Rest In Peace:\
My Dear Old Brother\
You Met Me Me\
And My Mother\
If Only You Could\
If Only You Would\
See the Light\
The Way I-\
\
\
\
SHUT UP YOU STUPID\
CULTISTS CAN'T YOU SEE\
I'M A POET WHO DOESN'T\
EVEN KNOW IT?!?!?!"))

smlua_text_utils_dialog_replace(DIALOG_002,1,4,95,200, ("For the past six\
months, a strange event\
occurs where six or more\
bobombs go into the\
pipe and drain all the\
water aside from one\
lake. They even drained\
this one, and I don't\
even think it WAS water."))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("For finding me and\
not trying to pick\
me and do... stuff...\
I will give you some\
advice. Some levels \
have prankster comets\
that come and ruin\
everything. Though,\
aside from the stupid\
purple ones that make \
your money purple,\
they're pretty rare.\
You'll find a speedy\
comet and maybe a\
daredevil comet or two,\
but I'm betting you\
will find a purple coin\
comet. Just make sure\
your wallet is \
protected..."))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, ("I've never seen thi\
place I used to\
call home be so\
quiet since we\
first got here...\
\
\
\
This is the worst\
day of my life.\
Dad is dead. My\
family has left\
me and my cousin\
over there.\
\
\
\
We're going to\
nighttime valley,\
where Bowser's Castle\
is later.\
Yes, I'll start the\
cannon..."))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, ("Hey, Mario! Is it true\
that you beat the Big\
Bob-omb? Cool!\
You must be strong. And\
pretty fast. So, how fast\
are you, anyway?\
Fast enough to beat me...\
Koopa the Quick? I don't\
think so. Just try me.\
How about a race to the\
mountaintop, where the\
Big Bob-omb was?\
Whaddya say? When I say\
『Go,』 let the race begin!\
\
Ready....\
\
//Go!////Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Hey!!! Don't try to scam\
ME. You've gotta run\
the whole course.\
Later. Look me up when\
you want to race for\
real."))

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, ("Hufff...fff...pufff...\
Whoa! You...really...are...\
fast! A human blur!\
Here you go--you've won\
it, fair and square!"))

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, ("Welcome to The Violet Stars.\
This was created by... \
some guy. Who made it \
wasn't important.\
Bowser is trying to\
do evil things like\
... evil things, so you\
must stop him. This\
time, he's put these\
random doors in your\
path to slow you\
down, and you can't\
squish by them because\
Bowser's a sneaky little\
crap. He's also made\
his arenas entirely out of\
the souls of dead\
pokemon, so you'll\
go deaf and have to\
reset the game after\
fighting... No new objects\
due to the game crashing.\
Sorry."))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Hey there. What? I'm\
in this trench because\
I want to be.\
\
What? You want to\
race? What the hell\
does that mean?\
Who's Kappa teh quack?\
Never heard of him or\
her.\
\
Fine. I can race with\
you in this infinite\
trench that only I\
can get through.\
Ready?\
\
//No//// Still No"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("You've stepped on the\
Wing Cap Switch. Now Mario\
possesses an ability\
which allows him to\
spread his pollution\
while airborn.\
\
Would you like to Save?\
\
//Sure////Ew"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("You've just stepped on\
the Metal Cap Switch!\
Luigi has gained\
10,000 freaking pounds.\
\
Would you like to Save?\
\
//Yes////Uh-oh"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("You've just stepped on\
the Vanish Cap Switch.\
Not that hard of a\
task, really. Nore was\
it a challenge.. Am I \
right?\
\
Would you like to Save?\
\
//Yes////WAHH"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("You've collected 100\
coins! Luigi gains more\
money to buy more\
shrooms. What do you\
think?\
//Yes////Oh no..."))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Wow! A star!\
Luigi gains more courage\
from the power of the\
world.\
Do you want to Save?\
\
//What?//Not Now!!!"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("Thanks to these expertese\
for the music used:\
cpuHacka\
Mosky2000\
Mr Green Thunder\
Quote\
Sanji02\
Shrooboidbrat\
Pieordie\
Pablo's Corner for the \
star selection theme!\
\
Thanks to these people for\
the textures used:\
Quote\
cpuhacka101\
Mr Green Thunder"))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("These fiery caves are\
really really hot. Those\
water caves are really\
really wet. And that grass\
ravine isn't anything\
special so it can piss\
off!\
Want to know a hint? If\
you ground pound after\
the tip top of a triple\
jump, then you will gain\
enough height to grab any\
red coin that's too high.\
Neat huh? How does it work?\
\
\
\
Ummm... Luigi's kind of\
a magici-\
DON'T LOOK AT ME LIKE THAT\
I was only trying to\
help!"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("I'm the Big Bob-omb, lord\
of all blasting matter,\
king of ka-booms the\
world over!\
How dare you scale my\
mountain? By what right\
do you set foot on my\
imperial mountaintop?\
You may have eluded my\
guards, but you'll never\
escape my grasp...\
\
...and you'll never take\
away my Power Star. I\
hereby challenge you,\
Mario!\
If you want the Star I\
hold, you must prove\
yourself in battle.\
\
Can you pick me up from\
the back and hurl me to\
this royal turf? I think\
that you cannot!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("Despite this cave\
being so hot I have to\
walk 0.0000003101\
percent faster, I open\
my non-existant jaw at this\
wooden box sitting here!"))

smlua_text_utils_dialog_replace(DIALOG_019,1,2,30,200, ("How the flying fuck did\
you get up here? No I have\
no ★!"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("Dear Luigi:\
Please come to the\
castle. I've baked\
a cake for you.\
Yours truly--\
Princess Toadstool"))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, ("Welcome.\
No one's home!\
Now scram--\
and don't come back!\
Gwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("You need a key to open\
this door. Stupid, did\
you not see the giant\
tatoo printed on the door?"))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, ("This key doesn't fit.\
Get a different one."))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, ("Get more stars, you don't\
have enough. You never have\
enough."))

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, ("It takes the power of\
3 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, ("It takes the power of\
8 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, ("It takes the power of\
30 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_028,1,4,95,200, ("It takes the power of\
50 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, ("To open the door that\
leads to the 『endless』\
stairs, you need 70\
Stars.\
Bwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, ("Mmmm! This is the greatest\
mud in the world! Yes, I'm\
aware it's not chocolate.\
Chocolate is disgusting...\
You can leave, now, I'm eating\
meh dirts."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("Spoiler. This trench\
was never infinite.\
Ever. Take the star.\
I only have it from\
my savings I don't\
need."))

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, ("God, guys, this fire\
is so great in that\
it never even lit up\
five feet in front\
of it. It's so nice!"))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, ("I know! I would have more,\
but that only tree that\
supplies us with air\
needs to love, so let's\
go near the purple\
goo over there once this\
tiny-ass fire burns up."))

smlua_text_utils_dialog_replace(DIALOG_034,1,6,30,200, ("Welcome sir! To my\
gold diggin' valley.\
I did not steal this\
from Wario, I promise!\
\
\
\
You need to know a\
few things, first!\
One: Don't fall in\
love with any of\
my children, ever!\
Two: Don't screw with\
me, or I'll have you\
more bent than a\
newspaper!\
Three: This gold is\
ours.\
Four: That black bobomb\
is real trouble, and\
you should hate him\
like I do!"))

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, ("Yo dude! Want to know a\
hint? That door requires\
65 stars to enter. Or\
6500000 coins. Sadly, I\
only have 5999999 coins,\
and the other guys\
won't share theirs.\
Jerks."))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("OBSERVATION PLATFORM\
Press [C]^ to take a look\
around. Don't miss\
anything!\
\
Press [R] to switch to\
Mario's camera. It\
always follows Mario.\
Press [R] again to switch\
to Lakitu's camera.\
Pause the game and\
switch the mode to 『fix』\
the camera in place while\
holding [R]. Give it a try!"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("I win! You lose!\
Ha ha ha ha!\
You're no slouch, but I'm\
a better sledder!\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("Reacting to the Star,\
the squeaks open."))

smlua_text_utils_dialog_replace(DIALOG_039,1,4,30,200, ("My husband is the\
nastiest thing that\
ever met me! I only\
married him when he\
WASN'T digging gold\
and bringing everything\
along with him. The\
poor children have to\
work for nothing, I\
can't do anything\
because this guy is\
a... you know. And\
worst of all, poor\
Tommy is stuck removing\
the fool's gold and\
selling that to the\
homeless! What a \
nightmare. This\
rebellion the children\
are planning better\
work out!"))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("Dude! I can't share\
beds with these\
guys anymore! We\
need to leave!"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("I win! You lose!\
Ha ha ha!\
\
That's what you get for\
messin' with Koopa the\
Quick.\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,4,30,200, ("I know! Dad's going\
nuts over here and \
won't let us even peep\
our heads past these\
hills! Don't worry,\
the rebellion is\
starting in a few\
days."))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("I hope Dad's not\
gonna get mad at me\
for digging to the\
center of the Earth.\
I hope so... I hope\
so..."))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("Oh my god! I found\
gold! GOLD GOLD GOLD\
GOLD GOLD! I found\
gold! WOOOHOOOO!\
It's all mine once\
tomarrow rolls around!\
HAHAHHAHAHA!"))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, ("Hi! Yes, I'm Tommy.\
What? I'm not the\
black sheep of the \
family... that would\
be the idiot who dug\
that giant dirt pillar\
over there! I'm hated\
by dad because he sees\
me as a minion to\
king koopatastrophy.\
But, I'm such a good\
person I swear! Tell \
you what? Get me out\
of here and I'll tell\
you a hint back at\
your place!"))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("Pssst! Listen dude!\
Come tomarrow! The\
rebellion starts\
tomarrow! Listen very\
carefully.\
\
\
\
Daddy\
\
\
\
is\
\
\
\
gonnna\
\
\
\
die."))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Hi! I'll prepare the\
cannon for you!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, ("BURN! BURN!\
BURN THE MAN WITCH!\
BURN BURN!\
BURN YOU MAN WITCH!\
MANWITCH! MANWITCH!"))

smlua_text_utils_dialog_replace(DIALOG_049,1,5,30,200, ("Hey buddy! You trust\
me right? Good. I have\
a small little secret\
in the mines over there\
yeah? You want it. Go get\
it and bring it to me\
to help me! I can't\
die like this when Tom\
boy over there lives!"))

smlua_text_utils_dialog_replace(DIALOG_050,1,4,30,200, ("They seem to be\
talking in a\
language you don't\
understand.\
MEEP MEEP MEMEEP MEEP\
MEEP. \
Huh. Too bad your too\
stupid to understand\
what they're saying...\
or doing."))

smlua_text_utils_dialog_replace(DIALOG_051,1,6,30,200, ("You found me! I've \
been sitting up here\
since those whomps\
been livin' here!\
Thank you! What?\
Join my sister over\
there to the nightly\
valley where king krappa\
lives? Of course \
master! I'd love to.\
Thank you for saving\
me!"))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("I think I'm gonna die!\
This sand and heat is\
killing m-\
\
\
\
WATER! WATER! SAVE\
ME I NEED WATER!"))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("Dude... we're allergic\
to water. Also, your\
only REAL worry is if\
some blockhead decides\
to light your fuse.\
THEN things will be\
bad. You'll never walk\
again..."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("Don't mind me sir! I'm\
just dazzled by this fine\
art. This fork here\
repressents the pain\
everyone carries to\
stab another pal of\
theirs, and this thing\
represents the cake\
that we could never eat.\
What? Purple coins? Those\
things? Use that tree\
over there to jump\
on to them. Just be\
careful!"))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("Hey-ey, Luigi, buddy,\
howzit goin'? Step right\
up. You look like a fast\
sleddin' kind of guy.\
I know speed when I see\
it, yes siree--I'm the\
world champion sledder,\
you know. Whaddya say?\
How about a race?\
Ready...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("You brrrr-oke my record!\
Unbelievable! I knew\
that you were the coolest.\
Now you've proven\
that you're also the\
fastest!\
I can't award you a gold\
medal, but here, take this\
Star instead. You've\
earned it!"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Excuse me mister? Little\
Mica is lost with the\
rest of my children. Yes\
ALL OF THEM are mine.\
I hate when people\
like you ask that.\
Like you people don't\
have your own 9\
children! Jeese! Can\
you find her? A hint?\
Umm... she has a beak."))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("HOLY CRAP! You found\
her? I couldn't find\
her THAT easily... and\
I checked to see which \
penguin was which! By\
using the method of\
looking 『under』 if you\
know what I mean. Here,\
have this star. By the \
way, soon there will\
be a musical purple comet,\
where the coins create\
random noises, including\
noises you've made!\
It'll be fun. I'll\
lose my baby, too!"))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("Nope... that's not my\
baby. That's... acutally,\
I forgot. Tommy? Will?\
Dick? Kermit? No...\
look for the female\
one. Just don't give\
up!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("Dear Luigi,\
We hate you.\
-Diamonds\
\
No, but seriously. We're\
on strike because\
you treat us like tools.\
I mean, can't we use the\
water raising feature\
of our souls to take\
over the world? No?\
Then it's settled.\
We left a little\
gift for in the caverns\
down below. However, you\
have to get it without\
our assistant.\
\
\
Toodles!\
--Diamonds\
\
P.S. For a 'triple\
-jump-dive' jump kick,\
jump, and then on\
the third jump\
dive to reach the\
platforms."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("To get over to that\
side way over there,\
where Mr. I is,\
you need to climb\
on the ceiling of\
this large incompetant\
box. How? Hold A ([A])\
when you touch the\
ceiling and you will\
climb it. Ten years\
later, you've made it\
to the end!"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("Hidden inside the green\
block is the amazing\
Metal Cap.\
Wearing it, you won't\
catch fire or be hurt\
by enemy attacks.\
You don't even have to\
breathe while wearing it.\
\
The only problem:\
You can't swim in it."))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("The Vanish Cap is inside\
the blue block. Mr. I.\
will be surprised, since\
you'll be invisible when\
you wear it!\
Even the Big Boo will be\
fooled--and you can walk\
through secret walls, too."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("When you put on the Wing\
Cap that comes from a\
red block, do the Triple\
Jump to soar high into\
the sky.\
Use the Control Stick to\
guide Mario. Pull back to\
to fly up, press forward\
to nose down, and press [Z]\
to land."))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("My gosh, this job sucks.\
All we ever do is ride\
in a straight line\
towards Bowser's\
supposedly 'Silent'\
Arena. If it's this\
far away, why the\
flying frick are we\
bringing three dogs?!"))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("Every gambler knows\
the secret to survival\
is knowing what to\
throw away\
knowing what to keep\
and every man's a winner\
and every man's a loser\
and the best that you can\
hope for is to die in\
the streets."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("(Sign Language)\
Well, well, well. Look\
who we have here. This\
is my silent arena.\
Only the loudest fucking\
volcano in the world.\
Here, your ears\
will bleed and fall\
and rott. Luckily,\
you can get replacement\
ears right after this\
battle (and another\
commercial break.)"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("My apology my dear,\
my dogs are quite rude \
as this trip has been\
going on for nine days.\
The arena is only a \
few more hours away!\
If you want anything,\
that pink bobomb over\
there will open the \
cannons... or just use\
the pipes we laid out."))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("You should only read\
this sign after you've\
beaten Bowser's Silent\
Arena and your sound\
has broken. Otherwise,\
it won't make sense.\
\
\
\
\
Dear Luigi,\
You're deaf. Reset the\
game (or in Mario's case,\
go back home using a\
simple button) to fix this.\
I apologize deeply, but\
it will happen again,\
be weary of it doing\
so.\
\
--James"))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("Listen up, here! This\
valley here is made\
entirely of molten\
lava. It's a deadly\
place. Completely\
lava hot. If you touch\
anything that's red,\
you will burn. Even \
your own hat. But,\
there are some tips\
I have for you.\
First off, the metal\
cap is hidden secretly\
in this course. Second,\
with the metal cap,\
you can bounce off\
walls because they're\
molten lava! Third, \
Bowser's second\
deafening arena is\
somewhere around in\
the molten mills\
course that the\
metal cap is in.\
Keep your nose up."))

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, ("This box does not mean\
that you missed the\
vanish cap switch,\
because it's somewhere\
around here... just not\
right here.\
Interesting..."))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("As you see, this coin\
is red, but only counts\
as one coin. This is\
a 'teleporter' coin. You'll\
find these scattered\
throughout the courses\
and they're are \
manditory for beating\
this game."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Alright, guys. It's time\
once again for another\
meeting at the\
castle. Pack up and\
let's get a head\
start of the girls."))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("WONDERFUL! I'M 'SOOOO'\
EXCITED. JEE WEE!"))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("Gosh, lighten up you\
two. Today is such\
a beautiful day. The \
journey may take a\
few hours, but at least\
those hours will be\
fun hours."))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("Another meeting. More\
time with the boys,\
more time with you\
two lazy rascals. More\
time to waste. Woo."))

smlua_text_utils_dialog_replace(DIALOG_077,1,2,150,200, ("Let's wait for that\
comet that's coming\
before we go there.\
There's a gray one\
and a purple one: lets\
wait for one."))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("Why hello there. You\
seem kind. Are you\
sure YOU aren't single,\
because. Oh my."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("Owwwuu! Let me go!\
Uukee-kee! I was only\
teasing! Can't you take\
a joke?\
I'll tell you what, let's\
trade. If you let me go,\
I'll give you something\
really good.\
So, how about it?\
\
//Free him/ Hold on"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("Eeeh hee hee hee!"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("IM COMING!!! HOLD\
YOUR HORSES LADY!"))

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, ("Hold on to your hat! If\
you lose it, you'll be\
injured easily.\
\
If you do lose your Cap,\
you'll have to find it in\
the course where you\
lost it.\
Oh, boy, it's not looking\
good for Peach. She's\
still trapped somewhere\
inside the walls.\
Please, Mario, you have\
to help her! Did you know\
that there are enemy\
worlds inside the walls?\
Yup. It's true. Bowser's\
troops are there, too.\
Oh, here, take this. I've\
been keeping it for you."))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("There's something strange\
about that clock. As you\
jump inside, watch the\
position of the big hand.\
Oh, look what I found!\
Here, Mario, catch!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Yeeoww! Unhand me,\
brute! I'm late, so late,\
I must make haste!\
This shiny thing? Mine!\
It's mine. Finders,\
keepers, losers...\
Late, late, late...\
Ouch! Take it then! A\
gift from Bowser, it was.\
Now let me be! I have a\
date! I cannot be late\
for tea!"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("Hurry up you twit!\
We ain't got all day\
ya know! That sun may\
always shine, but we\
won't have light in a\
few hours!"))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("I wanna cry right now.\
This is the greatest\
view ever made. Oh my\
gosh. Let's do the\
meeting out here!"))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("I wonder why those\
three are so slow\
today? I know it's\
a meeting but the \
quicker we get it \
done that quicker we'll\
be home."))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("My oh my. These flowers\
are so soft. I love them!"))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("I hate being the\
fastest. You end up\
waiting twenty hours\
for your siblings\
to catch up. Then, \
when the destination\
is reached, you're all\
alone."))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("LETS BURN THE CLOUDS"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("Naah.\
We tried that already."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("(Sign Language)\
Welcome Luigi! I\
stole this arena\
from some handy handy\
hands. Thus, here we\
are. This time, we're\
in space... or some\
really dark place\
that will deafen you.\
I'm ammune to this\
because... wait...\
AHHHHHHHHHHH!\
Whatever, I'll\
just get new ears. It\
worked last time..."))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("This time, I've come\
prepared. I have\
my old arena that I\
painted blue. I\
removed the pieces\
because when those didn't\
work it made me sad.\
\
\
\
Also, I made myself\
rainbows because it\
TOTALLY worked last\
time didn't it?"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("Let's use that star\
we found on the \
pillars a few nights\
ago!"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("Man... it's such a\
nice day outside. I\
really wanna go outside,\
but that would be\
rude to my brothers\
and sisters. Sigh."))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("I cannot believe\
she's still at the\
toilet. She's been\
giggling and making\
gargling noises since\
sunrise. What is she\
doing?"))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("Hehehehehe! I hid\
that star we found\
earlier today under\
the garden, and\
in a few months I will\
be the richest woman\
alive! Hehehehe!"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("Come on in here...\
...heh, heh, heh..."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("Gosh, it's been so wet\
here lately. The only\
water I don't see is\
the rocks! Even then,\
they are rocks..."))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("Ukkiki...Wakkiki...kee kee!\
Ha! I snagged it!\
It's mine! Heeheeheeee!"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("Ackk! Let...go...\
You're...choking...me...\
Cough...I've been framed!\
This Cap? Oh, all right,\
take it. It's a cool Cap,\
but I'll give it back.\
I think it looks better on\
me than it does on you,\
though! Eeeee! Kee keee!"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("I think the rain is\
nice here. It smells\
lovely, the sun\
won't give me any\
form of cancer or\
light my fuse. If\
anything, my fuse will\
never light, and the\
hospital is only\
a dream!"))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Ugh... where did these\
rocks come from?"))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("Right now, I'm just\
fixing this roof. It\
has another leak\
and god it's annoying\
to hear\
DRIP\
DROP\
DRIP\
DROP\
DROP\
DRIP\
for nine hours ever\
night."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Go into the can...\
\
I think I'm gonna\
cry."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("That is one ghost out\
of five.\
Make sure you defeat\
them and remain alive..."))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("A sudden thump is heard\
at the gate.\
Make it there before\
it's too late...\
to get new underwear.\
It's filled with shate.\
You've ruined your\
plate."))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("Ooooo Nooooo!\
Talk about out-of-body\
experiences--my body\
has melted away!\
Have you run in to any\
headhunters lately??\
I could sure use a new\
body!\
Brrr! My face might\
freeze like this!"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("I need a good head on my\
shoulders. Do you know of\
anybody in need of a good\
body? Please! I'll follow\
you if you do!"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Perfect! What a great\
new body! Here--this is a\
present for you. It's sure\
to warm you up."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("This water is lower\
than usual. WAIT. Now\
it's higher than usual.\
WAIT. Now it's lower\
than usual. WAIT. Now\
it's higher than usual.\
WAIT. Now it's lower\
than usual. WAIT. Now\
it's higher than usual."))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("I'm out of drinks guys!\
You've already payed up\
and drank your wines,\
go somewhere else! I'm\
out of drinks!"))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("IT PISSES ME THE\
CRAP OFF THAT YOU\
GUYS KEEP INVADING\
MY LAND! JUST FIRE MY\
DUDES FROM YOUR\
SUPER HARD LANDS AND\
WE BE ON OUR WAYS!\
I CRUSH YOU NOW!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("Goddammit! Ouch!\
\
Argh!\
\
\
\
Did I save me friends?\
\
\
\
Wait... they were never\
in any danger?\
Crap."))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Whaaa....Whaaat?\
Can it be that a\
pipsqueak like you has\
defused the Bob-omb\
king????\
You might be fast enough\
to ground me, but you'll\
have to pick up the pace\
if you want to take King\
Bowser by the tail.\
Methinks my troops could\
learn a lesson from you!\
Here is your Star, as I\
promised, Mario.\
\
If you want to see me\
again, select this Star\
from the menu. For now,\
farewell."))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Luigi... you... tiny\
... weakling followed\
us... and... now...\
we... must... fight...\
for... terr... it...\
or...y....\
Now... enough...\
... dilly... dally\
... in... g...\
\
\
\
LETS BATTLE!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Alright! Fine! Just\
take this... mountain.\
We don't need it.\
Besides, we're going\
to tell on Bowser for\
what you did to us.\
Yes. We speak perfect\
english."))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("(Sign Language)\
Well, I've certainly\
underestimated your\
ears. I should've made\
this arena in space...\
THAT'S IT! Hmmm... but\
where. Well, I did\
just buy this land of\
these windmill-\
WAIT STOP LISTENING\
YOU CREEP!"))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("(Sign Language)\
REALLY?! IN A BLIZZARD!\
HOW IN THE WORLD CAN\
I BEAT SOMEONE WHO\
CAN KILL ME TWICE,\
EVEN IN A BLIZZARD!\
SERIOUSLY! \
\
\
\
Sigh...\
\
\
\
See you in my\
nitrogen fortress!\
I should have my new\
ear replacements\
again! Bwaha\
-ACHOO!"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Oh no! Nooooo!\
I really wanted to\
beat you this\
time. Sniff... go \
ahead, take the star\
and go. Just go. I don't\
need happiness or\
anything to make me\
happy. All I need is\
the constant repeating\
of my life in order to\
finally find some point.\
You heroes think your\
soooo cool with your\
special abilities and\
generous deeds. Huh?\
Well, news flash. \
You aren't that\
special. Give some other\
people a chance...\
Go."))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("These wines are bland.\
I want a different\
one, he wants his\
to have his fly in his\
removed, and he has\
gunpowder from YOU.\
Get us new drinks.\
\
\
\
(Yes, I know he's out.\
His reactions are just\
HILARIOUS)"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("I think this drink\
is quite good and\
poetic. Hmm. It's all\
coming to me.\
\
\
\
The green represents the\
happy tone I get from\
drinking, and the black\
represents the flaws\
that you cannot see.\
The straw is the small\
imperfection you can\
see. Woah. Deep."))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("WHERE'S MY MONEY?!\
WHERE'S MY MONEY!?\
WHERE'S MY HONEY?!\
WHERE'S MY DUMMY?!"))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("How do you get the\
star in that tube\
over there?"))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("I wonder where the\
other guy went. I've\
been sitting here for\
eight hours, and he\
still hasn't returned\
from his hike. We need\
him to make a fire!"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Man this is a nice\
fire I'm imagining.\
Seriously, WHEN WILL\
HE GET BACK?!"))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("You must fight with\
honor! It is against the\
royal rules to throw the\
king out of the ring!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("Welcome to the Vanish\
Cap Switch Course! All of\
the blue blocks you find\
will become solid once you\
step on the Cap Switch.\
You'll disappear when you\
put on the Vanish Cap, so\
you'll be able to elude\
enemies and walk through\
many things. Try it out!"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("Welcome to the Metal Cap\
Switch Course! Once you\
step on the Cap Switch,\
the green blocks will\
become solid.\
When you turn your body\
into metal with the Metal\
Cap, you can walk\
underwater! Try it!"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("Welcome to the Wing Cap\
Course! Step on the red\
switch at the top of the\
tower, in the center of\
the rainbow ring.\
When you trigger the\
switch, all of the red\
blocks you find will\
become solid.\
\
Try out the Wing Cap! Do\
the Triple Jump to take\
off and press [Z] to land.\
\
\
Pull back on the Control\
Stick to go up and push\
forward to nose down,\
just as you would when\
flying an airplane."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Whoa, Luigi, pal, you\
aren't trying to cheat,\
are you? Shortcuts aren't\
allowed.\
Now, I know that you\
know better. You're\
disqualified! Next time,\
play fair!"))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("Am I glad to see you! The\
Princess...and I...and,\
well, everybody...we're all\
trapped inside the castle\
walls.\
\
Bowser has stolen the\
castle's Stars, and he's\
using their power to\
create his own world in\
the paintings and walls.\
\
Please recover the Power\
Stars! As you find them,\
you can use their power\
to open the doors that\
Bowser has sealed.\
\
There are four rooms on\
the first floor. Start in\
the one with the painting\
of Bob-omb inside. It's\
the only room that Bowser\
hasn't sealed.\
When you collect eight\
Power Stars, you'll be\
able to open the door\
with the big star. The\
Princess must be inside!"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("That large tree has\
a pink spot on it.\
I wonder if that's...\
nah. Can't be. It'd\
be too stupid."))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("Hey you found me!\
I was just hiking\
up this tree when \
I got the brillian\
idea to literally\
climb it. No birds\
nest. This game is\
too rushed for that.\
\
\
\
The star you're looking\
for is in the trees\
over there. It doesn't\
work? It must've been\
a star to fool you\
so you wouldn't\
collect the new one.\
I can fix it for you!\
Get it! I promise it\
will work this time."))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("Wow! You've already\
recovered that many\
Stars? Way to go, Mario!\
I'll bet you'll have us out\
of here in no time!\
\
Be careful, though.\
Bowser and his band\
wrote the book on 『bad.』\
Take my advice: When you\
need to recover from\
injuries, collect coins.\
Yellow Coins refill one\
piece of the Power Meter,\
Red Coins refill two\
pieces, and Blue Coins\
refill five.\
\
To make Blue Coins\
appear, pound on Blue\
Coin Blocks.\
\
\
\
Also, if you fall from\
high places, you'll\
minimize damage if you\
Pound the Ground as you\
land."))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("Thanks, Luigi! The castle\
is recovering its energy\
as you retrieve Power\
Stars, and you've chased\
Bowser right out of here,\
on to some area ahead.\
Oh, by the by, are you\
collecting coins? Special\
Stars appear when you\
collect 100 coins in each\
of the 15 courses!"))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Man this tent is great!\
If only our friend\
would return and sleep\
in it with me. What?\
It's that great of a\
tent!\
\
\
\
Don't get those dirty\
thoughts in your head."))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("Above: Automatic Elevator\
Elevator begins\
automatically and follows\
pre-set course.\
It disappears\
automatically, too."))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("Elevator Area\
Right: Hazy Maze\
/// Entrance\
Left: Black Hole\
///Elevator 1\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("With one star, you now\
have proven to somebody\
that you can properly\
and trustworthily handle\
a controller. Press '[A]'"))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("Three stars prove even\
less than what one\
star proves because it\
shows me that you expect\
me to praise YOU HAHAHA!"))

smlua_text_utils_dialog_replace(DIALOG_143,1,6,150,200, ("Stop calling me ma! I'm\
talking to this loser who\
expects me to compliment\
him! Oh, yeah, get more\
stars to go to the\
airships and stuff."))

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, ("Collect ten more stars and\
you can go to the third\
overworld, which contains\
some spooky stuff. Things\
won't be easy anymore.\
Mm Mm Mmmm. Yummy."))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("Oh wow! Ten stars until\
you can access Bowser's\
arena which actually\
contains sound! That's \
great! Now hurry up\
and get a girlfriend or\
something."))

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, ("These 70 stars show me\
that your trying to\
complete the game.\
That's pretty cool. No\
really, I'm proud of\
you buddy! You have\
a lot to go, so keep\
going! NOW!"))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("Are you using the Cap\
Blocks? You really should,\
you know.\
\
\
To make them solid so you\
can break them, you have\
to press the colored Cap\
Switches in the castle's\
hidden courses.\
You'll find the hidden\
courses only after\
regaining some of the\
Power Stars.\
\
The Cap Blocks are a big\
help! Red for the Wing\
Cap, green for the Metal\
Cap, blue for the Vanish\
Cap."))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("Snowman Mountain ahead.\
Keep out! And don't try\
the Triple Jump over the\
ice block shooter.\
\
\
If you fall into the\
freezing pond, your power\
decreases quickly, and\
you won't recover\
automatically.\
//--The Snowman"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("Welcome to\
Princess Toadstool's\
secret slide!\
There's a Star hidden\
here that Bowser couldn't\
find.\
When you slide, press\
forward to speed up,\
pull back to slow down.\
If you slide really\
fast, you'll win the Star!"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("YOU! I HEAR YOU! DON'T\
COME INTO MY CRIB OR IT\
WILL KILL YOU. THERE'S \
THAT PURPLE GOO THAT\
KILLS YOU SO YOU\
BETTER STAY AWAY YOU\
UGLY SAUSAGE!"))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("How the hell did you\
get in here without\
sinking? Whatever.\
LETS BATTLE LIKE\
MEN! OR WOMEN! I\
DON'T KNOW what\
gender are you?"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("Son of a bitch ya\
got me again. WHEN WILL\
I LEARN? Whatever. I'll\
shrink down only to\
swell up and grow a few\
days later as a star\
comes out of my\
butt. I'll peacefully\
think of another stupid\
arena to sit in..."))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("Hey! Who's there?\
What's climbing on me?\
Is it an ice ant?\
A snow flea?\
Whatever it is, it's\
bugging me! I think I'll\
blow it away!"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("Hold on to your hat! If\
you lose it, you'll be\
easily injured. If you\
lose it, look for it in the\
course where you lost it.\
Speaking of lost, the\
Princess is still stuck in\
the walls somewhere.\
Please help, Mario!\
\
Oh, you know that there\
are secret worlds in the\
walls as well as in the\
paintings, right?"))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting."))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("The world inside the\
clock is so strange!\
When you jump inside,\
watch the position of\
the big hand!"))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("Watch out! Don't let\
yourself be swallowed by\
quicksand.\
\
\
If you sink into the sand,\
you won't be able to\
jump, and if your head\
goes under, you'll be\
smothered.\
The dark areas are\
bottomless pits."))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("1. If you jump repeatedly\
and time it right, you'll\
jump higher and higher.\
If you run really fast and\
time three jumps right,\
you can do a Triple Jump.\
2. Jump into a solid wall,\
then jump again when you\
hit the wall. You can\
bounce to a higher level\
using this Wall Kick."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("3. If you stop, press [Z]\
to crouch, then jump, you\
can perform a Backward\
Somersault. To do a Long\
Jump, run fast, press [Z],\
then jump."))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("Press [B] while running\
fast to do a Body Slide\
attack. To stand while\
sliding, press [A] or [B]."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("Mario!!!\
It that really you???\
It has been so long since\
our last adventure!\
They told me that I might\
see you if I waited here,\
but I'd just about given\
up hope!\
Is it true? Have you\
really beaten Bowser? And\
restored the Stars to the\
castle?\
And saved the Princess?\
I knew you could do it!\
Now I have a very special\
message for you.\
『Thanks for playing Super\
Mario 64! This is the\
end of the game, but not\
the end of the fun.\
We want you to keep on\
playing, so we have a\
little something for you.\
We hope that you like it!\
Enjoy!!!』\
\
The Super Mario 64 Team"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("No, no, no! Not you\
again! I'm in a great\
hurry, can't you see?\
\
I've no time to squabble\
over Stars. Here, have it.\
I never meant to hide it\
from you...\
It's just that I'm in such\
a rush. That's it, that's\
all. Now, I must be off.\
Owww! Let me go!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Welp... crap. What? You\
found a crap ton of stars.\
You know I only placed\
like... ten. The rest were\
from meteor showers,\
pink bombs and Toads.\
Who even cares. You beat\
me. That's all I care\
about. Siiiiigggh."))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("Mario! What's up, pal?\
I haven't been on the\
slide lately, so I'm out\
of shape.\
Still, I'm always up for a\
good race, especially\
against an old sleddin'\
buddy.\
Whaddya say?\
Ready...set...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I take no responsibility\
whatsoever for those who\
get dizzy and pass out\
from running around\
this post."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("I'll be back soon.\
I'm out training now,\
so come back later.\
//--Koopa the Quick"))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("Princess Toadstool's\
castle is just ahead.\
\
\
Press [A] to jump, [Z] to\
crouch, and [B] to punch,\
read a sign, or grab\
something.\
Press [B] again to throw\
something you're holding."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("SUPERSAN MODE ACTIVATED!"))

smlua_text_utils_dialog_replace(DIALOG_169,1,4,30,200, ("Keep out!\
That means you!\
Arrgghh!\
\
Anyone entering this cave\
without permission will\
meet certain disaster."))

