function mario_update(m)
    gNetworkPlayers[m.playerIndex].overrideModelIndex = 1
end

hook_event(HOOK_MARIO_UPDATE, mario_update)