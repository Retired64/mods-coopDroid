smlua_text_utils_course_acts_replace(COURSE_BOB, (" 1 GOLD DIGGIN' VALLEY"),	("KING WHOMP'S REVENGE"),	("STAR OF THE MAGMA VALLEY"),	("A DIRTY PYRAMID"),	("THE REBELLION AGAINST FATHER"),	("THE PODIUM'S RED COINS"),	("SHOOT TO THE MYSTERIOUS MILL"))

smlua_text_utils_course_acts_replace(COURSE_WF, (" 3 STONE MASON"),	("TOP OF THE OL' WINDMIL"),	("SLIDE DOWN THE BIG PYRAMID"),	("RED COINS OF THE MAZE"),	("WALL JUMPS AND PILLAR CLIMBS"),	("STONE PURPLE COIN COMET"),	("SECRET OF THE MAZE"))

smlua_text_utils_course_acts_replace(COURSE_JRB, (" 4 BRONZE-BRASS CAVERNS"),	("DORRY'S RED COINS"),	("WALL JUMP UP THE TUBE"),	("WATCH FOR OBSTACLES!"),	("QUICKSAND CATASTROPHE"),	("QUICKSAND CATASTROPHE DAREDEVIL COMET"),	("METALLIC MARIO UNDER THE ARCH"))

smlua_text_utils_course_acts_replace(COURSE_CCM, (" 2 BRIGHT ICEY CAVERNS"),	("FINDING TUXIE"),	("SLIP SLIDING THROUGH THE CAVERN"),	("THE END OF THE SMOGGY ICE RINK"),	("RED COINS OF THE RINK"),	("BRIGHT YET DARK PURPLE COIN COMET"),	("SHELL UP THE WATERFALL"))

smlua_text_utils_course_acts_replace(COURSE_BBH, (" 5 KING BOO'S CEMETARY"),	("KING BOO'S MAJESTIC MOUNTAIN"),	("GHOST BUSTERS"),	("KING BOO'S DAREDEVIL COMET"),	("PUZZLE OF THE DIAMONDS"),	("CHALLENGE FROM THE DIAMONDS"),	("THE MOUNTAIN'S SECRET TRIALS"))

smlua_text_utils_course_acts_replace(COURSE_HMC, (" 9 DIMLIT CLIFFSIDES"),	("SCALE THE CLIFFSIDE"),	("SCUBA DIVING"),	("WALL JUMPING UP THE OLD RUINS"),	("THE CLIFFSIDE'S DAREDEVIL COMET"),	("SUBMERGED SWITCH"),	("ESCAPE THE CLIFFSIDE"))

smlua_text_utils_course_acts_replace(COURSE_LLL, (" 10 MOLTEN VOLCANO VALLEY"),	("BULLY THE BULLY"),	("MELTED CHOCOLATE COINS"),	("DON'T HUG THE WALLS"),	("MAGMA HOP ON TO THE SIDELINES"),	("PURPLE COMET OVER THE VALLEY"),	("FIREY-MOLTEN RED COINS"))

smlua_text_utils_course_acts_replace(COURSE_SSL, (" 8 CHOCOLATE MOUNTAIN PEAKS"),	("FLOATING STONE BLOCKS"),	("VOLCANO GLAZED IN CARAMEL"),	("FRIENDLY BULLET BILLS"),	("VIRTUAL HIKING ON ACNE MOUNTAIN"),	("THE HANDY HAND'S NEW TERRITORY"),	("MAGICAL CHOCOLATE TREES"))

smlua_text_utils_course_acts_replace(COURSE_DDD, (" 7 FLOATING GARDEN GALLERY"),	("CLIMB THE CILO"),	("A CASTLE IN THE SKY"),	("THE GOLDEN NUMBERS"),	("THE CHERRY'S DAREDEVIL COMET"),	("THE BOMBOMB'S TIME CAPSULE"),	("PURPLE CLOUD COMET"))

smlua_text_utils_course_acts_replace(COURSE_SL, ("13 FROSTBITE RIVERSIDE"),	("THE GAP IN THE WALL"),	("MAJOR FROSTBITE ROCKS"),	("ICEY WOOD"),	("LETHAL ICE ON THE MOUNTAIN"),	("RED COINS AROUND THE RIVER"),	("THE ICEPLACE"))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("11 GOLD-GRASS BAY"),	("TIGHTROPE CHALLENGE"),	("PARTICULARLY SQUARE RIFT"),	("BEACH SCAVENGER HUNT"),	("ROCKY RED COINS"),	("GOLDEN-PURPLE COINS"),	("WHERE'S THE VANISH CAPS?!"))

smlua_text_utils_course_acts_replace(COURSE_TTM, (" 6 MISTY HILLSIDE"),	("FORT UMBRELLA"),	("TIGHTROPE TRIAL"),	("FIVE PLUS FIVE IS TEN"),	("SHELL SURFIN' FOR RED COINS"),	("RAINING PURPLE COINS"),	("LINEAR HILL"))

smlua_text_utils_course_acts_replace(COURSE_THI, ("12 MUSHROOM NATIONAL PARK"),	("CLIMB THE LARGE TREE"),	("MUSHROOM MADNESS"),	("HOP ON TO THE FLOWERS"),	("WIGGLER'S NEW COVE"),	("FOOL'S HOLE"),	("FIND THE MISSING CAMPER"))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("14 THE CLOCKWORK DIMMENSION"),	("WINDING WATCH"),	("AVOID THE PENDELUMS"),	("JUMPING OFF WALLS"),	("VANISH THROUGH THE GLASS"),	("FLY TO THE BIG BLUE THWOMP"),	("ROTATING RED COINS"))

smlua_text_utils_course_acts_replace(COURSE_RR, ("15 FROZEN LAVA PEAKS"),	("INTO THE VOLCANO"),	("A FROZEN SPEEDY COMET"),	("SINK HOLES IN THE ICE"),	("SNOWMAN'S BROTHER'S HEAD"),	("PURPLE COINS ON THE PEAKS"),	("UNDER THE OLD FORT"))

smlua_text_utils_secret_star_replace(15 + 1, ("   BOWSER'S SILENT ARENA"))
smlua_text_utils_secret_star_replace(16 + 1, ("   AIRSHIP ARMADA"))
smlua_text_utils_secret_star_replace(17 + 1, ("   NITRO BLUE FORT"))
smlua_text_utils_secret_star_replace(18 + 1, ("   THE BOOS' PLAYPLACE"))
smlua_text_utils_secret_star_replace(19 + 1, ("   MOLTEN MILLS"))
smlua_text_utils_secret_star_replace(20 + 1, ("   SAND BOX BREAKOUT"))
smlua_text_utils_secret_star_replace(21 + 1, ("   RUSTED QUICKSAND DRAIN"))
smlua_text_utils_secret_star_replace(22 + 1, ("   BLOSSOMING FIELDS"))
smlua_text_utils_secret_star_replace(23 + 1, ("   DEEP DARK LAGOON"))
smlua_text_utils_secret_star_replace(24 + 1, (""))
smlua_text_utils_castle_secret_stars_replace(("   SECRET STARS"))
smlua_text_utils_extra_text_replace(0,("AN UNIDENTIFIED STAR!"))
smlua_text_utils_extra_text_replace(1,(""))
smlua_text_utils_extra_text_replace(2,(""))
smlua_text_utils_extra_text_replace(3,(""))
smlua_text_utils_extra_text_replace(4,(""))
smlua_text_utils_extra_text_replace(5,(""))
smlua_text_utils_extra_text_replace(6,(""))
