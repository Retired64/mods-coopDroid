-- name: \\#66ff82\\Luigi \\#ffffff\\& \\#ff66fa\\The Violet Stars
-- description: \\#66ff82\\Luigi \\#ffffff\\& \\#ff66fa\\The Violet Stars\\#ffffff\\ is a hack where you will play with Luigi throughout the game, it is very set in designs from old years it will be a fun experience to play and has some fun stars but in general its exploration.\n\n Ported by: Fe\\#ffbfa5\\arl
-- incompatible: romhack

gLevelValues.entryLevel = LEVEL_CASTLE_GROUNDS
gLevelValues.cellHeightLimit = 32767
gLevelValues.floorLowerLimit = -32767

camera_set_use_course_specific_settings(0)
camera_set_romhack_override(RCO_ALL)
rom_hack_cam_set_collisions(0)
camera_romhack_allow_centering(0)
camera_set_use_course_specific_settings(false)

gLevelValues.fixCollisionBugs = true
gLevelValues.fixCollisionBugsRoundedCorners = false
gLevelValues.fixCollisionBugsFalseLedgeGrab = false
gLevelValues.fixCollisionBugsGroundPoundBonks = false
gLevelValues.fixCollisionBugsPickBestWall = false

set_ttc_speed_setting(TTC_SPEED_FAST)