----- Functions -----

function set_marios_color(color, curPalette, p)
    local result = { r = 0, g = 0, b = 0 }

    result.r = lerp(color.r, curPalette.r, p)
    result.g = lerp(color.g, curPalette.g, p)
    result.b = lerp(color.b, curPalette.b, p)

    return result
end

function is_becoming_ash(m)
    if (m.action == ACT_LAVA_DEATH and m.vel.y <= 0 and not snowyTerrain)
    or (m.action == ACT_STANDING_DEATH and m.prevAction == ACT_BURNING_GROUND and m.actionTimer >= 25) then
        return true
    end
    return false
end

----- Toast (or freeze) Mario -----

function toast_or_freeze_the_mario(m)
    local d = gMarioDetails[m.playerIndex]
    local np = gNetworkPlayers[m.playerIndex]

    local ogCol = d.storedColors
    local colorToSwapto
    local lerpCap = 0

    if (m.action == ACT_BURNING_GROUND or m.action == ACT_BURNING_FALL or m.action == ACT_BURNING_JUMP or
        (m.action == ACT_LAVA_DEATH and not snowyTerrain)
        or (m.action == ACT_STANDING_DEATH and m.prevAction == ACT_BURNING_GROUND)) then
        if d.burnOrFreezeTimer < 0 then
            d.burnOrFreezeTimer = d.burnOrFreezeTimer + 10
        end

        d.burnOrFreezeTimer = approach_f32(d.burnOrFreezeTimer, 60, 1, 1)

        if d.lerpVariable < 0 then
            d.lerpVariable = d.lerpVariable + 0.085
        end

    elseif ((m.action & ACT_GROUP_MASK) == ACT_GROUP_SUBMERGED or m.action == ACT_LAVA_DEATH or m.action == ACT_FROZEN) and snowyTerrain then
        if d.burnOrFreezeTimer > 0 then
            d.burnOrFreezeTimer = d.burnOrFreezeTimer - 10
        end

        d.burnOrFreezeTimer = approach_f32(d.burnOrFreezeTimer, -60, 1, 1)

        if d.lerpVariable > 0 then
            d.lerpVariable = d.lerpVariable - 0.1
        end

    else
        if m.waterLevel - m.pos.y > 50 then
            if d.burnOrFreezeTimer > 0 then
                d.burnOrFreezeTimer = d.burnOrFreezeTimer - 10
            end
            if d.lerpVariable > 0 then
                d.lerpVariable = d.lerpVariable - 0.1
            end
        end
        d.burnOrFreezeTimer = approach_f32(d.burnOrFreezeTimer, 0, 1, 1)
    end

    if d.lerpVariable > 0 then
        if not is_becoming_ash(m) then
            d.smokeTimer = d.smokeTimer + 1
            if d.smokeTimer == 8 then
                spawn_non_sync_object(id_bhvBlackSmokeMario, E_MODEL_BURN_SMOKE, m.marioObj.header.gfx.pos.x, m.marioObj.header.gfx.pos.y,
                    m.marioObj.header.gfx.pos.z, nil)
                d.smokeTimer = 0
            end
        end
        colorToSwapto = { r = 0, g = 0, b = 0 }
        if m.action ~= ACT_LAVA_DEATH and m.action ~= ACT_STANDING_DEATH then
            lerpCap = 0.85
        else
            lerpCap = 1
        end
    else
        colorToSwapto = { r = 0xC8, g = 0xC8, b = 0xFF }
        if m.action ~= ACT_LAVA_DEATH and m.action ~= ACT_FROZEN then
            lerpCap = 0.75
        else
            lerpCap = 1
        end
    end

    if d.burnOrFreezeTimer > 0 then
        d.lerpVariable = approach_f32(d.lerpVariable, lerpCap, 0.075, 0.075)
    elseif d.burnOrFreezeTimer < 0 then
        -- read this as:
        -- (m.action == ACT_LAVA_BOOST or m.action ~= ACT_LAVA_DEATH) ? 0.075 : 0.015
        local lerpIncDec = (m.action == ACT_LAVA_BOOST or m.action == ACT_LAVA_DEATH or m.action == ACT_FROZEN) and 0.075 or 0.015
        d.lerpVariable = approach_f32(d.lerpVariable, -lerpCap, lerpIncDec, lerpIncDec)
    else
        d.lerpVariable = approach_f32(d.lerpVariable, 0, 0.015, 0.015)
    end

    network_player_color_to_palette(np, PANTS, set_marios_color(ogCol.pants, colorToSwapto, math.abs(d.lerpVariable)))

    network_player_color_to_palette(np, SHIRT, set_marios_color(ogCol.shirt, colorToSwapto, math.abs(d.lerpVariable)))

    network_player_color_to_palette(np, GLOVES, set_marios_color(ogCol.gloves, colorToSwapto, math.abs(d.lerpVariable)))

    network_player_color_to_palette(np, SHOES, set_marios_color(ogCol.shoes, colorToSwapto, math.abs(d.lerpVariable)))

    network_player_color_to_palette(np, HAIR, set_marios_color(ogCol.hair, colorToSwapto, math.abs(d.lerpVariable)))

    network_player_color_to_palette(np, SKIN, set_marios_color(ogCol.skin, colorToSwapto, math.abs(d.lerpVariable)))
end
