-- name: Freeze Camera
-- description: Freeze/Unfreeze your camera using /freeze-cam.
froze = false

function freeze_camera(m)
    if froze then camera_freeze() else camera_unfreeze() end
end

function freeze_command(msg)
    froze = not froze
    return true
end

hook_event(HOOK_MARIO_UPDATE, freeze_camera)
hook_chat_command("freeze-cam", "[Freezes/Unfreezes your camera]", freeze_command)