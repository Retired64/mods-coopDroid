

function courses()
smlua_text_utils_course_acts_replace(COURSE_BOB, ("   2000 IQ SUPER QUIZ!"), 	("BIG BOB-OMB ON THE SUMMIT"), 	("FOOTRACE WITH KOOPA THE QUICK"), 	("SHOOT TO THE ISLAND IN THE SKY"), 	("FIND THE 8 RED COINS"), 	("MARIO WINGS TO THE SKY"), 	("BEHIND CHAIN CHOMP'S GATE"))

smlua_text_utils_course_acts_replace(COURSE_WF, ("   2000 IQ SUPER QUIZ!"), 	("END?"), 	("TO THE TOP OF THE FORTRESS"), 	("SHOOT INTO THE WILD BLUE"), 	("RED COINS ON THE FLOATING ISLE"), 	("FALL ONTO THE CAGED ISLAND"), 	("BLAST AWAY THE WALL"))

smlua_text_utils_course_acts_replace(COURSE_JRB, ("   MINECRAFT"), 	(""), 	("CAN THE EEL COME OUT TO PLAY?"), 	("TREASURE OF THE OCEAN CAVE"), 	("RED COINS ON THE SHIP AFLOAT"), 	("BLAST TO THE STONE PILLAR"), 	("THROUGH THE JET STREAM"))

smlua_text_utils_course_acts_replace(COURSE_CCM, ("   FINAL 10"), 	(""), 	("LI'L PENGUIN LOST"), 	("BIG PENGUIN RACE"), 	("FROSTY SLIDE FOR 8 RED COINS"), 	("SNOWMAN'S LOST HIS HEAD"), 	("WALL KICKS WILL WORK"))

smlua_text_utils_course_acts_replace(COURSE_BBH, ("   2000 IQ SUPER QUIZ!"), 	("GO ON A GHOST HUNT"), 	("RIDE BIG BOO'S MERRY-GO-ROUND"), 	("SECRET OF THE HAUNTED BOOKS"), 	("SEEK THE 8 RED COINS"), 	("BIG BOO'S BALCONY"), 	("EYE TO EYE IN THE SECRET ROOM"))

smlua_text_utils_course_acts_replace(COURSE_HMC, ("   QUESTIONS 21-29"), 	(""), 	("ELEVATE FOR 8 RED COINS"), 	("METAL-HEAD MARIO CAN MOVE!"), 	("NAVIGATING THE TOXIC MAZE"), 	("A-MAZE-ING EMERGENCY EXIT"), 	("WATCH FOR ROLLING ROCKS"))

smlua_text_utils_course_acts_replace(COURSE_LLL, ("   2000 IQ SUPER QUIZ!"), 	("BOIL THE BIG BULLY"), 	("BULLY THE BULLIES"), 	("8-COIN PUZZLE WITH 15 PIECES"), 	("RED-HOT LOG ROLLING"), 	("HOT-FOOT-IT INTO THE VOLCANO"), 	("ELEVATOR TOUR IN THE VOLCANO"))

smlua_text_utils_course_acts_replace(COURSE_SSL, ("   CONGRATULATIONS!"), 	(""), 	("SHINING ATOP THE PYRAMID"), 	("INSIDE THE ANCIENT PYRAMID"), 	("STAND TALL ON THE FOUR PILLARS"), 	("FREE FLYING FOR 8 RED COINS"), 	("PYRAMID PUZZLE"))

smlua_text_utils_course_acts_replace(COURSE_DDD, ("   2000 IQ SUPER QUIZ!"), 	("BOARD BOWSER'S SUB"), 	("CHESTS IN THE CURRENT"), 	("POLE-JUMPING FOR RED COINS"), 	("THROUGH THE JET STREAM"), 	("THE MANTA RAY'S REWARD"), 	("COLLECT THE CAPS..."))

smlua_text_utils_course_acts_replace(COURSE_SL, ("   2000 IQ SUPER QUIZ!"), 	("REMEMBER THIS!"), 	("CHILL WITH THE BULLY"), 	("IN THE DEEP FREEZE"), 	("WHIRL FROM THE FREEZING POND"), 	("SHELL SHREDDIN' FOR RED COINS"), 	("INTO THE IGLOO"))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("   2000 IQ SUPER QUIZ!"), 	("SHOCKING ARROW LIFTS!"), 	("TOP O' THE TOWN"), 	("SECRETS IN THE SHALLOWS & SKY"), 	("EXPRESS ELEVATOR--HURRY UP!"), 	("GO TO TOWN FOR RED COINS"), 	("QUICK RACE THROUGH DOWNTOWN!"))

smlua_text_utils_course_acts_replace(COURSE_TTM, ("   2000 IQ SUPER QUIZ!"), 	("SCALE THE MOUNTAIN"), 	("MYSTERY OF THE MONKEY CAGE"), 	("SCARY 'SHROOMS, RED COINS"), 	("MYSTERIOUS MOUNTAINSIDE"), 	("BREATHTAKING VIEW FROM BRIDGE"), 	("BLAST TO THE LONELY MUSHROOM"))

smlua_text_utils_course_acts_replace(COURSE_THI, ("   2000 IQ SUPER QUIZ!"), 	("PLUCK THE PIRANHA FLOWER"), 	("THE TIP TOP OF THE HUGE ISLAND"), 	("REMATCH WITH KOOPA THE QUICK"), 	("FIVE ITTY BITTY SECRETS"), 	("WIGGLER'S RED COINS"), 	("MAKE WIGGLER SQUIRM"))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("   2000 IQ SUPER QUIZ!"), 	("ROLL INTO THE CAGE"), 	("THE PIT AND THE PENDULUMS"), 	("GET A HAND"), 	("STOMP ON THE THWOMP"), 	("TIMED JUMPS ON MOVING BARS"), 	("STOP TIME FOR RED COINS"))

smlua_text_utils_course_acts_replace(COURSE_RR, ("   2000 IQ SUPER QUIZ!"), 	("CRUISER CROSSING THE RAINBOW"), 	("THE BIG HOUSE IN THE SKY"), 	("COINS AMASSED IN A MAZE"), 	("SWINGIN' IN THE BREEZE"), 	("TRICKY TRIANGLES!"), 	("SOMEWHERE OVER THE RAINBOW"))

smlua_text_utils_secret_star_replace(16, ("   2000 IQ SUPER QUIZ!"))
smlua_text_utils_secret_star_replace(17, ("   QUESTIONS 13-19"))
smlua_text_utils_secret_star_replace(18, ("   QUESTION 20"))
smlua_text_utils_secret_star_replace(19, ("   QUESTIONS 1-11"))
smlua_text_utils_secret_star_replace(20, ("   CONGRATULATIONS?"))
smlua_text_utils_secret_star_replace(21, ("   2000 IQ SUPER QUIZ!"))
smlua_text_utils_secret_star_replace(22, ("   2000 IQ SUPER QUIZ!"))
smlua_text_utils_secret_star_replace(23, ("   HOW ARE YOU EVEN HERE?"))
smlua_text_utils_secret_star_replace(24, ("   2000 IQ SUPER QUIZ!"))
smlua_text_utils_secret_star_replace(25, ("   REMEMBER THIS!"))
smlua_text_utils_secret_star_replace(("   2000 IQ SUPER QUIZ!"))

end
courses()
