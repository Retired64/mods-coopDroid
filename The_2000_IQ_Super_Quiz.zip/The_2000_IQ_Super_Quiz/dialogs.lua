function dialogs()
    smlua_text_utils_dialog_replace(DIALOG_000, 1, 4, 30, 200, ("\
"))

smlua_text_utils_dialog_replace(DIALOG_001, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_002, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_003, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_004, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_005, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_006, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_007, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_008, 1, 4, 30, 200, ("Ladies and gentlemen,\
Hello! I'm a Goomba With\
a Top Hat, your host for\
the evening!\
Welcome to the...\
2000 IQ Super Quiz!\
Let's all have a round of\
applause for tonight's\
contestant, the one\
and only Mario, heroic\
plumber and savior of\
the Mushroom Kingdom!\
He's all set and ready to\
participate to our 2000\
IQ Super Quiz, but how\
far will he make it to?\
That's what we'll find\
out in a few seconds!\
The game will start as\
soon as Mario jumps into\
that pipe! Let's all wish\
him good luck for the...\
\
2000 IQ SUPER QUIZ!"))

smlua_text_utils_dialog_replace(DIALOG_009, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_010, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_011, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_012, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_013, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_014, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_015, 1, 5, 30, 200, ("The! Game! Has! Begun!\
Watch closely as our\
contestant approaches\
the first challenge: the\
infamous puzzle painting!\
For now, all Mario has to\
do is to examine this\
painting carefully and\
remember where the\
little star is!\
This will be very important\
for the rest of the game.\
When you are done, Mario,\
please stand on the\
red platform ahead!"))

smlua_text_utils_dialog_replace(DIALOG_016, 1, 4, 30, 200, ("Oooh! My dear audience,\
our contestant will now\
face the first question\
of tonight's episode!\
Listen closely:\
How many coins at most\
can you get in Whomp's\
Fortress?\
BLUE - 107\
RED - 141\
GREEN - 213\
YELLOW - 999"))

smlua_text_utils_dialog_replace(DIALOG_017, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_018, 1, 4, 30, 200, ("Oh, yeah yeah yeah!\
Our contestant obviously\
knows that by duplicating\
the breakable box, you\
can max out the coin\
counter! Now, will he be\
smart enough to answer\
the following question?\
What character in the\
game has a typo in one\
of their textboxes?\
\
BLUE- Bowser\
RED - Toad\
GREEN - Yoshi\
YELLOW - Hoot"))

smlua_text_utils_dialog_replace(DIALOG_019, 1, 2, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_020, 1, 6, 95, 150, (""))

smlua_text_utils_dialog_replace(DIALOG_021, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_022, 1, 2, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_023, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_024, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_025, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_026, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_027, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_028, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_029, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_030, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_031, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_032, 1, 6, 30, 200, ("Ding ding ding! That's\
right! Yoshi says \
『Mario!!! It that\
really you???『\
when you meet him\
on the rooftop.\
Tonight's contestant\
seems to be on a\
winning streak!\
The next question is a\
very easy one... it's not\
even a question!\
Mario must simply enter\
the RED pipe.\
We've seen his logical\
skills, but will Mario be\
able to pass this test?"))

smlua_text_utils_dialog_replace(DIALOG_033, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_034, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_035, 1, 5, 30, 200, ("Oh, ha ha ha...\
Ladies and gentlemen,\
Our contestant must\
simply have misunder-\
stood the question!\
He needs to enter the\
RED pipe in order to go\
to the next question!\
Or else he will LOSE the\
game and START OVER!"))

smlua_text_utils_dialog_replace(DIALOG_036, 1, 5, 30, 200, ("Congratulations! Tonight's\
contestant proves that\
he is capable of following\
a simple indication\
without messing up!\
Now, onto the neeext\
question! Which one of\
these characters from\
the Super Mario universe \
is the sexiest?\
BLUE- Peach\
RED- Daisy\
GREEN- Rosalina\
YELLOW- Waluigi\
"))

smlua_text_utils_dialog_replace(DIALOG_037, 1, 2, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_038, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_039, 1, 5, 30, 200, ("Our contestant answered\
right once again!\
He followed his heart and\
knew that his GIRLFRIEND\
was objectively sexier\
and that any other\
answer would have got\
him absolutely torn to\
shreds when he would have\
come back to the castle.\
NEXT QUESTION!\
How many red coin\
stars are there in\
Super Mario 64?\
\
17DE81 - 23 \
99C944 - 21\
AC57BD - 19\
FF8525 - 15"))

smlua_text_utils_dialog_replace(DIALOG_040, 1, 5, 30, 200, ("And he knows his hex\
colors, ladies and\
gentlemen! How amazing!\
He's gonna go far!\
Here's the next question!\
What hidden way of\
transportation allows\
Mario to travel from one\
point to another in some\
levels of SM64?\
RED - Cannon\
BLUE - Sling star\
GREEN - Cappy\
YELLOW - the bus\
"))

smlua_text_utils_dialog_replace(DIALOG_041, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_042, 1, 4, 30, 200, ("\
Increeeedible! He\
figured it out!\
\
Ladies and gentlemen,\
don't you think it's time\
to slow down on the\
questions, and instead\
watch our contestant use\
his platforming skills to\
get to the other side of \
the quicksand pit?\
Let's see if he jumps as\
well as they say! \
"))

smlua_text_utils_dialog_replace(DIALOG_043, 1, 5, 30, 200, ("He he he... How did he\
know not to walk on \
the slabs?\
Maybe he practiced\
before, or maybe he\
can try his chance as\
much as he wants\
thanks to some\
complicated time-\
travelling power, or\
maybe we're all living\
in a simulation and he's\
just resetting every\
time he loses!\
\
But, my good audience,\
who am I to make such\
bold assumptions!\
Merely a goomba with\
a top hat!\
Anyway... Next question.\
Let's put our contestant's\
memory to the test!\
Can he remember\
the order of the colors\
and jump into the\
BLUE pipe?"))

smlua_text_utils_dialog_replace(DIALOG_044, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_045, 1, 6, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_046, 1, 6, 30, 200, ("He remembers the\
colors!!! I hope he also\
remembers his sins.\
Thou shall never forget\
the evil that thou hast\
done, Mario.\
After all these trick\
questions, let's have an\
easy one, for once!\
Nothing complicated,\
no trap, just a good\
old regular question!\
What character is never\
mentioned in a Super\
Mario 64 textbox?\
\
\
\
\
BLUE - Big Boo\
RED - Santa Claus\
GREEN - Luigi\
YELLOW - Koopa Troopa"))

smlua_text_utils_dialog_replace(DIALOG_047, 1, 2, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_048, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_049, 1, 5, 30, 200, ("Well done! Santa Claus\
is on a sign in Cool Cool\
Mountain, Koopa is\
mentioned at the start\
of Bob-Omb Battlefield,\
and Big Boo is written on\
a sign in his own manor.\
Poor Luigi didn't even\
get his name on a simple\
piece of wood. Oh well...\
Anyway, our contestant\
might be wondering where\
on earth could the pipes\
have gone? It's not our\
fault, I promise. \
The warps simply\
disappeared! We didn't\
think you would make\
it this far so we didn't\
cancel, but since you're\
here, you can always try\
to find one of them.\
They must have simply\
turned invisible and\
hidden somewhere\
in the room. They just\
do that sometimes.\
If ever you wanted to\
find one of them,\
be warned: they're\
pretty good climbers!\
They could be anywhere!\
If you can't, we'll send\
you home with some\
compensation.\
We have some leftover\
pineapple pizza in the\
back, that'll do."))

smlua_text_utils_dialog_replace(DIALOG_050, 1, 5, 30, 200, ("Mamma mia, as our\
contestant would\
probably say.\
He managed to find\
the invisible pipe, but\
now it's the ground\
that disappeared!\
Talk about budget cuts...\
But that's nothing to fear,\
and the game goes on!\
Mario will simply have\
to use his powerful leg\
muscles to jump all the\
way to his answer of\
choice.\
Here is the question:\
What is written on the\
metal plate on the star\
statue in the backyard of\
Princess Peach's castle?\
BLUE- Eternal Star\
RED - Nothing\
YELLOW - L is real 2401\
GREEN - L is real 2041"))

smlua_text_utils_dialog_replace(DIALOG_051, 1, 5, 30, 200, ("He braves the unexpected,\
he defies the law of\
Murphy, tonight's\
contestant has a\
very high IQ!\
\
Maybe not 2000 yet,\
but like, around 1500.\
Which is acceptable.\
\
Speaking of numbers,\
what's the number that\
should be written\
on the ground?\
\
It's here to indicate\
what question you're at.\
Do you remember how\
many questions you've\
answered?\
Or maybe what's the\
last number you saw\
below your feet?\
Jump into the right\
pipe and prove it!\
BLUE - 11\
RED - 12\
GREEN - 13\
YELLOW - 14"))

smlua_text_utils_dialog_replace(DIALOG_052, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_053, 1, 4, 30, 200, ("Fantastic! Tonight's show\
ends on a win for Mario,\
our constestant who has\
proven he has 2000 IQ!\
Mario, whenever you feel\
ready, go and grab that\
trophy! I hope you\
enjoyed the experience."))

smlua_text_utils_dialog_replace(DIALOG_054, 1, 4, 30, 200, ("Ha ha ha ha! You got\
pranked on live TV!\
You really thought it\
was the end of the quiz?\
Ladies and gentlemen,\
our contestant is in for\
a treat tonight, he isn't\
even close to winning!\
Let's go on to the next\
question! Ready?\
What would you call a\
goomba with wings?\
BLUE - Paragoomba\
RED - Aerogoomba\
GREEN - Flygoomba\
YELLOW - Philip"))

smlua_text_utils_dialog_replace(DIALOG_055, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_056, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_057, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_058, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_059, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_060, 1, 3, 30, 200, ("Right answer again!\
It is really rude to call\
someone by their species.\
How would you like it if\
I called you 『the human『?\
Not very much, yeah.\
Besides, Philip's a really\
nice guy. Funny and all.\
But ANYWAY!\
Question number 14!\
How old do you think\
I am? Like, honestly?\
Enter your anwser by\
ground-pounding the \
buttons on the ground,\
then enter the pipe to\
confirm and check if\
you were right!"))

smlua_text_utils_dialog_replace(DIALOG_061, 1, 4, 30, 200, ("Oh oh oh!\
Our contestant might\
think he found the \
correct answer, but\
the number pad was\
actually broken all\
along! He will never\
get to know my age!\
You might think it's \
because of the makeup,\
but I actually have\
naturally smooth skin.\
I'm not old, I swear.\
You can touch my face\
backstage after the\
show if you want.\
Oh? Yes, right, I'm\
being told to stop\
talking and go on with\
the questions! So...\
Who here has the\
smoothest skin?\
Go on, guess! I know\
you know the answer!\
BLUE - The host\
RED - The host\
GREEN - The host\
YELLOW - Not the host"))

smlua_text_utils_dialog_replace(DIALOG_062, 1, 4, 30, 200, ("Hey! Not nice!\
Who's writing these\
questions? I'm going\
to get you fired, man!\
Urgh... Anyway, looking\
at the stats of tonight's\
episode revealed that\
half the viewers had\
already left because,\
I quote, 『The hack is\
not cancer enough.『\
So we added these!\
One of these deadly\
traps is not deadly\
at all, but you don't\
know which one.\
Can you get out of\
this question alive?\
\
\
And most importantly,\
can we get the viewers\
back, please?"))

smlua_text_utils_dialog_replace(DIALOG_063, 1, 5, 30, 200, ("Hey! Who turned off the\
lights? What's going on?\
Can you still hear me?\
\
Urgh...\
Seems like it's Mario's\
lucky day today, hm.\
This uninteresting lack\
of deaths won't bring\
the wiewers back.\
Let's go back to some\
challenging questions,\
then. Have you noticed\
we're at question 17?\
\
Would you happen to\
know what year was\
the 17th birthday of\
Super Mario 64 on?\
\
BLUE - 2009\
RED - 2011\
GREEN - 2013\
YELLOW - 2015"))

smlua_text_utils_dialog_replace(DIALOG_064, 1, 5, 30, 200, ("The math was simple\
enough, good job!\
Super Mario 64 was\
released in 1996 in\
the US and Japan.\
And it seems the lights\
are back on, for now.\
Let's hope they stay on.\
Now, I present to you\
the next question!\
These are tricky pipes!\
They look normal, but\
don't be mistaken:\
their colors are merely\
an illusion.\
They've each taken the\
color of another pipe,\
can you find which one\
was originally green?\
\
Note that the red pipe\
was originally blue, and\
that the green one was\
not originally yellow.\
Good luck, he he he!"))

smlua_text_utils_dialog_replace(DIALOG_065, 1, 5, 30, 200, ("\
Yes! Tonight's contestant\
found the right answer! \
Congratulations!\
\
Now, have you paid\
close attention to the\
quiz? Could you tell me\
what was the answer\
to question number 2?\
BLUE- Yoshi\
RED - The red pipe\
GREEN - 999\
YELLOW - Peach"))

smlua_text_utils_dialog_replace(DIALOG_066, 1, 3, 30, 200, ("Our contestant is right\
once more! He is\
UN-STOP-PA-BLE!\
Or is he? Let's see how\
he'll get past this new\
platforming challenge!\
And there are no more\
traps this time around,\
I swear!"))

smlua_text_utils_dialog_replace(DIALOG_067, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_068, 1, 3, 30, 200, ("Ha! I lied! There was a\
trap! But that did not\
deter our fierce Mario,\
who jumped over it\
with the ease of a\
pelican!\
Wait, is a pelican really\
gracious? Who has even\
seen a real one anyway?\
These are questions for\
another day... But the\
question for today is:\
What is the fastest way\
to get out of a level?\
\
ORANGE - Grab a star\
PURPLE - Lose a life"))

smlua_text_utils_dialog_replace(DIALOG_069, 1, 3, 30, 200, ("Thinking out of the box\
is definitely one of our\
contestant's strenghts!\
But is knowledge of\
trivia also one of\
them? Let's see!\
What's special about\
the title of the game,\
Super Mario 64?\
BLUE - It was planned\
to be the title of\
another game\
RED - It was a place-\
holder title, but stuck\
for the final release\
GREEN - It has been\
changed 17 times\
during development\
YELLOW - It appeared\
to Shigeru Miyamoto in\
a dream"))

smlua_text_utils_dialog_replace(DIALOG_070, 1, 5, 30, 200, ("Someone's been reading\
a lot about the game!\
This is some serious\
knowledge, do you have\
a PHD in Super Mario?\
Now, you can see there\
is a signpost in front of\
us, on which is written\
a list of 5 numbers.\
\
Try to memorise them!\
I'll ask you a question\
about them. When you\
are done, jump into\
the blue pipe ahead!"))

smlua_text_utils_dialog_replace(DIALOG_071, 1, 4, 30, 200, ("Alright, did you learn\
them by heart, Mario?\
Here's the question...\
\
What was the first\
word I said to you in\
the previous room?\
\
BLUE - Wow\
RED - Congratulations\
GREEN - Someone\
YELLOW - Have"))

smlua_text_utils_dialog_replace(DIALOG_072, 1, 4, 30, 200, ("Ha ha, sometimes you\
have to learn more\
than what you're \
told to! \
I hope you're not mad\
at me for this little\
harmless joke...\
You better not be!\
Anyway, next question:\
What is the name of\
the star that sits the\
highest above ground?\
BLUE - Chests in\
        the current\
RED - Red coins on\
      the ship afloat\
GREEN - Big Boo's\
          balcony\
YELLOW - Roll into\
           the cage"))

smlua_text_utils_dialog_replace(DIALOG_073, 1, 4, 95, 200, ("Great job! Mario very\
obviously knew that\
the ship was not \
considered as solid\
ground, but as an\
object! Or, he watched\
Pannenkoek's video...\
Who knows!\
We're nearing the end\
of our quiz, but there\
is still more to discover!\
Such as this question!\
\
What was the fourth\
number in the list?\
\
BLUE - 743\
RED -  247\
GREEN - 427\
YELLOW - 437"))

smlua_text_utils_dialog_replace(DIALOG_074, 1, 5, 30, 200, ("He he he... I told you I\
was going to ask you\
about the numbers...\
I just didn't say when!\
\
We haven't really done\
much math tonight,\
have we? Let's fix that!\
Here's a simple math\
problem to solve!\
What's 17 ↔ 4 ↔ 5?\
BLUE - twetny-seven\
RED - twenty-seven\
GREEN - twnety-seven\
YELLOW - twen-vtny"))

smlua_text_utils_dialog_replace(DIALOG_075, 1, 5, 30, 200, ("My dear audience,\
what a contestant we\
have tonight! He is\
smart, witty AND\
good at platforming!\
But is he as good at\
guessing? Mario, what's\
going to happen when\
you enter the correct\
pipe?\
Possible answers:\
BLUE - You will win\
           the game\
RED - You will lose\
         the game\
GREEN- You will be\
warped into Minecraft\
YELLOW - I'll come to\
your house and break\
both your kneecaps"))

smlua_text_utils_dialog_replace(DIALOG_076, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_077, 1, 4, 150, 200, ("Oh, my dear audience,\
what a plot twist,\
changing the whole\
game like that!\
Can the contestant\
survive in the wild\
environment of this\
unfamiliar world?\
Can he collect eight\
mushrooms and enter\
the blue pipe to go to\
the next level?\
Stay tuned on QuizTV\
to know the answer!"))

smlua_text_utils_dialog_replace(DIALOG_078, 1, 4, 30, 200, ("Incredible!!\
No matter what you\
throw at him, Mario\
stays up and proud!\
Dare I say it...\
He might even make\
it to the end of the\
2000 IQ Super Quiz!\
If he answers this\
question, that is.\
What character do\
you play in SM64?\
BLUE - Yoshi\
RED - Mario\
GREEN - Luigi\
YELLOW - Wario"))

smlua_text_utils_dialog_replace(DIALOG_079, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_080, 1, 1, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_081, 1, 4, 30, 200, ("You made it, Mario.\
Listen up, and watch\
closely, my dear \
audience, as tonight's\
contestant approaches\
the FINAL challenge!\
Now, there's only one\
question remaining...\
\
\
ARE YOU READY?\
\
GREEN - Nah.\
RED - Kinda...\
YELLOW - Not fully\
BLUE - YES!!!"))

smlua_text_utils_dialog_replace(DIALOG_082, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_083, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_084, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_085, 1, 5, 30, 200, ("Here's the challenge:\
You will be asked 10\
questions, and will have\
to answer in the right\
order.\
The answers are either\
colors or numbers from\
1 to 4, corresponding\
to the pipes you have to\
enter. \
You can read the sign\
next to me to know\
the questions, and talk\
to me to know the rules\
as much as needed.\
Good luck.\
If you win this,\
you win the game!\
It's the last trial!\
Have fun!"))

smlua_text_utils_dialog_replace(DIALOG_086, 1, 4, 30, 200, ("Oh... Did I say\
FINAL challenge? \
Sorry, there's one\
more to beat...\
Remember that little\
star on the Bob-Omb\
painting? I sure hope\
you do, Mario!\
For the final trial, for\
real this time, tell us\
on what tile the little\
star was!\
Be careful though, I\
might have accidentally\
scrambled the pieces...\
Oops..."))

smlua_text_utils_dialog_replace(DIALOG_087, 1, 4, 30, 200, ("And that's how\
tonight's episode ends,\
my dear audience...\
Let's all cheer and clap\
for Mario, who has\
successfully asnwered\
all questions of the...\
2000IQ Super Quiz!!\
Congratulations!!\
Don't hesitate to come\
back and try to beat\
the Quiz again!\
In the meantime, I,\
a Goomba With a Top\
Hat, will be waiting!\
\
-----CREDITS-----\
Thanks to all the\
people who helped!\
-----------------\
Huge thanks to\
Drahnokks for making\
most of the custom\
behaviors in this hack!\
Thanks to Kaze and\
devwizard64 for\
making various ASM\
codes!\
Thanks to DavidSM64,\
Trenavix, and Skelux\
for making the tools\
I used for the hack!\
Thanks to the French\
SM64 Hacking group\
for motivating me\
and giving advice!\
Thanks to Maddy,\
GTM, and the french\
SM64 Hacking group\
for betatesting!\
And finally, thanks\
to YOU, for playing!\
I'm a goomba with a top\
hat, see you next time !"))

smlua_text_utils_dialog_replace(DIALOG_088, 1, 1, 95, 150, ("210\
721\
884\
743\
609"))

smlua_text_utils_dialog_replace(DIALOG_089, 1, 3, 95, 200, ("He he he! I broke in\
and turned off all the\
lights on the stage!\
I've always wanted to\
come and see what\
these pipes smelled like.\
Looks like it's my\
chance, he he he!\
\
By the way, I've also\
found the list of this\
episode's questions.\
Looks like there are\
30 questions before\
the final challenge!\
Now, come to papa,\
pipey-pipey... He he he!\
Sniff sniff..."))

smlua_text_utils_dialog_replace(DIALOG_090, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_091, 2, 6, 30, 200, ("You see, my dear\
audience, math is\
easy when you take\
the time to think\
about it!\
\
Now, some more plat-\
forming! Do you think\
our favorite plumber\
learned anything from\
his experiences?\
We'll see!"))

smlua_text_utils_dialog_replace(DIALOG_092, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_093, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_094, 1, 2, 30, 200, ("What color is the sky?\
\
What comes after 2?\
\
What do you get by\
mixing blue and yellow?\
What's inside an egg?\
\
How many horns\
on a unicorn?\
What number are we?\
\
How many ears\
on a unicorn?\
What color is Yoshi?\
\
What color is lava?\
\
If you remove one, how\
many spikes on a star?"))

smlua_text_utils_dialog_replace(DIALOG_095, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_096, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_097, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_098, 1, 2, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_099, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_100, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_101, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_102, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_103, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_104, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_105, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_106, 1, 2, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_107, 1, 3, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_108, 1, 2, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_109, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_110, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_111, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_112, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_113, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_114, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_115, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_116, 1, 5, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_117, 1, 1, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_118, 1, 6, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_119, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_120, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_121, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_122, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_123, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_124, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_125, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_126, 2, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_127, 3, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_128, 1, 4, 95, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_129, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_130, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_131, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_132, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_133, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_134, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_135, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_136, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_137, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_138, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_139, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_140, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_141, 1, 5, 150, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_142, 1, 5, 150, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_143, 1, 6, 150, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_144, 1, 6, 150, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_145, 1, 6, 150, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_146, 1, 6, 150, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_147, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_148, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_149, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_150, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_151, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_152, 1, 3, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_153, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_154, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_155, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_156, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_157, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_158, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_159, 1, 6, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_160, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_161, 1, 4, 30, 200, ("Mario!!!\
It that really you???\
It has been so long since\
our last adventure!\
They told me that I might\
see you if I waited here,\
but I'd just about given\
up hope!\
Is it true? Have you\
really beaten Bowser? And\
restored the Stars to the\
castle?\
And saved the Princess?\
I knew you could do it!\
Now I have a very special\
message for you.\
『Thanks for playing Super\
Mario 64! This is the\
end of the game, but not\
the end of the fun.\
We want you to keep on\
playing, so we have a\
little something for you.\
We hope that you like it!\
Enjoy!!!『\
\
The Super Mario 64 Team"))

smlua_text_utils_dialog_replace(DIALOG_162, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_163, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_164, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_165, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_166, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_167, 1, 4, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_168, 1, 5, 30, 200, (""))

smlua_text_utils_dialog_replace(DIALOG_169, 1, 4, 30, 200, (""))

end 
dialogs()