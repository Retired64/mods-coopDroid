-- name: The 2000 IQ Super Quiz!
-- description: The 2000 IQ Super Quiz is quiz hack that features 30 Questions and everyone's favorite Mario character: Goomba with a Tophat! Work together with friends to figure out each question, or bruteforce it with the power of co-op cheese.\n\nPort by Mr.Needlemouse\n\nPlaytesters:\nZetaSixty4\nJokerFactor\nJaydenSM64\nIsaac\nSpooneyApple\nSuper-playz-games\n\nOriginal Romhack by Biobak
-- incompatible: romhack

 

local warped = false

gLevelValues.entryLevel = LEVEL_BITDW
gServerSettings.bubbleDeath = false
gServerSettings.skipIntro = true


function pause_exit()
if gNetworkPlayers[0].currLevelNum ~=LEVEL_BITS then
    return false
else warp_to_level(LEVEL_HMC, 1, 1)
end
end
hook_event(HOOK_ON_PAUSE_EXIT, pause_exit)

function wrong_warp(m)
    if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GROUNDS then
        warp_to_level(LEVEL_BITDW, 1, 0)
    end
    if m.hurtCounter > 0 then
        m.health = 0
    end
end

hook_event(HOOK_MARIO_UPDATE, wrong_warp)

hook_event(HOOK_USE_ACT_SELECT, function ()return false end)

function on_pause_exit(usedExitToCastle)
    if not usedExitToCastle then
        return false;
    end
end

hook_event(HOOK_ON_PAUSE_EXIT, on_pause_exit)


function red_coins(m, o, intee)
    if intee == INTERACT_COIN and
          m.numCoins > 15 then        
            djui_popup_create("You've collected all 8 Mushrooms! You may proceed to the pipe.",1)
        end
        end
    hook_event(HOOK_ON_INTERACT, red_coins)

    function question_fail()
        local np = gNetworkPlayers[0]
    if np.currLevelNum == LEVEL_ENDING then

        djui_popup_create("Looks like our contestant is dumb as fuck...",3)
      end 
    end
    hook_event(HOOK_ON_LEVEL_INIT, question_fail)

    function wrong_warp_2(m)
        if gNetworkPlayers[0].currLevelNum == LEVEL_ENDING then
            warp_to_level(LEVEL_BITDW, 1, 0)
        end
    end
    hook_event(HOOK_MARIO_UPDATE, wrong_warp_2)

    function star_delete()
        local obj = obj_get_first_with_behavior_id(id_bhvHiddenRedCoinStar)
        if obj ~= nill then
            obj_mark_for_deletion(obj)
        end
    end

    hook_event(HOOK_MARIO_UPDATE, star_delete)

    function warp_condition(m)



        if m.numCoins > 15 then
            if m.pos.x >= 5072 and m.pos.x <= 5145 and
            m.pos.y >= -124 and m.pos.y <= -74 and 
            m.pos.z >= 959 and m.pos.z <= 1033 then
                warp_to_level(LEVEL_HMC, 1, 1) 
                warped = true
                
            end
        end
            
        end

        hook_event(HOOK_MARIO_UPDATE, warp_condition)

        function hmc_coords(m)

        if warped == true then
            local obj = obj_get_first_with_behavior_id(id_bhvBobombBuddy)
            obj = obj_get_next_with_same_behavior_id(obj)
            
                m.pos.x = obj.oPosX
                m.pos.y = obj.oPosY
                m.pos.z = obj.oPosZ
                warped = false
            end
        end
        hook_event(HOOK_MARIO_UPDATE, hmc_coords)


    

function no_fall_damage(m)
 m.peakHeight = m.pos.y
end
hook_event(HOOK_MARIO_UPDATE, no_fall_damage)


gLevelValues.wingCapDurationTotwc = 1
gLevelValues.metalCapDurationCotmc = 1
gLevelValues.vanishCapDurationVcutm = 1 


function wrong_warp_3(m)
    if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE then
        warp_to_level(LEVEL_BITDW, 1, 0)
    end
end
hook_event(HOOK_MARIO_UPDATE, wrong_warp_3)