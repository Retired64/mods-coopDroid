-- name: 3D world roll
-- description: Groundpound + Y = Air Roll \n\Crouch + Y = Ground roll \n\Ground roll + A = Super longjump

ACT_AIR_ROLL = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ATTACKING | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_3D_ROLL = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_MOVING | ACT_FLAG_ATTACKING)

gEventTable = {}

gStateExtras = {}
for i = 0, (MAX_PLAYERS - 1) do
    gStateExtras[i] = {}
    local m = gMarioStates[i]
    local e = gStateExtras[i]
    e.airRolled = false
    e.animFrame = 0
end

function act_air_roll(m)
    
    local e = gStateExtras[m.playerIndex]

    -- Attributes
    common_air_action_step(m, ACT_3D_ROLL, MARIO_ANIM_FORWARD_SPINNING, AIR_STEP_NONE)

    m.particleFlags = m.particleFlags | PARTICLE_DUST

    if m.action == ACT_AIR_ROLL then
        if m.actionTimer > 5 then
            set_mario_action(m, ACT_FREEFALL, 0)
            e.airRolled = true
        end
    end

    if m.wall ~= nil then
        set_mario_action(m, ACT_FORWARD_AIR_KB, 0)
    end

    m.actionTimer = m.actionTimer + 1
end

function act_3d_roll(m)
    common_slide_action(m, ACT_AIR_ROLL, ACT_FREEFALL, MARIO_ANIM_FORWARD_SPINNING)

    if m.wall ~= nil then
        set_mario_action(m, ACT_BACKWARD_GROUND_KB, 0)
    end

    if m.actionTimer > 5 then
        set_mario_action(m, ACT_WALKING, 0)
    end

    mario_set_forward_vel(m, 50)

    if (m.controller.buttonPressed & A_BUTTON) ~= 0 then
        set_mario_action(m, ACT_LONG_JUMP, 0)
        mario_set_forward_vel(m, m.forwardVel + 15)
    end

    m.actionTimer = m.actionTimer + 1
    return 0
end


function mario_update(m)
    local e = gStateExtras[m.playerIndex]

    if m.action == ACT_GROUND_POUND and (m.controller.buttonPressed & Y_BUTTON) ~= 0 and e.airRolled == false then
        set_mario_action(m, ACT_AIR_ROLL, 0)
        m.forwardVel = 60
        m.vel.y = 0
        m.faceAngle.y = m.intendedYaw
        m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
    end

    if m.action == ACT_IDLE or m.action == ACT_WALKING or m.action == ACT_DOUBLE_JUMP then
        e.airRolled = false
    end

    if m.action == ACT_CROUCHING or m.action == ACT_CROUCH_SLIDE or m.action == ACT_LONG_JUMP_LAND then
        if (m.controller.buttonPressed & Y_BUTTON) ~= 0 then
            set_mario_action(m, ACT_3D_ROLL, 0)
            m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
        end
    end
    if m.action == ACT_LONG_JUMP and m.prevAction == ACT_3D_ROLL then
        if m.actionTimer < 15 then
            set_mario_animation(m, MARIO_ANIM_FORWARD_SPINNING)
            set_anim_to_frame(m, e.animFrame)
            e.animFrame = e.animFrame + 1
            if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
                e.animFrame = e.animFrame - m.marioObj.header.gfx.animInfo.curAnim.loopEnd
            end
        else
            set_anim_to_frame(m, 255)
        end
        m.actionTimer = m.actionTimer + 1
    end
end

function mario_on_set_action(m)
    local e = gStateExtras[m.playerIndex]

    if m.action == ACT_BACKWARD_AIR_KB and e.airRolled == true then
        set_mario_action(m, ACT_FORWARD_AIR_KB, 0)
        e.airRolled = false
    end
end

-----------
-- hooks --
-----------

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)

hook_mario_action(ACT_AIR_ROLL,     { every_frame = act_air_roll })
hook_mario_action(ACT_3D_ROLL,      { every_frame = act_3d_roll }, INT_KICK)
